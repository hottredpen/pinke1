-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : pkgit
-- 
-- Part : #1
-- Date : 2017-08-13 15:57:21
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `pk_admin`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin`;
CREATE TABLE `pk_admin` (
  `id` mediumint(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `group` int(5) NOT NULL,
  `verify` varchar(50) NOT NULL COMMENT '参与密码的md5之一',
  `last_ip` varchar(15) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_admin`
-- -----------------------------
INSERT INTO `pk_admin` VALUES ('1', 'admin', '9e19cde4ce227b703abf87b83bea9ba1', '1', 'espZNB', '127.0.0.1', 'admin@admin.com', '1', '1500646452', '1502607393');

-- -----------------------------
-- Table structure for `pk_admin_auth`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_auth`;
CREATE TABLE `pk_admin_auth` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `role_id` tinyint(3) NOT NULL,
  `menu_id` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `role_id` (`role_id`,`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=405 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_admin_auth`
-- -----------------------------
INSERT INTO `pk_admin_auth` VALUES ('276', '20', '8');
INSERT INTO `pk_admin_auth` VALUES ('273', '20', '2');
INSERT INTO `pk_admin_auth` VALUES ('274', '20', '6');
INSERT INTO `pk_admin_auth` VALUES ('278', '20', '148');
INSERT INTO `pk_admin_auth` VALUES ('277', '20', '9');
INSERT INTO `pk_admin_auth` VALUES ('281', '20', '60');
INSERT INTO `pk_admin_auth` VALUES ('282', '20', '61');
INSERT INTO `pk_admin_auth` VALUES ('283', '20', '62');
INSERT INTO `pk_admin_auth` VALUES ('284', '20', '63');
INSERT INTO `pk_admin_auth` VALUES ('285', '20', '64');
INSERT INTO `pk_admin_auth` VALUES ('275', '20', '7');
INSERT INTO `pk_admin_auth` VALUES ('279', '20', '626');
INSERT INTO `pk_admin_auth` VALUES ('280', '20', '705');
INSERT INTO `pk_admin_auth` VALUES ('286', '20', '700');
INSERT INTO `pk_admin_auth` VALUES ('287', '20', '672');
INSERT INTO `pk_admin_auth` VALUES ('288', '20', '706');
INSERT INTO `pk_admin_auth` VALUES ('289', '20', '707');
INSERT INTO `pk_admin_auth` VALUES ('290', '20', '701');
INSERT INTO `pk_admin_auth` VALUES ('404', '10', '671');
INSERT INTO `pk_admin_auth` VALUES ('403', '10', '670');
INSERT INTO `pk_admin_auth` VALUES ('402', '10', '669');
INSERT INTO `pk_admin_auth` VALUES ('401', '10', '655');
INSERT INTO `pk_admin_auth` VALUES ('400', '10', '654');
INSERT INTO `pk_admin_auth` VALUES ('399', '10', '653');
INSERT INTO `pk_admin_auth` VALUES ('398', '10', '652');
INSERT INTO `pk_admin_auth` VALUES ('397', '10', '651');
INSERT INTO `pk_admin_auth` VALUES ('396', '10', '650');
INSERT INTO `pk_admin_auth` VALUES ('395', '10', '668');
INSERT INTO `pk_admin_auth` VALUES ('394', '10', '649');
INSERT INTO `pk_admin_auth` VALUES ('393', '10', '648');
INSERT INTO `pk_admin_auth` VALUES ('392', '10', '647');
INSERT INTO `pk_admin_auth` VALUES ('391', '10', '646');
INSERT INTO `pk_admin_auth` VALUES ('390', '10', '645');
INSERT INTO `pk_admin_auth` VALUES ('389', '10', '644');
INSERT INTO `pk_admin_auth` VALUES ('388', '10', '641');
INSERT INTO `pk_admin_auth` VALUES ('387', '10', '640');
INSERT INTO `pk_admin_auth` VALUES ('386', '10', '639');
INSERT INTO `pk_admin_auth` VALUES ('385', '10', '638');
INSERT INTO `pk_admin_auth` VALUES ('384', '10', '672');
INSERT INTO `pk_admin_auth` VALUES ('383', '10', '64');
INSERT INTO `pk_admin_auth` VALUES ('382', '10', '63');
INSERT INTO `pk_admin_auth` VALUES ('381', '10', '62');
INSERT INTO `pk_admin_auth` VALUES ('380', '10', '61');
INSERT INTO `pk_admin_auth` VALUES ('379', '10', '60');
INSERT INTO `pk_admin_auth` VALUES ('378', '10', '626');
INSERT INTO `pk_admin_auth` VALUES ('377', '10', '148');
INSERT INTO `pk_admin_auth` VALUES ('376', '10', '2');
INSERT INTO `pk_admin_auth` VALUES ('375', '10', '1');
INSERT INTO `pk_admin_auth` VALUES ('211', '15', '666');
INSERT INTO `pk_admin_auth` VALUES ('210', '15', '665');
INSERT INTO `pk_admin_auth` VALUES ('209', '15', '664');
INSERT INTO `pk_admin_auth` VALUES ('208', '15', '663');
INSERT INTO `pk_admin_auth` VALUES ('207', '15', '662');
INSERT INTO `pk_admin_auth` VALUES ('206', '15', '661');
INSERT INTO `pk_admin_auth` VALUES ('205', '15', '660');
INSERT INTO `pk_admin_auth` VALUES ('204', '15', '659');
INSERT INTO `pk_admin_auth` VALUES ('203', '15', '658');
INSERT INTO `pk_admin_auth` VALUES ('202', '15', '657');
INSERT INTO `pk_admin_auth` VALUES ('201', '15', '656');
INSERT INTO `pk_admin_auth` VALUES ('200', '15', '671');
INSERT INTO `pk_admin_auth` VALUES ('199', '15', '670');
INSERT INTO `pk_admin_auth` VALUES ('198', '15', '669');
INSERT INTO `pk_admin_auth` VALUES ('197', '15', '655');
INSERT INTO `pk_admin_auth` VALUES ('196', '15', '654');
INSERT INTO `pk_admin_auth` VALUES ('195', '15', '653');
INSERT INTO `pk_admin_auth` VALUES ('194', '15', '652');
INSERT INTO `pk_admin_auth` VALUES ('193', '15', '651');
INSERT INTO `pk_admin_auth` VALUES ('192', '15', '650');
INSERT INTO `pk_admin_auth` VALUES ('191', '15', '668');
INSERT INTO `pk_admin_auth` VALUES ('190', '15', '649');
INSERT INTO `pk_admin_auth` VALUES ('189', '15', '648');
INSERT INTO `pk_admin_auth` VALUES ('188', '15', '647');
INSERT INTO `pk_admin_auth` VALUES ('187', '15', '646');
INSERT INTO `pk_admin_auth` VALUES ('186', '15', '645');
INSERT INTO `pk_admin_auth` VALUES ('185', '15', '644');
INSERT INTO `pk_admin_auth` VALUES ('184', '15', '641');
INSERT INTO `pk_admin_auth` VALUES ('183', '15', '640');
INSERT INTO `pk_admin_auth` VALUES ('182', '15', '639');
INSERT INTO `pk_admin_auth` VALUES ('181', '15', '638');
INSERT INTO `pk_admin_auth` VALUES ('180', '15', '628');
INSERT INTO `pk_admin_auth` VALUES ('179', '15', '627');
INSERT INTO `pk_admin_auth` VALUES ('178', '15', '626');
INSERT INTO `pk_admin_auth` VALUES ('177', '15', '625');
INSERT INTO `pk_admin_auth` VALUES ('176', '15', '624');
INSERT INTO `pk_admin_auth` VALUES ('175', '15', '623');
INSERT INTO `pk_admin_auth` VALUES ('174', '15', '162');
INSERT INTO `pk_admin_auth` VALUES ('173', '15', '161');
INSERT INTO `pk_admin_auth` VALUES ('172', '15', '160');
INSERT INTO `pk_admin_auth` VALUES ('171', '15', '156');
INSERT INTO `pk_admin_auth` VALUES ('170', '15', '278');
INSERT INTO `pk_admin_auth` VALUES ('169', '15', '159');
INSERT INTO `pk_admin_auth` VALUES ('168', '15', '158');
INSERT INTO `pk_admin_auth` VALUES ('167', '15', '157');
INSERT INTO `pk_admin_auth` VALUES ('166', '15', '155');
INSERT INTO `pk_admin_auth` VALUES ('165', '15', '154');
INSERT INTO `pk_admin_auth` VALUES ('164', '15', '10');
INSERT INTO `pk_admin_auth` VALUES ('163', '15', '34');
INSERT INTO `pk_admin_auth` VALUES ('212', '15', '667');

-- -----------------------------
-- Table structure for `pk_admin_config`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_config`;
CREATE TABLE `pk_admin_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `module` varchar(32) NOT NULL DEFAULT '' COMMENT '配置所在分组',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型',
  `value` text NOT NULL COMMENT '配置值',
  `options` text NOT NULL COMMENT '配置项',
  `tip` varchar(256) NOT NULL DEFAULT '' COMMENT '配置提示',
  `item_group` int(5) NOT NULL,
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- -----------------------------
-- Records of `pk_admin_config`
-- -----------------------------
INSERT INTO `pk_admin_config` VALUES ('37', 'website_url', '网站域名', 'common', 'text', 'http://pinke.com/', '', '以‘/’结尾', '0', '0', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('38', 'website_name', '网站名称', 'common', 'text', 'pjaxcms官网2d', '', '', '0', '0', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('39', 'website_beian', '备案号', 'common', 'text', '浙ICP备14020195号-2', '', '', '0', '1500719333', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('40', 'mail_address', '邮件地址', 'common', 'text', 'domain@chuangpinke.com', '', '', '1', '1500724589', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('41', 'mail_loginname', '邮件登录名', 'common', 'text', 'domain@chuangpinke.com', '', '', '1', '1500724629', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('42', 'mail_smtp', 'smtp', 'common', 'text', 'smtp.mxhichina.com', '', '', '1', '1500724659', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('43', 'mail_password', '邮件密码', 'common', 'text', '123456', '', '', '1', '1500724705', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('44', 'mail_port', '邮件端口', 'common', 'text', '25', '', '', '1', '1500724739', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('45', 'mail_name', '邮件发送人', 'common', 'text', 'pjax官网', '', '', '1', '1500724806', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('46', 'register_open', '是否开启注册', 'user', 'switch', '1', '', '', '0', '1500726749', '1500726829', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('47', 'project_name', 'cms选用系统', 'cms', 'text', 'Yuji', '', '', '0', '1500726926', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('48', 'require_build_js', 'js是否使用build', 'admin', 'switch', '0', '', '', '0', '1500727141', '1500727141', '33', '1');
INSERT INTO `pk_admin_config` VALUES ('52', 'badword', '不允许的注册名', 'user', 'textarea', '', '', '', '0', '1501294550', '1501294567', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('53', 'badwordfilter', '敏感词的过滤', 'user', 'textarea', '', '', '', '0', '1501302716', '1501302979', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('61', 'auth_username', '官网账号', 'common', 'text', 'hottredpen', '', '', '0', '1501504700', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('62', 'secret_key', '官网秘钥', 'common', 'text', '5be7534289bb3e325f4c9391990294ff', '', '官网中获得', '0', '1501504758', '1502578143', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('63', 'site_name', 'cms网站名称', 'cms', 'text', '品客系统', '', '', '0', '1502495285', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('64', 'site_400', '400电话', 'cms', 'text', '123-456-7890', '', '', '0', '1502495807', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('65', 'site_com', '公司名称', 'cms', 'text', 'XXXXXX有限公司', '', '', '0', '1502495871', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('66', 'site_com_address', '公司地址', 'cms', 'text', 'XXXXXX东路166号3楼', '', '', '0', '1502495991', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('67', 'site_copyright', '版权文字说明', 'cms', 'text', 'Copyright 2017 www.lankuwangluo.com All Rights Reserved ', '', '', '0', '1502496131', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('68', 'site_icp', '备案号', 'cms', 'text', '浙ICP备17017151号', '', '', '0', '1502496182', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('69', 'site_email', '邮箱', 'cms', 'text', 'lankuwangluo@126.com', '', '', '0', '1502496339', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('70', 'site_zipcode', '邮政编码', 'cms', 'text', '322100', '', '', '0', '1502496375', '1502610291', '100', '1');
INSERT INTO `pk_admin_config` VALUES ('71', 'web_openid', '网站id', 'common', 'text', 'abcdefghijklmnopqrst-bcdefghijklmnopqqssu-cdefghijklmnopqqssud-015fe76ea17afcd903e6276204c3336b', '', '', '0', '1502527323', '1502578143', '100', '1');

-- -----------------------------
-- Table structure for `pk_admin_database`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_database`;
CREATE TABLE `pk_admin_database` (
  `id` mediumint(6) NOT NULL AUTO_INCREMENT,
  `filename` varchar(30) NOT NULL,
  `tables_num` int(5) NOT NULL,
  `tables_data` text NOT NULL,
  `create_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `pk_admin_group`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_group`;
CREATE TABLE `pk_admin_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '部门ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级部门ID',
  `title` varchar(31) NOT NULL DEFAULT '' COMMENT '部门名称',
  `icon` varchar(31) NOT NULL DEFAULT '' COMMENT '图标',
  `menu_auth` text NOT NULL COMMENT '权限列表',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='部门信息表';

-- -----------------------------
-- Records of `pk_admin_group`
-- -----------------------------
INSERT INTO `pk_admin_group` VALUES ('1', '0', '超级管理员', '', '', '1492827025', '0', '0', '1');
INSERT INTO `pk_admin_group` VALUES ('10', '0', '技术管理员', '', '', '1492827126', '1502414792', '0', '1');
INSERT INTO `pk_admin_group` VALUES ('15', '0', '客服管理员', '', '', '1492837434', '1492838919', '0', '1');

-- -----------------------------
-- Table structure for `pk_admin_hook`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_hook`;
CREATE TABLE `pk_admin_hook` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `plugin` varchar(100) NOT NULL DEFAULT '' COMMENT '钩子来自哪个插件',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子描述',
  `system` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统钩子',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='钩子表';

-- -----------------------------
-- Records of `pk_admin_hook`
-- -----------------------------
INSERT INTO `pk_admin_hook` VALUES ('1', 'admin_index', '', '后台首页', '1', '1468174214', '1477757518', '1');
INSERT INTO `pk_admin_hook` VALUES ('2', 'plugin_index_tab_list', '', '插件扩展tab钩子', '1', '1468174214', '1468174214', '1');
INSERT INTO `pk_admin_hook` VALUES ('3', 'module_index_tab_list', '', '模块扩展tab钩子', '1', '1468174214', '1468174214', '1');
INSERT INTO `pk_admin_hook` VALUES ('4', 'page_tips', '', '每个页面的提示', '1', '1468174214', '1468174214', '1');
INSERT INTO `pk_admin_hook` VALUES ('5', 'signin_footer', '', '登录页面底部钩子', '1', '1479269315', '1479269315', '1');
INSERT INTO `pk_admin_hook` VALUES ('6', 'signin_captcha', '', '登录页面验证码钩子', '1', '1479269315', '1479269315', '1');
INSERT INTO `pk_admin_hook` VALUES ('7', 'signin', '', '登录控制器钩子', '1', '1479386875', '1479386875', '1');
INSERT INTO `pk_admin_hook` VALUES ('20', 'zuowen_html_hook', 'HelloWorld', '作文详情页的钩子', '0', '1496978483', '1496978483', '1');
INSERT INTO `pk_admin_hook` VALUES ('19', 'my_hook', 'HelloWorld', '我的钩子', '0', '1496978483', '1496978483', '1');
INSERT INTO `pk_admin_hook` VALUES ('21', 'weixin_message_send_content_by_media_id', 'WeixinCard', '发送信息时的钩子', '0', '1502434509', '1502434509', '1');

-- -----------------------------
-- Table structure for `pk_admin_hook_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_hook_plugin`;
CREATE TABLE `pk_admin_hook_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(100) NOT NULL DEFAULT '' COMMENT '钩子id(插件的钩子必须带上插件名，系统钩子带有sys)',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标识',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8 COMMENT='钩子-插件对应表';

-- -----------------------------
-- Records of `pk_admin_hook_plugin`
-- -----------------------------
INSERT INTO `pk_admin_hook_plugin` VALUES ('2', 'admin_index', 'DevTeam', '1477755780', '1477755780', '2', '1');
INSERT INTO `pk_admin_hook_plugin` VALUES ('5', 'admin_index', 'SystemInfo', '1496633792', '1496633792', '100', '1');
INSERT INTO `pk_admin_hook_plugin` VALUES ('30', 'zuowen_html_hook', 'HelloWorld', '1496978483', '1496978483', '100', '1');
INSERT INTO `pk_admin_hook_plugin` VALUES ('29', 'my_hook', 'HelloWorld', '1496978483', '1496978483', '100', '1');
INSERT INTO `pk_admin_hook_plugin` VALUES ('28', 'page_tips', 'HelloWorld', '1496978483', '1496978483', '100', '1');
INSERT INTO `pk_admin_hook_plugin` VALUES ('31', 'page_tips', 'CmsProjectLanku', '1498099287', '1498099287', '100', '1');
INSERT INTO `pk_admin_hook_plugin` VALUES ('33', 'page_tips', 'CmsProjectWechat', '1498472339', '1498472339', '100', '1');
INSERT INTO `pk_admin_hook_plugin` VALUES ('90', 'page_tips', 'CmsProjectPinke', '1501764674', '1501764674', '100', '1');
INSERT INTO `pk_admin_hook_plugin` VALUES ('95', 'weixin_message_send_content_by_media_id', 'WeixinCard', '1502434509', '1502434509', '100', '1');

-- -----------------------------
-- Table structure for `pk_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_log`;
CREATE TABLE `pk_admin_log` (
  `id` mediumint(6) NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) NOT NULL,
  `model` varchar(50) NOT NULL,
  `scene_id` int(5) NOT NULL,
  `record_id` int(10) NOT NULL,
  `info` varchar(255) NOT NULL,
  `before_data` varchar(1000) DEFAULT NULL,
  `after_data` varchar(1000) DEFAULT NULL,
  `ip` varchar(50) NOT NULL,
  `create_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_admin_log`
-- -----------------------------
INSERT INTO `pk_admin_log` VALUES ('1', '1', 'Admin', '10', '1', 'admin登录成功', 'a:0:{}', 'a:0:{}', '127.0.0.1', '1502581816');
INSERT INTO `pk_admin_log` VALUES ('2', '1', 'AdminConfig', '22', '0', 'admin【超级管理员】修改了站点配置 ', 'a:0:{}', 'a:9:{i:0;a:2:{s:4:\"name\";s:12:\"project_name\";s:5:\"value\";s:4:\"Yuji\";}i:1;a:2:{s:4:\"name\";s:9:\"site_name\";s:5:\"value\";s:12:\"品客系统\";}i:2;a:2:{s:4:\"name\";s:8:\"site_400\";s:5:\"value\";s:12:\"400-811-3676\";}i:3;a:2:{s:4:\"name\";s:8:\"site_com\";s:5:\"value\";s:30:\"浙江蓝酷网络有限公司\";}i:4;a:2:{s:4:\"name\";s:16:\"site_com_address\";s:5:\"value\";s:40:\"浙江省东阳市汉宁东路166号3楼\";}i:5;a:2:{s:4:\"name\";s:14:\"site_copyright\";s:5:\"value\";s:56:\"Copyright 2017 www.lankuwangluo.com All Rights Reserved \";}i:6;a:2:{s:4:\"name\";s:8:\"site_icp\";s:5:\"value\";s:20:\"浙ICP备17017151号\";}i:7;a:2:{s:4:\"name\";s:10:\"site_email\";s:5:\"value\";s:20:\"lankuwangluo@126.com\";}i:8;a:2:{s:4:\"name\";s:12:\"site_zipcode\";s:5:\"value\";s:6:\"322100\";}}', '127.0.0.1', '1502581829');
INSERT INTO `pk_admin_log` VALUES ('3', '1', 'Admin', '10', '1', 'admin登录成功', 'a:0:{}', 'a:0:{}', '127.0.0.1', '1502607393');
INSERT INTO `pk_admin_log` VALUES ('4', '1', 'CmsDocument', '12', '391', '未找到模板', 'N;', 'a:2:{s:6:\"status\";i:0;s:2:\"id\";i:391;}', '127.0.0.1', '1502607981');
INSERT INTO `pk_admin_log` VALUES ('5', '1', 'CmsDocument', '12', '380', '未找到模板', 'a:29:{s:2:\"id\";s:3:\"380\";s:3:\"uid\";s:1:\"0\";s:4:\"name\";s:0:\"\";s:5:\"title\";s:12:\"联系我们\";s:11:\"category_id\";s:3:\"193\";s:7:\"gotourl\";N;s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:4:\"root\";s:1:\"0\";s:3:\"pid\";s:1:\"0\";s:8:\"model_id\";s:1:\"0\";s:4:\"type\";s:1:\"2\";s:8:\"position\";s:1:\"0\";s:7:\"link_id\";s:1:\"0\";s:8:\"cover_id\";s:1:\"0\";s:11:\"list_p_data\";s:0:\"\";s:8:\"listdata\";s:0:\"\";s:9:\"otherdata\";s:0:\"\";s:7:\"display\";s:1:\"1\";s:8:\"deadline\";s:1:\"0\";s:6:\"attach\";s:1:\"0\";s:4:\"view\";s:1:\"0\";s:7:\"comment\";s:1:\"0\";s:6:\"extend\";s:1:\"0\";s:5:\"level\";s:1:\"0\";s:14:\"recommend_side\";s:1:\"0\";s:11:\"create_time\";s:10:\"1493800751\";s:11:\"update_time\";s:10:\"1493800751\";s:6:\"status\";s:1:\"1\";}', 'a:11:{s:11:\"category_id\";i:193;s:5:\"title\";s:12:\"联系我们\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:11:\"list_p_data\";s:0:\"\";s:6:\"status\";i:1;s:2:\"id\";i:380;s:11:\"create_time\";i:1502609938;s:11:\"update_time\";i:1502609938;s:8:\"listdata\";s:0:\"\";s:9:\"otherdata\";s:0:\"\";}', '127.0.0.1', '1502609938');
INSERT INTO `pk_admin_log` VALUES ('6', '1', 'CmsDocument', '12', '375', '未找到模板', 'a:29:{s:2:\"id\";s:3:\"375\";s:3:\"uid\";s:1:\"0\";s:4:\"name\";s:0:\"\";s:5:\"title\";s:12:\"关于语记\";s:11:\"category_id\";s:3:\"174\";s:7:\"gotourl\";N;s:8:\"keywords\";s:12:\"关于语记\";s:11:\"description\";s:12:\"关于语记\";s:4:\"root\";s:1:\"0\";s:3:\"pid\";s:1:\"0\";s:8:\"model_id\";s:1:\"0\";s:4:\"type\";s:1:\"2\";s:8:\"position\";s:1:\"0\";s:7:\"link_id\";s:1:\"0\";s:8:\"cover_id\";s:1:\"0\";s:11:\"list_p_data\";s:0:\"\";s:8:\"listdata\";s:0:\"\";s:9:\"otherdata\";s:0:\"\";s:7:\"display\";s:1:\"1\";s:8:\"deadline\";s:1:\"0\";s:6:\"attach\";s:1:\"0\";s:4:\"view\";s:1:\"0\";s:7:\"comment\";s:1:\"0\";s:6:\"extend\";s:1:\"0\";s:5:\"level\";s:1:\"0\";s:14:\"recommend_side\";s:1:\"0\";s:11:\"create_time\";s:10:\"1493791782\";s:11:\"update_time\";s:10:\"1493791782\";s:6:\"status\";s:1:\"1\";}', 'a:11:{s:11:\"category_id\";i:174;s:5:\"title\";s:12:\"关于我们\";s:8:\"keywords\";s:12:\"关于我们\";s:11:\"description\";s:12:\"关于我们\";s:11:\"list_p_data\";s:0:\"\";s:6:\"status\";i:1;s:2:\"id\";i:375;s:11:\"create_time\";i:1502610003;s:11:\"update_time\";i:1502610003;s:8:\"listdata\";s:0:\"\";s:9:\"otherdata\";s:0:\"\";}', '127.0.0.1', '1502610003');
INSERT INTO `pk_admin_log` VALUES ('7', '1', 'CmsDocument', '12', '379', '未找到模板', 'a:29:{s:2:\"id\";s:3:\"379\";s:3:\"uid\";s:1:\"0\";s:4:\"name\";s:0:\"\";s:5:\"title\";s:24:\"关于我们（单页）\";s:11:\"category_id\";s:3:\"192\";s:7:\"gotourl\";N;s:8:\"keywords\";s:24:\"关于我们（单页）\";s:11:\"description\";s:24:\"关于我们（单页）\";s:4:\"root\";s:1:\"0\";s:3:\"pid\";s:1:\"0\";s:8:\"model_id\";s:1:\"0\";s:4:\"type\";s:1:\"2\";s:8:\"position\";s:1:\"0\";s:7:\"link_id\";s:1:\"0\";s:8:\"cover_id\";s:1:\"0\";s:11:\"list_p_data\";s:0:\"\";s:8:\"listdata\";s:0:\"\";s:9:\"otherdata\";s:0:\"\";s:7:\"display\";s:1:\"1\";s:8:\"deadline\";s:1:\"0\";s:6:\"attach\";s:1:\"0\";s:4:\"view\";s:1:\"0\";s:7:\"comment\";s:1:\"0\";s:6:\"extend\";s:1:\"0\";s:5:\"level\";s:1:\"0\";s:14:\"recommend_side\";s:1:\"0\";s:11:\"create_time\";s:10:\"1493791851\";s:11:\"update_time\";s:10:\"1493791851\";s:6:\"status\";s:1:\"1\";}', 'a:11:{s:11:\"category_id\";i:192;s:5:\"title\";s:24:\"关于我们（单页）\";s:8:\"keywords\";s:24:\"关于我们（单页）\";s:11:\"description\";s:24:\"关于我们（单页）\";s:11:\"list_p_data\";s:0:\"\";s:6:\"status\";i:1;s:2:\"id\";i:379;s:11:\"create_time\";i:1502610059;s:11:\"update_time\";i:1502610059;s:8:\"listdata\";s:0:\"\";s:9:\"otherdata\";s:0:\"\";}', '127.0.0.1', '1502610059');
INSERT INTO `pk_admin_log` VALUES ('8', '1', 'CmsDocument', '12', '381', '未找到模板', 'N;', 'a:2:{s:6:\"status\";i:1;s:2:\"id\";i:381;}', '127.0.0.1', '1502610185');
INSERT INTO `pk_admin_log` VALUES ('9', '1', 'AdminConfig', '22', '0', 'admin【超级管理员】修改了站点配置 ', 'a:0:{}', 'a:9:{i:0;a:2:{s:4:\"name\";s:12:\"project_name\";s:5:\"value\";s:4:\"Yuji\";}i:1;a:2:{s:4:\"name\";s:9:\"site_name\";s:5:\"value\";s:12:\"品客系统\";}i:2;a:2:{s:4:\"name\";s:8:\"site_400\";s:5:\"value\";s:12:\"123-456-7890\";}i:3;a:2:{s:4:\"name\";s:8:\"site_com\";s:5:\"value\";s:18:\"XXXXXX有限公司\";}i:4;a:2:{s:4:\"name\";s:16:\"site_com_address\";s:5:\"value\";s:22:\"XXXXXX东路166号3楼\";}i:5;a:2:{s:4:\"name\";s:14:\"site_copyright\";s:5:\"value\";s:56:\"Copyright 2017 www.lankuwangluo.com All Rights Reserved \";}i:6;a:2:{s:4:\"name\";s:8:\"site_icp\";s:5:\"value\";s:20:\"浙ICP备17017151号\";}i:7;a:2:{s:4:\"name\";s:10:\"site_email\";s:5:\"value\";s:20:\"lankuwangluo@126.com\";}i:8;a:2:{s:4:\"name\";s:12:\"site_zipcode\";s:5:\"value\";s:6:\"322100\";}}', '127.0.0.1', '1502610291');
INSERT INTO `pk_admin_log` VALUES ('10', '1', 'AdminMenu', '13', '64', ' admin【超级管理员】删除菜单节点：删除 ', 'a:15:{s:2:\"id\";s:2:\"64\";s:4:\"name\";s:6:\"删除\";s:3:\"pid\";s:2:\"61\";s:7:\"top_pid\";s:1:\"1\";s:15:\"controller_name\";s:5:\"Admin\";s:11:\"action_name\";s:6:\"delete\";s:3:\"url\";s:18:\"admin/Admin/delete\";s:4:\"data\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:5:\"often\";s:1:\"0\";s:5:\"ordid\";s:1:\"0\";s:7:\"display\";s:1:\"0\";s:6:\"status\";s:1:\"1\";s:7:\"addtime\";s:1:\"0\";s:10:\"updatetime\";s:1:\"0\";}', 'a:1:{s:2:\"id\";i:64;}', '127.0.0.1', '1502610920');
INSERT INTO `pk_admin_log` VALUES ('11', '1', 'AdminMenu', '13', '63', ' admin【超级管理员】删除菜单节点：编辑 ', 'a:15:{s:2:\"id\";s:2:\"63\";s:4:\"name\";s:6:\"编辑\";s:3:\"pid\";s:2:\"61\";s:7:\"top_pid\";s:1:\"1\";s:15:\"controller_name\";s:5:\"Admin\";s:11:\"action_name\";s:4:\"edit\";s:3:\"url\";s:16:\"admin/Admin/edit\";s:4:\"data\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:5:\"often\";s:1:\"0\";s:5:\"ordid\";s:1:\"0\";s:7:\"display\";s:1:\"0\";s:6:\"status\";s:1:\"1\";s:7:\"addtime\";s:1:\"0\";s:10:\"updatetime\";s:1:\"0\";}', 'a:1:{s:2:\"id\";i:63;}', '127.0.0.1', '1502610929');
INSERT INTO `pk_admin_log` VALUES ('12', '1', 'AdminMenu', '13', '62', ' admin【超级管理员】删除菜单节点：新增 ', 'a:15:{s:2:\"id\";s:2:\"62\";s:4:\"name\";s:6:\"新增\";s:3:\"pid\";s:2:\"61\";s:7:\"top_pid\";s:1:\"1\";s:15:\"controller_name\";s:5:\"Admin\";s:11:\"action_name\";s:3:\"add\";s:3:\"url\";s:15:\"admin/Admin/add\";s:4:\"data\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:5:\"often\";s:1:\"0\";s:5:\"ordid\";s:1:\"0\";s:7:\"display\";s:1:\"0\";s:6:\"status\";s:1:\"1\";s:7:\"addtime\";s:1:\"0\";s:10:\"updatetime\";s:1:\"0\";}', 'a:1:{s:2:\"id\";i:62;}', '127.0.0.1', '1502610936');
INSERT INTO `pk_admin_log` VALUES ('13', '1', 'AdminMenu', '13', '9', ' admin【超级管理员】删除菜单节点：删除 ', 'a:15:{s:2:\"id\";s:1:\"9\";s:4:\"name\";s:6:\"删除\";s:3:\"pid\";s:1:\"6\";s:7:\"top_pid\";s:1:\"1\";s:15:\"controller_name\";s:4:\"Menu\";s:11:\"action_name\";s:6:\"delete\";s:3:\"url\";s:17:\"admin/Menu/delete\";s:4:\"data\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:5:\"often\";s:1:\"0\";s:5:\"ordid\";s:1:\"0\";s:7:\"display\";s:1:\"0\";s:6:\"status\";s:1:\"1\";s:7:\"addtime\";s:1:\"0\";s:10:\"updatetime\";s:1:\"0\";}', 'a:1:{s:2:\"id\";i:9;}', '127.0.0.1', '1502610942');
INSERT INTO `pk_admin_log` VALUES ('14', '1', 'AdminMenu', '13', '8', ' admin【超级管理员】删除菜单节点：编辑 ', 'a:15:{s:2:\"id\";s:1:\"8\";s:4:\"name\";s:6:\"编辑\";s:3:\"pid\";s:1:\"6\";s:7:\"top_pid\";s:1:\"1\";s:15:\"controller_name\";s:4:\"Menu\";s:11:\"action_name\";s:4:\"edit\";s:3:\"url\";s:15:\"admin/Menu/edit\";s:4:\"data\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:5:\"often\";s:1:\"0\";s:5:\"ordid\";s:1:\"0\";s:7:\"display\";s:1:\"0\";s:6:\"status\";s:1:\"1\";s:7:\"addtime\";s:1:\"0\";s:10:\"updatetime\";s:1:\"0\";}', 'a:1:{s:2:\"id\";i:8;}', '127.0.0.1', '1502610948');
INSERT INTO `pk_admin_log` VALUES ('15', '1', 'AdminMenu', '13', '7', ' admin【超级管理员】删除菜单节点：新增 ', 'a:15:{s:2:\"id\";s:1:\"7\";s:4:\"name\";s:6:\"新增\";s:3:\"pid\";s:1:\"6\";s:7:\"top_pid\";s:1:\"1\";s:15:\"controller_name\";s:4:\"Menu\";s:11:\"action_name\";s:3:\"add\";s:3:\"url\";s:14:\"admin/Menu/add\";s:4:\"data\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:5:\"often\";s:1:\"0\";s:5:\"ordid\";s:1:\"0\";s:7:\"display\";s:1:\"0\";s:6:\"status\";s:1:\"1\";s:7:\"addtime\";s:1:\"0\";s:10:\"updatetime\";s:1:\"0\";}', 'a:1:{s:2:\"id\";i:7;}', '127.0.0.1', '1502610953');
INSERT INTO `pk_admin_log` VALUES ('16', '1', 'AdminMenu', '12', '693', 'admin【超级管理员】修改菜单节点： ', 'N;', 'a:2:{s:6:\"status\";i:0;s:2:\"id\";i:693;}', '127.0.0.1', '1502610981');

-- -----------------------------
-- Table structure for `pk_admin_log_tpl`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_log_tpl`;
CREATE TABLE `pk_admin_log_tpl` (
  `id` mediumint(6) NOT NULL AUTO_INCREMENT,
  `model_scene` varchar(100) NOT NULL,
  `title` varchar(50) NOT NULL,
  `tpl` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_admin_log_tpl`
-- -----------------------------
INSERT INTO `pk_admin_log_tpl` VALUES ('1', 'AdminPlugin_11', '安装插件', '[admin_id|admin_local_admin_id_name]安装了插件[record_id|admin_get_plugin_name_by_plugin_id],插件id=[record_id]', '1', '1500377788', '1500446929');
INSERT INTO `pk_admin_log_tpl` VALUES ('2', 'AdminPlugin_13', '卸载插件', '[admin_id|admin_local_admin_id_name]卸载了插件[record_id|admin_get_plugin_name_by_plugin_id],插件id=[record_id]', '1', '1500378188', '1500446885');
INSERT INTO `pk_admin_log_tpl` VALUES ('4', 'Admin_11', '添加管理员', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】添加了新的管理员[after_data[username]]【[after_data[group]|admin_local_admin_group_name]】', '1', '1500442559', '1500450724');
INSERT INTO `pk_admin_log_tpl` VALUES ('5', 'Admin_12', '修改管理员', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】修改了管理员[before_data[username]]【[before_data[group]|admin_local_admin_group_name]】', '1', '1500442624', '1500450769');
INSERT INTO `pk_admin_log_tpl` VALUES ('6', 'Admin_13', '删除管理员', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】删除了管理员[before_data[username]]【[before_data[group]|admin_local_admin_group_name]】', '1', '1500443067', '1501293988');
INSERT INTO `pk_admin_log_tpl` VALUES ('7', 'AdminConfig_22', '修改站点配置', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】修改了站点配置 ', '1', '1501293922', '1501293997');
INSERT INTO `pk_admin_log_tpl` VALUES ('8', 'AdminConfig_11', '添加站点配置项', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】添加了站点配置项：[after_data[title]]', '1', '1501294130', '1501302969');
INSERT INTO `pk_admin_log_tpl` VALUES ('9', 'AdminConfig_12', '修改站点配置项', ' [admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】修改了站点配置项：[after_data[title]] ', '1', '1501302938', '1501302959');
INSERT INTO `pk_admin_log_tpl` VALUES ('10', 'AdminConfig_13', '删除站点配置项', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】删除了站点配置项：[before_data[title]] ', '1', '1501310903', '1501310929');
INSERT INTO `pk_admin_log_tpl` VALUES ('11', 'AdminMenu_11', '添加菜单节点', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】添加菜单节点：[after_data[name]]', '1', '1501388861', '1501389065');
INSERT INTO `pk_admin_log_tpl` VALUES ('12', 'AdminMenu_12', '修改菜单节点', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】修改菜单节点：[before_data[name]] ', '1', '1501388907', '1501389059');
INSERT INTO `pk_admin_log_tpl` VALUES ('13', 'AdminMenu_13', '删除菜单节点', ' [admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】删除菜单节点：[before_data[name]] ', '1', '1501388954', '1501389054');
INSERT INTO `pk_admin_log_tpl` VALUES ('14', 'AdminGroup_11', '新增管理组', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】新增管理组：[after_data[title]] ', '1', '1501391351', '1501391411');
INSERT INTO `pk_admin_log_tpl` VALUES ('15', 'AdminGroup_12', '修改管理组', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】修改管理组：[before_data[title]] =>[after_data[title]] ', '1', '1501391396', '1501391546');
INSERT INTO `pk_admin_log_tpl` VALUES ('16', 'AdminGroup_13', '删除管理组', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】删除管理组：[before_data[title]] ', '1', '1501391457', '1501391475');
INSERT INTO `pk_admin_log_tpl` VALUES ('17', 'AdminDatabase_11', '备份数据库', '[admin_id|admin_local_admin_id_name]【[admin_id|admin_get_group_name_by_admin_id]】备份数据库：[after_data[filename]] ', '1', '1501466854', '1501466885');

-- -----------------------------
-- Table structure for `pk_admin_menu`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_menu`;
CREATE TABLE `pk_admin_menu` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `pid` smallint(6) NOT NULL,
  `top_pid` int(10) NOT NULL,
  `controller_name` varchar(40) NOT NULL,
  `action_name` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `data` varchar(120) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `often` tinyint(1) NOT NULL DEFAULT '0',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `display` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) DEFAULT '1',
  `addtime` int(12) NOT NULL,
  `updatetime` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=723 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_admin_menu`
-- -----------------------------
INSERT INTO `pk_admin_menu` VALUES ('1', '系统设置', '0', '1', 'Setting', 'index', 'admin/Setting/index', '', '0', '0', '1', '1', '1', '0', '1500699642');
INSERT INTO `pk_admin_menu` VALUES ('2', '核心设置', '1', '1', 'Setting', 'index', 'admin/Setting/index', '', '', '0', '1', '1', '1', '0', '1500699757');
INSERT INTO `pk_admin_menu` VALUES ('6', '菜单管理', '2', '1', 'AdminMenu', 'index', 'admin/AdminMenu/index', '', '', '0', '7', '1', '1', '0', '1500295820');
INSERT INTO `pk_admin_menu` VALUES ('60', '管理员管理', '1', '1', 'Admin', 'index', 'admin/Admin/index', '', '', '0', '4', '1', '1', '0', '0');
INSERT INTO `pk_admin_menu` VALUES ('61', '管理员管理', '60', '1', 'Admin', 'index', 'admin/Admin/index', '', '', '0', '1', '1', '1', '0', '0');
INSERT INTO `pk_admin_menu` VALUES ('708', '后台首页', '695', '694', 'Index', 'index', 'admin/Index/index', '', '', '0', '255', '1', '1', '1501388338', '1501388338');
INSERT INTO `pk_admin_menu` VALUES ('148', '站点设置', '2', '1', 'Setting', 'index', 'admin/Setting/index', '', '', '0', '0', '1', '1', '0', '0');
INSERT INTO `pk_admin_menu` VALUES ('700', '系统日志', '60', '1', 'AdminLog', 'index', 'admin/AdminLog/index', '', '', '0', '255', '1', '1', '1500359322', '1500359322');
INSERT INTO `pk_admin_menu` VALUES ('718', '微信卡券', '638', '638', 'WeixinCard', 'card', 'admin/WeixinCard/card', '', '', '0', '255', '1', '1', '1502505220', '1502505220');
INSERT INTO `pk_admin_menu` VALUES ('719', '微信卡券', '718', '638', 'WeixinCard', 'card', 'admin/WeixinCard/card', '', '', '0', '255', '1', '1', '1502505255', '1502505255');
INSERT INTO `pk_admin_menu` VALUES ('720', '新建卡券', '719', '638', 'WeixinCard', 'addform_WeixinCardCash', 'admin/WeixinCard/addform_WeixinCardCash', '', '', '0', '255', '1', '1', '1502505846', '1502505846');
INSERT INTO `pk_admin_menu` VALUES ('721', '修改卡券', '719', '638', 'WeixinCard', 'editform_WeixinCard', 'admin/WeixinCard/editform_WeixinCard', '', '', '0', '255', '1', '1', '1502505958', '1502505958');
INSERT INTO `pk_admin_menu` VALUES ('722', '微信会员卡', '718', '638', 'WeixinCard', 'member_card', 'admin/WeixinCard/member_card', '', '', '0', '255', '1', '1', '1502506236', '1502506236');
INSERT INTO `pk_admin_menu` VALUES ('706', '添加管理组', '672', '1', 'AdminGroup', 'addAdminGroup', 'admin/AdminGroup/addAdminGroup', '', '', '0', '255', '1', '1', '1501379406', '1501379406');
INSERT INTO `pk_admin_menu` VALUES ('707', '修改管理组', '672', '1', 'AdminGroup', 'editAdminGroup', 'admin/AdminGroup/editAdminGroup', '', '', '0', '255', '1', '1', '1501379438', '1501379438');
INSERT INTO `pk_admin_menu` VALUES ('626', '附件上传配置', '2', '1', 'AdminUploadconfig', 'index', 'admin/AdminUploadconfig/index', '', '', '0', '255', '1', '1', '1494996069', '1500683781');
INSERT INTO `pk_admin_menu` VALUES ('638', '微信', '0', '638', 'Weixin', 'index', 'admin/Weixin/index', '', '', '0', '255', '1', '1', '1488529987', '0');
INSERT INTO `pk_admin_menu` VALUES ('639', '基本设置', '638', '638', 'Weixin', 'index', 'admin/Weixin/index', '', '', '0', '255', '1', '1', '1488530008', '0');
INSERT INTO `pk_admin_menu` VALUES ('640', '微信账号管理', '639', '638', 'Weixin', 'index', 'admin/Weixin/index', '', '', '0', '255', '1', '1', '1488530029', '0');
INSERT INTO `pk_admin_menu` VALUES ('641', '菜单管理', '639', '638', 'Weixin', 'menu', 'admin/Weixin/menu', '', '', '0', '255', '1', '1', '1488530051', '0');
INSERT INTO `pk_admin_menu` VALUES ('644', '公众号功能', '638', '638', 'Weixin', 'core', 'admin/Weixin/core', '', '', '0', '255', '1', '1', '1489555397', '0');
INSERT INTO `pk_admin_menu` VALUES ('645', '欢迎语设置', '644', '638', 'Weixin', 'editform_weixinAutoreply', 'admin/Weixin/editform_weixinAutoreply', '/trigger_type/-1', '', '0', '255', '1', '1', '1493869306', '1498621527');
INSERT INTO `pk_admin_menu` VALUES ('646', '未识别的回复', '644', '638', 'Weixin', 'editform_weixinAutoreply', 'admin/Weixin/editform_weixinAutoreply', '/trigger_type/-2', '', '0', '255', '1', '1', '1493869771', '1498621539');
INSERT INTO `pk_admin_menu` VALUES ('647', '自动回复', '644', '638', 'Weixin', 'autoreply', 'admin/Weixin/autoreply', '', '', '0', '255', '1', '1', '1489555499', '1498621552');
INSERT INTO `pk_admin_menu` VALUES ('648', '用户管理', '638', '638', 'Weixin', 'users', 'admin/Weixin/users', '', '', '0', '255', '1', '1', '1489558249', '0');
INSERT INTO `pk_admin_menu` VALUES ('649', '微信用户', '648', '638', 'Weixin', 'users', 'admin/Weixin/users', '', '', '0', '255', '1', '1', '1489558269', '0');
INSERT INTO `pk_admin_menu` VALUES ('650', '素材管理', '638', '638', 'Weixin', 'material', 'admin/Weixin/material', '', '', '0', '255', '1', '1', '1489720323', '0');
INSERT INTO `pk_admin_menu` VALUES ('651', '图文素材', '650', '638', 'Weixin', 'pictext', 'admin/Weixin/pictext', '', '', '0', '255', '1', '1', '1489720346', '0');
INSERT INTO `pk_admin_menu` VALUES ('652', '图片素材', '650', '638', 'Weixin', 'pic', 'admin/Weixin/pic', '', '', '0', '255', '1', '1', '1489720372', '0');
INSERT INTO `pk_admin_menu` VALUES ('653', '语音素材', '650', '638', 'Weixin', 'voice', 'admin/Weixin/voice', '', '', '0', '255', '1', '1', '1493857902', '0');
INSERT INTO `pk_admin_menu` VALUES ('654', '视频素材', '650', '638', 'Weixin', 'video', 'admin/Weixin/video', '', '', '0', '255', '1', '1', '1493857917', '0');
INSERT INTO `pk_admin_menu` VALUES ('655', '文本素材', '650', '638', 'Weixin', 'text', 'admin/Weixin/text', '', '', '0', '255', '1', '1', '1489720525', '0');
INSERT INTO `pk_admin_menu` VALUES ('656', '内容管理', '0', '656', 'Cms', 'category', 'admin/Cms/category', '', '', '0', '255', '1', '1', '1494921068', '1502497025');
INSERT INTO `pk_admin_menu` VALUES ('657', '基础设置', '656', '656', 'Cms', 'index', 'admin/Cms/index', '', '', '0', '255', '1', '1', '1491983307', '0');
INSERT INTO `pk_admin_menu` VALUES ('659', 'seo配置', '657', '656', 'Cms', 'seo', 'admin/Cms/seo', '', '', '0', '255', '1', '1', '1491983384', '0');
INSERT INTO `pk_admin_menu` VALUES ('660', '文章分类', '657', '656', 'Cms', 'category', 'admin/Cms/category', '', '', '0', '255', '1', '1', '1491983460', '0');
INSERT INTO `pk_admin_menu` VALUES ('661', '文章管理', '657', '656', 'Cms', 'document', 'admin/Cms/document', '', '', '0', '255', '1', '1', '1491983482', '0');
INSERT INTO `pk_admin_menu` VALUES ('662', '产品管理', '656', '656', 'Cms', 'product', 'admin/Cms/product', '', '', '0', '255', '1', '1', '1491983540', '0');
INSERT INTO `pk_admin_menu` VALUES ('663', '产品分类', '662', '656', 'Cms', 'product_category', 'admin/Cms/product_category', '', '', '0', '255', '1', '1', '1491983592', '0');
INSERT INTO `pk_admin_menu` VALUES ('664', '产品列表', '662', '656', 'Cms', 'product', 'admin/Cms/product', '', '', '0', '255', '1', '1', '1491983620', '0');
INSERT INTO `pk_admin_menu` VALUES ('665', '用户反馈', '656', '656', 'Cms', 'fromuser', 'admin/Cms/fromuser', '', '', '0', '255', '1', '1', '1492588113', '0');
INSERT INTO `pk_admin_menu` VALUES ('666', '网站留言', '665', '656', 'Cms', 'webmsg', 'admin/Cms/webmsg', '', '', '0', '255', '1', '1', '1492588137', '0');
INSERT INTO `pk_admin_menu` VALUES ('667', '维修反馈', '665', '656', 'Cms', 'servicemsg', 'admin/Cms/servicemsg', '', '', '0', '255', '1', '1', '1492588160', '0');
INSERT INTO `pk_admin_menu` VALUES ('668', '用户分组', '648', '638', 'Weixin', 'group', 'admin/Weixin/group', '', '', '0', '255', '1', '1', '1492656494', '0');
INSERT INTO `pk_admin_menu` VALUES ('669', '微信记录管理', '638', '638', 'Weixin', 'log', 'admin/Weixin/log', '', '', '0', '255', '1', '1', '1492744225', '0');
INSERT INTO `pk_admin_menu` VALUES ('670', '聊天记录管理', '669', '638', 'Weixin', 'message_log', 'admin/Weixin/message_log', '', '', '0', '255', '1', '1', '1494490788', '0');
INSERT INTO `pk_admin_menu` VALUES ('671', '微信红包记录', '673', '638', 'Weixin', 'redpack_log', 'admin/Weixin/redpack_log', '', '', '0', '255', '1', '1', '1492856571', '0');
INSERT INTO `pk_admin_menu` VALUES ('672', '管理组', '60', '1', 'AdminGroup', 'index', 'admin/AdminGroup/index', '', '', '0', '255', '1', '1', '1492837371', '1501379368');
INSERT INTO `pk_admin_menu` VALUES ('673', '微信红包管理', '638', '638', 'Weixin', 'redpack', 'admin/Weixin/redpack', '', '', '0', '255', '1', '1', '1492855087', '0');
INSERT INTO `pk_admin_menu` VALUES ('674', '微信红包', '673', '638', 'Weixin', 'redpack', 'admin/Weixin/redpack', '', '', '0', '255', '1', '1', '1494300465', '0');
INSERT INTO `pk_admin_menu` VALUES ('675', '微信充值', '673', '638', 'Weixin', 'paytowechat', 'admin/Weixin/paytowechat', '', '', '0', '255', '1', '1', '1492995130', '0');
INSERT INTO `pk_admin_menu` VALUES ('676', '公众号概况', '639', '638', 'Weixin', 'dashboard', 'admin/Weixin/dashboard', '', '', '0', '255', '1', '1', '1493094590', '1502497837');
INSERT INTO `pk_admin_menu` VALUES ('677', '微信群发', '644', '638', 'Weixin', 'masssend', 'admin/Weixin/masssend', '', '', '0', '255', '1', '1', '1493276060', '1502504892');
INSERT INTO `pk_admin_menu` VALUES ('678', '已发送群发', '644', '638', 'Weixin', 'masshistory', 'admin/Weixin/masshistory', '', '', '0', '255', '1', '1', '1493276112', '0');
INSERT INTO `pk_admin_menu` VALUES ('679', '碎片化内容', '656', '656', 'Cms', 'block', 'admin/Cms/block', '', '', '0', '255', '1', '1', '1493797526', '0');
INSERT INTO `pk_admin_menu` VALUES ('680', '区块内容分类', '679', '656', 'Cms', 'block_category', 'admin/Cms/block_category', '', '', '0', '255', '1', '1', '1493797474', '1502456731');
INSERT INTO `pk_admin_menu` VALUES ('681', '区块内容管理', '679', '656', 'Cms', 'block', 'admin/Cms/block', '', '', '0', '255', '1', '1', '1493797498', '1502456748');
INSERT INTO `pk_admin_menu` VALUES ('682', '会员管理', '0', '682', 'User', 'index', 'admin/User/index', '', '', '0', '255', '1', '1', '1495862055', '1495862055');
INSERT INTO `pk_admin_menu` VALUES ('683', '会员管理', '682', '682', 'User', 'index', 'admin/User/index', '', '', '0', '255', '1', '1', '1495862071', '1495862071');
INSERT INTO `pk_admin_menu` VALUES ('684', '会员管理', '683', '682', 'User', 'index', 'admin/User/index', '', '', '0', '255', '1', '1', '1495862095', '1495862095');
INSERT INTO `pk_admin_menu` VALUES ('685', '信件管理', '682', '682', 'Msg', 'index', 'admin/Msg/index', '', '', '0', '255', '1', '1', '1495862162', '1495862162');
INSERT INTO `pk_admin_menu` VALUES ('686', '信件模板', '685', '682', 'User', 'msg_tpl', 'admin/User/msg_tpl', '', '', '0', '255', '1', '1', '1495862191', '1495862191');
INSERT INTO `pk_admin_menu` VALUES ('687', '站内信记录', '685', '682', 'User', 'localmsg_log', 'admin/User/localmsg_log', '', '', '0', '255', '1', '1', '1495868670', '1495868751');
INSERT INTO `pk_admin_menu` VALUES ('688', '短信记录', '685', '682', 'User', 'sms_log', 'admin/User/sms_log', '', '', '0', '255', '1', '1', '1495868694', '1495868694');
INSERT INTO `pk_admin_menu` VALUES ('689', '邮寄记录', '685', '682', 'User', 'email_log', 'admin/User/email_log', '', '', '0', '255', '1', '1', '1495868713', '1495868713');
INSERT INTO `pk_admin_menu` VALUES ('690', '拓展中心', '1', '1', 'Plugin', 'index', 'admin/Plugin/index', '', '', '0', '255', '1', '1', '1496975350', '1496975432');
INSERT INTO `pk_admin_menu` VALUES ('691', '插件管理', '690', '1', 'Plugin', 'index', 'admin/Plugin/index', '', '', '0', '255', '1', '1', '1496975381', '1496975422');
INSERT INTO `pk_admin_menu` VALUES ('692', '模块管理', '690', '1', 'Module', 'index', 'admin/Module/index', '', '', '0', '255', '1', '1', '1499838423', '1499838423');
INSERT INTO `pk_admin_menu` VALUES ('693', '组件管理', '690', '1', 'Component', 'index', 'admin/Component/index', '', '', '0', '255', '1', '0', '1499843115', '1499843115');
INSERT INTO `pk_admin_menu` VALUES ('694', '首页', '0', '694', 'Index', 'index', 'admin/Index/index', '', '', '0', '0', '1', '1', '1500105506', '1501420505');
INSERT INTO `pk_admin_menu` VALUES ('695', '常用操作', '694', '694', 'Index', 'index', 'admin/Index/index', '', '', '0', '255', '1', '1', '1500105557', '1500105557');
INSERT INTO `pk_admin_menu` VALUES ('696', '清理缓存', '695', '694', 'Cache', 'index', 'admin/Cache/index', '', '', '0', '255', '1', '1', '1500122942', '1500122942');
INSERT INTO `pk_admin_menu` VALUES ('701', '日志模板', '60', '1', 'AdminLogTpl', 'index', 'admin/AdminLogTpl/index', '', '', '0', '255', '1', '1', '1500360686', '1500376609');
INSERT INTO `pk_admin_menu` VALUES ('702', '数据库管理', '1', '1', 'AdminDatabase', 'index', 'admin/AdminDatabase/index', '', '', '0', '255', '1', '1', '1500642769', '1500642769');
INSERT INTO `pk_admin_menu` VALUES ('703', '数据备份', '702', '1', 'AdminDatabase', 'index', 'admin/AdminDatabase/index', '', '', '0', '255', '1', '1', '1500642870', '1500642870');
INSERT INTO `pk_admin_menu` VALUES ('704', '数据还原', '702', '1', 'AdminDatabase', 'db_list', 'admin/AdminDatabase/db_list', '', '', '0', '255', '1', '1', '1500642898', '1500643274');
INSERT INTO `pk_admin_menu` VALUES ('705', '配置管理', '2', '1', 'AdminConfig', 'index', 'admin/AdminConfig/index', '', '', '0', '255', '1', '1', '1500699105', '1500699105');
INSERT INTO `pk_admin_menu` VALUES ('715', '组件管理', '714', '656', 'CmsProjectPinke', 'index', 'admin/CmsProjectPinke/index', '', '', '0', '255', '1', '1', '1501832440', '1501832506');
INSERT INTO `pk_admin_menu` VALUES ('714', '当前主题拓展', '656', '656', 'CmsProject', 'index', 'admin/CmsProject/index', '', '', '0', '255', '1', '1', '1501831909', '1501832137');
INSERT INTO `pk_admin_menu` VALUES ('716', '组件授权列表', '714', '656', 'CmsProjectPinke', 'components_auth_log', 'admin/CmsProjectPinke/components_auth_log', '', '', '0', '255', '1', '1', '1501833832', '1501833832');
INSERT INTO `pk_admin_menu` VALUES ('717', '组件版本', '714', '656', 'CmsProjectPinke', 'components_version', 'admin/CmsProjectPinke/components_version', '', '', '0', '255', '1', '1', '1501836776', '1501892967');

-- -----------------------------
-- Table structure for `pk_admin_module`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_module`;
CREATE TABLE `pk_admin_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(31) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(63) NOT NULL DEFAULT '' COMMENT '标题',
  `logo` varchar(63) NOT NULL DEFAULT '' COMMENT '图片图标',
  `icon` varchar(31) NOT NULL DEFAULT '' COMMENT '字体图标',
  `icon_color` varchar(7) NOT NULL DEFAULT '' COMMENT '字体图标颜色',
  `description` varchar(127) NOT NULL DEFAULT '' COMMENT '描述',
  `developer` varchar(31) NOT NULL DEFAULT '' COMMENT '开发者',
  `author` varchar(30) NOT NULL,
  `version` varchar(7) NOT NULL DEFAULT '' COMMENT '版本',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='模块功能表';

-- -----------------------------
-- Records of `pk_admin_module`
-- -----------------------------
INSERT INTO `pk_admin_module` VALUES ('1', 'Admin', '后台', '', 'fa fa-cog', '#3CA6F1', '核心系统', '浙江蓝酷网络有限公司', '直观层', '1.0.0', '1438651748', '1490167673', '0', '1');
INSERT INTO `pk_admin_module` VALUES ('2', 'User', '用户', '', 'fa fa-users', '#F9B440', '用户中心模块', '浙江蓝酷网络有限公司', '直观层', '1.0.0', '1471174771', '1471174771', '0', '1');
INSERT INTO `pk_admin_module` VALUES ('3', 'Cms', 'CMS', '', 'fa fa-newspaper-o', '#9933FF', 'CMS门户模块', '浙江蓝酷网络有限公司', '直观层', '1.0.0', '1471174779', '1484872833', '0', '1');

-- -----------------------------
-- Table structure for `pk_admin_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_plugin`;
CREATE TABLE `pk_admin_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '插件名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '插件描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text NOT NULL COMMENT '配置信息',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '插件唯一标识符',
  `admin` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `pk_admin_plugin`
-- -----------------------------
INSERT INTO `pk_admin_plugin` VALUES ('93', 'CmsProjectYuji', '语记伞业的内容管理', 'fa fa-fw fa-globe', '这个是语记伞业的网页模板主题，如果你是第三方开发者，并打算使用该模板，只需对此模板进行拓展开发', '直观层', 'http://www.lankuwangluo.com', '', '1.0.0', 'yujisanye.hottredpen.plugin', '1', '1500698606', '0', '100', '1');

-- -----------------------------
-- Table structure for `pk_admin_test_group_task`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_test_group_task`;
CREATE TABLE `pk_admin_test_group_task` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `group` int(10) NOT NULL,
  `task_id` int(10) NOT NULL,
  `next_task_id` int(10) NOT NULL,
  `model_custom_id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `module` varchar(30) NOT NULL COMMENT '模块',
  `test_scene_id` int(5) NOT NULL,
  `test_visitor_id` int(8) NOT NULL COMMENT '测试访问者id',
  `test_handle_id` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='测试的任务';


-- -----------------------------
-- Table structure for `pk_admin_test_task`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_test_task`;
CREATE TABLE `pk_admin_test_task` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `group` int(10) NOT NULL,
  `task_id` int(10) NOT NULL,
  `next_task_id` int(10) NOT NULL,
  `model_custom_id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `module` varchar(30) NOT NULL COMMENT '模块',
  `controller` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  `model_name` varchar(100) NOT NULL,
  `test_scene_id` int(5) NOT NULL,
  `test_visitor_id` int(8) NOT NULL COMMENT '测试访问者id',
  `test_handle_id` int(8) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='测试的任务';

-- -----------------------------
-- Records of `pk_admin_test_task`
-- -----------------------------
INSERT INTO `pk_admin_test_task` VALUES ('1', '1', '0', '0', '0', '添加管理员', 'Admin/Admin/createAdmin', 'Admin', 'Admin', 'createAdmin', '', '0', '0', '0', '1');
INSERT INTO `pk_admin_test_task` VALUES ('2', '0', '0', '0', '0', '修改管理员', 'Admin/Admin/saveAdmin', 'Admin', 'Admin', 'saveAdmin', '', '0', '0', '0', '1');
INSERT INTO `pk_admin_test_task` VALUES ('3', '0', '0', '0', '0', '删除管理员', 'Admin/Admin/deleteAdmin', 'Admin', 'Admin', 'deleteAdmin', '', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `pk_admin_test_task_data`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_test_task_data`;
CREATE TABLE `pk_admin_test_task_data` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `group` int(10) NOT NULL,
  `task_id` int(10) NOT NULL,
  `next_task_id` int(10) NOT NULL,
  `model_custom_id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `module` varchar(30) NOT NULL COMMENT '模块',
  `controller` varchar(100) NOT NULL,
  `action_name` varchar(100) NOT NULL,
  `model_name` varchar(100) NOT NULL,
  `test_scene_id` int(5) NOT NULL,
  `test_visitor_id` int(8) NOT NULL COMMENT '测试访问者id',
  `test_handle_id` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='测试的任务';


-- -----------------------------
-- Table structure for `pk_admin_uploadconfig`
-- -----------------------------
DROP TABLE IF EXISTS `pk_admin_uploadconfig`;
CREATE TABLE `pk_admin_uploadconfig` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `from_module` varchar(50) NOT NULL DEFAULT 'home',
  `name` varchar(50) NOT NULL,
  `typename` varchar(100) NOT NULL,
  `catid` varchar(100) NOT NULL,
  `maxsize` int(3) NOT NULL DEFAULT '1' COMMENT '最大Mb',
  `is_hold_old_data` int(1) NOT NULL DEFAULT '0' COMMENT '是否保留原数据（不压缩），配合sha1使用',
  `allowext` varchar(255) NOT NULL,
  `allowext_errorinfo` varchar(255) NOT NULL DEFAULT '图片格式不对！' COMMENT '格式不正确的错误提示',
  `save_path` varchar(255) NOT NULL DEFAULT 'data/uploads/{Ym}/{typename}/' COMMENT '保存路径',
  `sub_width` int(5) NOT NULL DEFAULT '0' COMMENT '截取宽度',
  `sub_height` int(5) NOT NULL DEFAULT '0' COMMENT '截取高度',
  `sub_type` int(2) NOT NULL DEFAULT '0' COMMENT '截取类型（1、居中裁剪，2、右上角裁剪，3左下角裁剪）',
  `scale_width` int(5) NOT NULL DEFAULT '0' COMMENT '缩放宽度',
  `scale_height` int(5) NOT NULL DEFAULT '0' COMMENT '缩放高度',
  `scale_type` int(2) NOT NULL DEFAULT '0' COMMENT '缩放类型（1、缩放不填充，2、缩放填充，3、变形缩放）',
  `upload_return_type` int(1) NOT NULL DEFAULT '0' COMMENT '上传后返回类型（-1、裁剪图替换原图0、原图返回，1，裁剪图返回，2、放缩图返回）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_admin_uploadconfig`
-- -----------------------------
INSERT INTO `pk_admin_uploadconfig` VALUES ('55', 'cms', '首页幻灯片', 'yuji_index_banner', '156', '2', '0', 'bmp|jpeg|gif|jpg|png', '图片格式不对！', 'data/uploads/{Ym}/{typename}/', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `pk_admin_uploadconfig` VALUES ('56', 'cms', '首页新品', 'yuji_index_newproduct', '172', '2', '0', 'bmp|jpeg|gif|jpg|png', '图片格式不对！', 'data/uploads/{Ym}/{typename}/', '430', '430', '1', '430', '430', '3', '1');
INSERT INTO `pk_admin_uploadconfig` VALUES ('57', 'cms', '首页产品', 'yuji_index_product', '173', '2', '0', 'bmp|jpeg|gif|jpg|png', '图片格式不对！', 'data/uploads/{Ym}/{typename}/', '340', '340', '1', '340', '340', '3', '1');
INSERT INTO `pk_admin_uploadconfig` VALUES ('58', 'cms', '首页关于我们幻灯片', 'yuji_index_about_banner', '175', '2', '0', 'bmp|jpeg|gif|jpg|png', '图片格式不对！', 'data/uploads/{Ym}/{typename}/', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `pk_admin_uploadconfig` VALUES ('59', 'cms', '新闻列表图片', 'yuji_news_cover', '194,177', '3', '0', 'bmp|jpeg|gif|jpg|png', '图片格式不对！', 'data/uploads/{Ym}/{typename}/', '500', '300', '1', '500', '300', '3', '1');
INSERT INTO `pk_admin_uploadconfig` VALUES ('60', 'cms', '产品封面图', 'yuji_product_cover', '0', '7', '0', 'bmp|jpeg|gif|jpg|png', '图片格式不对！', 'data/uploads/{Ym}/{typename}/', '430', '430', '1', '430', '430', '3', '1');
INSERT INTO `pk_admin_uploadconfig` VALUES ('65', 'common', '富文本编辑器上传图', 'kindeditor', '', '3', '0', 'bmp|jpeg|gif|jpg|png', '图片格式不对！', 'data/uploads/{Ym}/{typename}/', '0', '0', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `pk_cms_block`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_block`;
CREATE TABLE `pk_cms_block` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(12) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `list_p_data` varchar(255) NOT NULL,
  `otherdata` varchar(255) DEFAULT NULL,
  `cover_id` int(12) NOT NULL COMMENT '源文件附件id',
  `cover_ids` varchar(255) NOT NULL COMMENT '图片介绍列表附件id',
  `orderid` int(3) NOT NULL DEFAULT '100',
  `status` tinyint(1) NOT NULL,
  `addtime` int(12) NOT NULL,
  `update_time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='区块内容';

-- -----------------------------
-- Records of `pk_cms_block`
-- -----------------------------
INSERT INTO `pk_cms_block` VALUES ('1', '2', '底部文字友情链接', '', '蓝酷网络=>url=>http://www.lankuwangluo.com\r\n创品客=>url=>http://www.chuangpinke.com', '', '0', '', '100', '1', '0', '1493797667');

-- -----------------------------
-- Table structure for `pk_cms_block_category`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_block_category`;
CREATE TABLE `pk_cms_block_category` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `is_page` int(1) NOT NULL DEFAULT '0' COMMENT '是否是单内容数据',
  `sort` int(3) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='区域块分类';

-- -----------------------------
-- Records of `pk_cms_block_category`
-- -----------------------------
INSERT INTO `pk_cms_block_category` VALUES ('1', '0', '首页', 'index', '0', '11', '1', '0');
INSERT INTO `pk_cms_block_category` VALUES ('2', '1', '首页底部友情链接', 'index_friend', '0', '0', '1', '0');

-- -----------------------------
-- Table structure for `pk_cms_category`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_category`;
CREATE TABLE `pk_cms_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `deep` int(2) NOT NULL DEFAULT '1',
  `display_tpl` varchar(255) DEFAULT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '2' COMMENT '列表绑定模型',
  `model_sub` varchar(100) NOT NULL DEFAULT '' COMMENT '子文档绑定模型',
  `type` varchar(100) NOT NULL DEFAULT '2' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `is_page` int(1) NOT NULL DEFAULT '0' COMMENT '是否是单页',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=201 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `pk_cms_category`
-- -----------------------------
INSERT INTO `pk_cms_category` VALUES ('170', 'index', '首页', '0', '1', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('171', 'index_banner', '首页幻灯片', '170', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('172', 'index_newproduct', '首页新品新图', '170', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0');
INSERT INTO `pk_cms_category` VALUES ('173', 'index_product', '产品', '170', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('174', 'index_about', '首页关于我们', '170', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '1', '0', '0', '', '', '0', '1491893658', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('175', 'index_about_banner', '首页关于我们幻灯片', '170', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('176', 'news', '新闻中心', '0', '1', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '1491872587', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('177', 'news_index', '公司新闻', '176', '2', 'list', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('179', 'index_contact', '首页联系我们', '170', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '1', '0', '0', '', '', '0', '1491893650', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('180', 'product', '产品', '0', '1', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('181', 'product_umbrella', '雨伞', '180', '2', 'index', '3', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '1492149020', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('182', 'product_bumbersoll', '太阳伞', '180', '2', 'index', '2', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '1492149038', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('183', 'product_allweather', '晴雨伞', '180', '2', 'index', '1', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '1492149048', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('184', 'custom', '定制', '0', '1', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('186', 'about', '关于', '0', '1', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '1491899261', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('187', 'contact', '联系', '0', '1', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('189', 'custom_ad', '广告伞定制', '184', '2', 'index', '2', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '1', '0', '0', '', '', '0', '1491956208', '0', '0');
INSERT INTO `pk_cms_category` VALUES ('190', 'custom_person', '私人定制', '184', '2', 'index', '1', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '1', '0', '0', '', '', '0', '0', '0', '0');
INSERT INTO `pk_cms_category` VALUES ('191', 'custom_index', '定制', '184', '2', 'index', '3', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '1', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('192', 'about_index', '关于我们', '186', '2', 'index', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('193', 'contact_index', '联系我们', '187', '2', 'index', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('194', 'news_industry', '行业新闻', '176', '2', 'list', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('195', 'contact_map', '我们的位置', '187', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('196', 'yusan_index', '默认分类', '1', '1', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('197', 'service', '售后服务', '0', '1', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('198', 'service_index', '售后服务', '197', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('199', 'index_bottom', '首页底部信息', '170', '2', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');
INSERT INTO `pk_cms_category` VALUES ('200', 'index_bottom_friendlink', '底部友情链接', '199', '3', '', '0', '10', '', '', '', '', '', '', '', '2', '', '2', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '0');

-- -----------------------------
-- Table structure for `pk_cms_document`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_document`;
CREATE TABLE `pk_cms_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `gotourl` varchar(50) DEFAULT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `list_p_data` varchar(1000) NOT NULL,
  `listdata` varchar(255) DEFAULT NULL,
  `otherdata` varchar(255) DEFAULT NULL,
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `recommend_side` int(1) NOT NULL DEFAULT '0',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=400 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `pk_cms_document`
-- -----------------------------
INSERT INTO `pk_cms_document` VALUES ('374', '0', '', '关于我们幻灯片', '175', '', '关于我们幻灯片', '关于我们幻灯片', '0', '0', '0', '2', '0', '0', '438', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492844892', '1492844892', '1');
INSERT INTO `pk_cms_document` VALUES ('369', '0', '', '首页幻灯片001', '171', '', '首页幻灯片001', '首页幻灯片001', '0', '0', '0', '2', '0', '0', '392', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492243820', '1492243820', '1');
INSERT INTO `pk_cms_document` VALUES ('370', '0', '', '首页幻灯片002', '171', '', '首页幻灯片002', '首页幻灯片002', '0', '0', '0', '2', '0', '0', '393', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492243835', '1492243835', '1');
INSERT INTO `pk_cms_document` VALUES ('371', '0', '', '新品图002', '172', '', '新品图002', '新品图002', '0', '0', '0', '2', '0', '0', '356', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492147157', '1492147157', '1');
INSERT INTO `pk_cms_document` VALUES ('372', '0', '', '新品图003', '172', '', '新品图003', '新品图003', '0', '0', '0', '2', '0', '0', '357', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492147172', '1492147172', '1');
INSERT INTO `pk_cms_document` VALUES ('373', '0', '', '新品图004', '172', '', '新品图004', '新品图004', '0', '0', '0', '2', '0', '0', '358', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492147184', '1492147184', '1');
INSERT INTO `pk_cms_document` VALUES ('375', '0', '', '关于我们', '174', '', '关于我们', '关于我们', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1502610003', '1502610003', '1');
INSERT INTO `pk_cms_document` VALUES ('376', '0', '', '广告伞定制（单页）', '189', '', '广告伞定制（单页）', '广告伞定制（单页）', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492423582', '1492423582', '1');
INSERT INTO `pk_cms_document` VALUES ('377', '0', '', '私人定制（单页）', '190', '', '私人定制（单页）', '私人定制（单页）', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492423625', '1492423625', '1');
INSERT INTO `pk_cms_document` VALUES ('378', '0', '', '定制首页（单页）', '191', '', '', '', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1493779466', '1493779466', '1');
INSERT INTO `pk_cms_document` VALUES ('379', '0', '', '关于我们（单页）', '192', '', '关于我们（单页）', '关于我们（单页）', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1502610059', '1502610059', '1');
INSERT INTO `pk_cms_document` VALUES ('380', '0', '', '联系我们', '193', '', '', '', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1502609938', '1502609938', '1');
INSERT INTO `pk_cms_document` VALUES ('381', '0', '', '行业新闻', '194', '', '行业新闻', '行业新闻', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '17', '0', '0', '0', '0', '1491961663', '0', '1');
INSERT INTO `pk_cms_document` VALUES ('382', '0', '', '雨伞001', '181', '', '雨伞001', '雨伞001', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1491962152', '0', '1');
INSERT INTO `pk_cms_document` VALUES ('383', '0', '', '雨伞002', '181', '', '雨伞002', '雨伞002', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1491962171', '0', '1');
INSERT INTO `pk_cms_document` VALUES ('384', '0', '', '幻灯片003', '171', '', '幻灯片003', '幻灯片003', '0', '0', '0', '2', '0', '0', '394', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492243864', '0', '1');
INSERT INTO `pk_cms_document` VALUES ('385', '0', '', '幻灯片004', '171', '', '幻灯片004', '幻灯片004', '0', '0', '0', '2', '0', '0', '395', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492243887', '0', '1');
INSERT INTO `pk_cms_document` VALUES ('388', '0', '', '售后服务说明', '198', '', '', '', '0', '0', '0', '2', '0', '0', '0', '', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492993000', '1492993000', '1');
INSERT INTO `pk_cms_document` VALUES ('394', '0', '', '防晒伞真的有用吗 小黑伞防晒更胜一筹吗', '177', '', '', '', '0', '0', '0', '2', '0', '0', '426', '', '', '', '1', '0', '0', '48', '0', '0', '0', '0', '1492756878', '0', '1');
INSERT INTO `pk_cms_document` VALUES ('398', '0', '', '友情链接', '200', '', '', '', '0', '0', '0', '2', '0', '0', '0', '蓝酷网络=>url=>http://www.lankuwangluo.com\r\n创品客=>url=>http://www.chuangpinke.com', '', '', '1', '0', '0', '0', '0', '0', '0', '0', '1492998157', '0', '1');

-- -----------------------------
-- Table structure for `pk_cms_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_document_article`;
CREATE TABLE `pk_cms_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  `update_time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `pk_cms_document_article`
-- -----------------------------
INSERT INTO `pk_cms_document_article` VALUES ('374', '0', '&lt;p&gt;关于我们幻灯片&lt;br/&gt;&lt;/p&gt;', '', '0', '1492844892');
INSERT INTO `pk_cms_document_article` VALUES ('369', '0', '&lt;p&gt;首页幻灯片001&lt;/p&gt;', '', '0', '1492243820');
INSERT INTO `pk_cms_document_article` VALUES ('370', '0', '&lt;p&gt;首页幻灯片002&lt;br/&gt;&lt;/p&gt;', '', '0', '1492243835');
INSERT INTO `pk_cms_document_article` VALUES ('371', '0', '&lt;p&gt;新品图002&lt;/p&gt;', '', '0', '1492147157');
INSERT INTO `pk_cms_document_article` VALUES ('372', '0', '&lt;p&gt;新品图003&lt;/p&gt;', '', '0', '1492147172');
INSERT INTO `pk_cms_document_article` VALUES ('373', '0', '&lt;p&gt;新品图004&lt;/p&gt;', '', '0', '1492147184');
INSERT INTO `pk_cms_document_article` VALUES ('375', '0', '&lt;p style=&quot;text-align: center;&quot;&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: left;&quot;&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; XXXX伞业有限公司是一家专注于各类伞及其配件、雨具、休闲旅游产品的研发、设计、生产、销售为一体的私营制合伙企业。&lt;/p&gt;', '', '0', '1502610003');
INSERT INTO `pk_cms_document_article` VALUES ('376', '0', '&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/88d35158bf7fd26f4.jpeg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;广告伞定制（单页）广告伞定制（单页）广告伞定制（单页）广告伞定制（单页）广告伞定制（单页）广告伞定制（单页）广告伞定制（单页）广告伞定制（单页）广告伞定制（单页）&lt;/p&gt;', '', '0', '1492423582');
INSERT INTO `pk_cms_document_article` VALUES ('377', '0', '&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/f7e248044b5a6bbb9.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）私人定制（单页）&lt;br/&gt;&lt;/p&gt;', '', '0', '1492423625');
INSERT INTO `pk_cms_document_article` VALUES ('378', '0', '&lt;p&gt;&lt;img src=&quot;/data/uploads/201705/kindeditor/a9a177000f05a3504.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/data/uploads/201705/kindeditor/006b9569030b20c72.jpg&quot;/&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/data/uploads/201705/kindeditor/7a02083925a1dfb95.jpg&quot;/&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/data/uploads/201705/kindeditor/b1b2930630d479456.jpg&quot;/&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/data/uploads/201705/kindeditor/20ded5611be9fd504.jpg&quot;/&gt;&lt;/p&gt;', '', '0', '1493779466');
INSERT INTO `pk_cms_document_article` VALUES ('379', '0', '&lt;p&gt;&lt;span style=&quot;font-size: 14px; font-family: 宋体;&quot;&gt;&lt;br/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-size: 18px;&quot;&gt;&lt;span style=&quot;font-family: 宋体;&quot;&gt;XXX伞业有限公司专业设计、生产及销售各类伞具、雨具、休闲旅游用品等产品。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;br/&gt;&lt;p&gt;&lt;span style=&quot;font-family: Calibri; font-size: 18px;&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;', '', '0', '1502610059');
INSERT INTO `pk_cms_document_article` VALUES ('380', '0', '&lt;p&gt;&lt;strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;公司名称：&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;XXXX伞业有限公司&lt;/span&gt;&lt;br/&gt;&lt;strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;公司地址：XXXXXX&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;东路166号3楼&lt;/span&gt;&lt;br/&gt;&lt;strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;邮政编码：&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;322100&lt;/span&gt;&lt;br/&gt;&lt;strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;客服热线：123&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;-456-&lt;/span&gt;&lt;span style=&quot;font-size: 14px; line-height: 2; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51);&quot;&gt;7890&lt;/span&gt;&lt;span style=&quot;font-size: 14px; line-height: 2; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51);&quot;&gt;&lt;/span&gt;&lt;br/&gt;&lt;strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;传真号码：&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;0579-12345678&lt;/span&gt;&lt;br/&gt;&lt;strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;电子邮箱：sssss&lt;/span&gt;&lt;/strong&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;@126&lt;/span&gt;&lt;span style=&quot;font-size: 14px; font-family: &amp;#39;Microsoft YaHei&amp;#39;; color: rgb(51, 51, 51); line-height: 2;&quot;&gt;.com&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '', '0', '1502609938');
INSERT INTO `pk_cms_document_article` VALUES ('381', '0', '&lt;p&gt;行业新闻行业新闻行业新闻行业新闻行业新闻行业新闻&lt;/p&gt;', '', '0', '1491961663');
INSERT INTO `pk_cms_document_article` VALUES ('382', '0', '&lt;p&gt;雨伞001雨伞001雨伞001雨伞001雨伞001雨伞001&lt;br/&gt;&lt;/p&gt;', '', '0', '1491962152');
INSERT INTO `pk_cms_document_article` VALUES ('383', '0', '&lt;p&gt;雨伞002雨伞002雨伞002雨伞002雨伞002&lt;br/&gt;&lt;/p&gt;', '', '0', '1491962171');
INSERT INTO `pk_cms_document_article` VALUES ('384', '0', '&lt;p&gt;幻灯片003&lt;/p&gt;', '', '0', '1492243864');
INSERT INTO `pk_cms_document_article` VALUES ('385', '0', '&lt;p&gt;幻灯片004&lt;/p&gt;', '', '0', '1492243887');
INSERT INTO `pk_cms_document_article` VALUES ('388', '0', '&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: 24px;&quot;&gt;&lt;strong&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/e62e702ea9ae02678.jpg&quot;/&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: 24px;&quot;&gt;&lt;strong&gt;&lt;br/&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;br/&gt;', '', '0', '1492993001');
INSERT INTO `pk_cms_document_article` VALUES ('394', '0', '&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;防晒伞真的有用吗？炎炎夏日太阳高挂，这个时候出门的话肯定少不了做一些防晒的工作，有很多人选择防晒衣，也有一些选择防晒伞，那么防晒伞真的有用吗，下面就和小编一起去看看吧！&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;strong&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;防晒伞真的有用吗&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;在《纺织品防紫外线性能的评定》中，有标准规定：只有当样品的&lt;/span&gt;upf&lt;span style=&quot;font-family:宋体&quot;&gt;值大于&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;30&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;，并且&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;uva&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;的透过率小于&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;5%&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;时，才能称之为“防紫外线产品”，这两个条件缺一不可，这是判定一种产品是不是“防紫外线产品”的指标。其中，&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;upf&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;指的是紫外线防护系数，&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;upf&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;值越高，说明紫外线的防护效果越好，在国家标准中纺织品的&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;upf&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;值最高的标识是&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;50&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;＋，也就是&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;upf&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;＞&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;50&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;消费者在选购遮阳伞时可以先查看一下其防护等级的标识，此外也可以注意一下遮阳伞的标签上是否有国家标准的编号和防紫外线标志，另外，最好选择一些有知名度的品牌产品，切不可购买价格过于低廉的遮阳伞。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;strong&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;防晒效果好的不透光&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;一般防紫外线伞的伞面有三种处理方式&lt;/span&gt;:&lt;span style=&quot;font-family:宋体&quot;&gt;在染色过程中使用防紫外线染料&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;;&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;在伞面直接加涂防紫外线涂层&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;;&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;对伞面进行防紫外线处理，选用紫外线屏蔽剂或者紫外线吸收剂对织物进行处理加工。但这对消费者来说比较难判断是否做了处理。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;直观的判断防晒效果好坏的办法是，消费者把伞撑开对着亮光看一看，如果透光性很强，则表明这把伞抵挡紫外线的功效一般，甚至根本没有抵挡紫外线的功能。此外，从伞布本身材质来说，厚的布料比薄的布料防晒效果好&lt;/span&gt;;&lt;span style=&quot;font-family:宋体&quot;&gt;深色织物比浅色织物抗紫外线性能好&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;;&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;聚酯纤维的防晒效果比一般纤维好。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;strong&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;价高抗紫效果未必好&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;有些防晒伞价格高，与伞的面料、手柄、配件、伞架材质、制作工艺、包装以及其品牌效应都很有关系，抗紫外线效果并不是其定价的主要因素。以面料为例，目前市面上用来制作防晒伞的面料除了过去的银胶、珍珠胶以外，还有像口麦克布、银葱色丁布、碰击布等新型面料，这些新型面料不仅可以抵抗紫外线，而且又有不错的视觉效果。但是，就抗紫外线效果来说，价格相对低廉的优质银胶则为最佳。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;strong&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;银胶防紫外线佳&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;涂层处理是伞面达到防紫外线效果的一种最常见的处理方法。一般来说，银胶涂层处理的伞布防紫外线性能远远好于经过一般染整处理的面料。同时，银胶涂层在内或在外并不影响防晒的效果，最好选择银胶在里面的，不易脱落。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;如果想要挑选一把无涂层的防晒伞，需要特别关注织物密度。这实际上是非涂层面料抗紫外线性能最重要的影响因素。可通过最直接的方法来检验&lt;/span&gt;:&lt;span style=&quot;font-family:宋体&quot;&gt;一是看空隙，对着光观察撑开的伞布，若是几乎看不到空隙，或者将伞置于阳光下，影子较黑者，说明织物的紧密程度较好&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;;&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;二是看光泽，最好是选择有绸缎光泽的面料，如色丁布、麦克布等。相关样本测试结果显示，一些紧密程度好的伞布防紫外线效果比一般的涂层面料好。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;strong&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;防嗮伞不能当雨伞用&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;雨水对防晒涂层有腐蚀作用，为了保持遮阳伞的防晒性能，最好不要把遮阳伞用来防雨。如果伞面脏了，可以用质地较软的刷洗工具蘸清水轻轻刷洗，但是不能用手搓洗，清洗次数更不可过频，否则也会影响防晒效果。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;strong&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;如何挑选防晒伞&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;1&lt;span style=&quot;font-family:宋体&quot;&gt;、防晒指数&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;(&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;抗紫外线指数&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;)&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;科学知识：紫外线分&lt;/span&gt;UVB&lt;span style=&quot;font-family:宋体&quot;&gt;、&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;UVA&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;两种&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;UVB&lt;span style=&quot;font-family:宋体&quot;&gt;的伤害和防护已经得到彻底的研究，它可以使皮肤在短时间内晒伤、晒红&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;(&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;对一般人来说是&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;25&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;分钟左右&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;)&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;，现在市场上绝大多数防晒品是&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;UVB&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;型的，&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;SPF&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;就是&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;UVB&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;防护能力的标志。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;UVA&lt;span style=&quot;font-family:宋体&quot;&gt;是可怕的阳光杀手，它藉着波长比较长、穿透能力强的本领，可以穿透皮肤表层，深人真皮以下组织，可以破坏胶原蛋白、弹性纤维组织等皮肤内部的微细结构，产生皱纹和幼纹，令皮肤松弛衰老。这在医学上称之为光致老化。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;在阳光中紫外线的能量分布中，&lt;/span&gt;UVA&lt;span style=&quot;font-family:宋体&quot;&gt;是&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;UVB&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;的&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;15&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;倍，是令皮肤晒黑的主要原因。它能使皮肤里结合水的透明质酸含量减少，令皮肤干燥，加速黑色素形成，使肤色变黑，同时也是引起皮肤癌的重要原因。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;2&lt;span style=&quot;font-family:宋体&quot;&gt;、透光率&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;透光率是指透过透明或半透明体的光通量与其入射光通量的百分率。大家在判断一款伞是否防晒的时候常常会混绕两个概念：防紫外线和透光率。这两个是完全不同的，大家一定要切记。阳光中的紫外线和普通的光线波长是不同的，而且紫外线是看不到的，你如果打一把黑色的伞，会感觉伞下黑黑的，给人的感觉会觉得很防晒，但是如果你打上一把雨伞坐在那里钓上一天的鱼，你会发现你还是会被晒伤，皮肤还是会红红的甚至蜕皮。总结意见认为，透光率主要考虑到眼睛的适应程度。而防紫外线指数则是看不见的，是保护健康的重要指数啊。所以两者千万注意分别开来啊。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;3&lt;span style=&quot;font-family:宋体&quot;&gt;、伞面料&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;伞面是衡量防紫外线效果的关键。并且总结以下几点：&lt;/span&gt;⑴棉、丝、尼龙面料都不如涤纶的好&lt;span style=&quot;font-family:Calibri&quot;&gt;;&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;⑵&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;.&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;有些伞面料薄且稀疏，最好挑选织物紧密的&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;;&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;⑶&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;.&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;缎纹织物最好，然后是斜纹、平纹&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;;&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;⑷&lt;/span&gt;&lt;span style=&quot;font-family:Calibri&quot;&gt;.&lt;/span&gt;&lt;span style=&quot;font-family:宋体&quot;&gt;面料颜色越深越好。专家建议，挑伞时，不妨撑开伞看地面上的影子，影子颜色深的好。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-indent:28px&quot;&gt;&lt;span style=&quot;;font-family:宋体;font-size:14px&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '', '0', '1492756878');
INSERT INTO `pk_cms_document_article` VALUES ('398', '0', '&lt;p&gt;友情链接&lt;br/&gt;&lt;/p&gt;', '', '0', '1492998157');

-- -----------------------------
-- Table structure for `pk_cms_post`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_post`;
CREATE TABLE `pk_cms_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `qq` varchar(13) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `addtime` int(12) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `updatetime` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `pk_cms_product`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_product`;
CREATE TABLE `pk_cms_product` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL COMMENT '用户ID',
  `category_id` int(12) NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL COMMENT '关键字',
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `list_p_data` varchar(255) NOT NULL,
  `cover_id` int(12) NOT NULL COMMENT '源文件附件id',
  `cover_ids` varchar(255) NOT NULL COMMENT '图片介绍列表附件id',
  `price` decimal(12,2) NOT NULL,
  `view` int(12) NOT NULL COMMENT '浏览次数',
  `recommend_index_new` int(1) NOT NULL DEFAULT '0' COMMENT '推荐到首页新品',
  `recommend_index_product` int(1) NOT NULL DEFAULT '0' COMMENT '推荐到首页产品中',
  `url_taobao` varchar(255) DEFAULT NULL COMMENT '淘宝链接',
  `url_weixin` varchar(255) DEFAULT NULL COMMENT '微信链接',
  `status` tinyint(1) NOT NULL,
  `addtime` int(12) NOT NULL,
  `update_time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=930 DEFAULT CHARSET=utf8 COMMENT='产品';

-- -----------------------------
-- Records of `pk_cms_product`
-- -----------------------------
INSERT INTO `pk_cms_product` VALUES ('914', '0', '3', '折叠晴雨两用雨伞女韩国小清新防晒防紫外线遮阳伞 ', '晴雨两用雨伞女韩国小清新防晒防紫外线遮阳伞 ', '晴雨两用雨伞女韩国小清新防晒防紫外线遮阳伞 ', '&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/9af453c1fde5804b7.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/11e83a42b7476ab1d.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/3c01789e5d7d3eb65.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/a521c819ebb233e8d.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/66f9ce531e88b0e93.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/cbb50c30ba1158978.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/21f971f7339d3fcac.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/0a9eace657cb429b3.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/7a791b7f70254a761.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/f0bd86b5853034614.jpg&quot; style=&quot;&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '第二代雾面彩胶防晒涂层，独创防晒技术，降温呵护；4重雾面防护，隔光隔热隔紫外线，让你在夏日也能拥有冰凉体验；纳米防水技术，一甩即干；小清新糖果色新体验，将清凉的色彩融入夏天。', '0', '', '49.00', '9', '1', '0', 'https://item.taobao.com/item.htm?spm=a1z10.3-c.w4002-16237998338.37.BCRU7d&id=548385948160', '', '1', '1491967941', '1502608388');
INSERT INTO `pk_cms_product` VALUES ('915', '0', '1', '经典商务大码双人三折折叠加固防风防晒学生男遮阳晴雨伞', 'asdfasdf', 'asdfasd', '&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/af3237c3861a3344c.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/e657c09b31579eff0.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/3ee430bd8c69e5c88.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align:center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/0ad312e9eef01cce2.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align:center&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/4b746f1c0326870a5.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/8862f02688bbde0f1.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/c0f3962dae15d4ed7.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/cfdf83e9c1f40bc8d.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/e52497d69bc13d671.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/f7d763ee32e6cf0fa.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/data/uploads/201704/kindeditor/dd53fb4b82b4bb9b3.jpg&quot; style=&quot;float:none;&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '经典超大商务伞，加大伞身，360度全方位呵护，风霜雨雪，陪您一路同行。', '0', '', '39.00', '35', '1', '1', 'https://item.taobao.com/item.htm?spm=a1z10.3-c.w4002-16237998338.31.BCRU7d&id=548485527292', '', '1', '1491968003', '1502608364');
INSERT INTO `pk_cms_product` VALUES ('918', '0', '5', '小清新太阳晴雨两用雨伞女三折叠防晒防紫外线简约条纹学生伞', '三折叠防晒防紫外线简约条纹学生伞', '三折叠防晒防紫外线简约条纹学生伞', '&lt;p&gt;&lt;img src=&quot;/data/uploads/201708/kindeditor/a863afc4010e9ce37.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '防水碰击布+降温雾面彩胶；新涂层比以往质地更轻盈，薄薄一层呈现哑光质感；小清新马卡龙色调，为您的夏日带来清爽体验；提升99%紫外线阻隔率，更具备令人欣喜的防雨性能。', '105', '105', '59.00', '23', '1', '0', 'https://item.taobao.com/item.htm?spm=a1z10.3-c.w4002-16237998338.34.BCRU7d&id=548473595807', '', '1', '1493783246', '1502609538');

-- -----------------------------
-- Table structure for `pk_cms_product_category`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_product_category`;
CREATE TABLE `pk_cms_product_category` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(12) NOT NULL,
  `title` varchar(50) NOT NULL COMMENT '产品分类',
  `name` varchar(100) NOT NULL COMMENT '产品分类标示（请与文章分类的标示相统一）',
  `sort` int(3) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `update_time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='产品分类';

-- -----------------------------
-- Records of `pk_cms_product_category`
-- -----------------------------
INSERT INTO `pk_cms_product_category` VALUES ('1', '0', '雨伞', 'umbrella', '0', '1', '0');
INSERT INTO `pk_cms_product_category` VALUES ('3', '0', '太阳伞', 'bumbersoll', '0', '1', '0');
INSERT INTO `pk_cms_product_category` VALUES ('5', '0', '晴雨伞', 'allweather', '0', '1', '0');

-- -----------------------------
-- Table structure for `pk_cms_seo`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_seo`;
CREATE TABLE `pk_cms_seo` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(30) NOT NULL,
  `action` varchar(30) NOT NULL,
  `pid` int(2) NOT NULL DEFAULT '0',
  `modulename` varchar(30) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `other` int(2) DEFAULT '0',
  `replaceField` varchar(255) DEFAULT NULL,
  `title_tpl` varchar(255) DEFAULT NULL,
  `keywords_tpl` varchar(255) DEFAULT NULL,
  `description_tpl` varchar(255) DEFAULT NULL,
  `ordid` int(3) NOT NULL DEFAULT '0',
  `updatetime` int(12) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='SEO';

-- -----------------------------
-- Records of `pk_cms_seo`
-- -----------------------------
INSERT INTO `pk_cms_seo` VALUES ('1', 'index', 'index', '0', '首页', '首页', '0', '', '', '', '', '0', '0', '1');
INSERT INTO `pk_cms_seo` VALUES ('3', 'index', 'index', '1', '', '首页', '0', '', 'XXXX伞业有限公司', 'XXXX记伞业有限公司 雨伞 晴雨伞 遮阳伞', 'XXXX伞业有限公司', '0', '1502607425', '1');
INSERT INTO `pk_cms_seo` VALUES ('4', 'news', 'index', '0', '新闻资讯', '新闻资讯', '0', '', '', '', '', '0', '0', '1');
INSERT INTO `pk_cms_seo` VALUES ('5', 'news', 'index', '4', '公司新闻', '公司新闻', '0', '', '公司新闻-XXXX伞业有限公司', '公司新闻，XXXX伞业有限公司', '', '0', '1502607442', '1');
INSERT INTO `pk_cms_seo` VALUES ('6', 'news', 'index', '4', '公司新闻详情页', '公司新闻详情页', '1', '', '{info_title}-公司新闻-XXXX伞业有限公司', '{info_keywords},公司新闻,XXXX伞业有限公司', '', '0', '1502607458', '1');
INSERT INTO `pk_cms_seo` VALUES ('8', 'product', 'index', '0', '产品', '产品', '0', '', '', '', '', '0', '0', '1');
INSERT INTO `pk_cms_seo` VALUES ('9', 'product', 'index', '8', '所有产品', '所有产品', '0', '', '所有产品-XXXX伞业有限公司', '雨伞 晴雨伞 遮阳伞 太阳伞', '雨伞 晴雨伞 遮阳伞 太阳伞', '0', '1502607490', '1');
INSERT INTO `pk_cms_seo` VALUES ('10', 'product', 'umbrella', '8', '雨伞', '雨伞', '0', '', '雨伞-产品-XXXX伞业有限公司', '雨伞', '雨伞', '0', '1502607505', '1');
INSERT INTO `pk_cms_seo` VALUES ('11', 'product', 'bumbersoll', '8', '太阳伞', '太阳伞', '0', '', '太阳伞-产品-XXXX伞业有限公司', '太阳伞 ', '太阳伞 ', '0', '1502607533', '1');
INSERT INTO `pk_cms_seo` VALUES ('12', 'product', 'allweather', '8', '晴雨伞', '晴雨伞', '0', '', '晴雨伞-产品-XXXX伞业有限公司', '晴雨伞 ', '晴雨伞 ', '0', '1502607544', '1');
INSERT INTO `pk_cms_seo` VALUES ('13', 'product', 'detail', '8', '雨伞详情页', '雨伞详情页', '0', '', '{info_title}-产品-XXXX伞业有限公司', '雨伞 晴雨伞 遮阳伞 太阳伞', '雨伞 晴雨伞 遮阳伞 太阳伞', '0', '1502607557', '1');
INSERT INTO `pk_cms_seo` VALUES ('14', 'about', 'index', '0', '关于我们', '关于我们', '0', '', '', '', '', '0', '1493688115', '1');
INSERT INTO `pk_cms_seo` VALUES ('15', 'about', 'index', '14', '关于我们', '关于我们', '0', '', '关于我们-XXXX伞业有限公司 ', '关于我们,XXXX伞业有限公司 ', '关于我们,XXXX伞业有限公司 ', '0', '1502607574', '1');
INSERT INTO `pk_cms_seo` VALUES ('16', 'custom', 'index', '0', '定制', '定制', '0', '', '', '', '', '0', '1493780412', '1');
INSERT INTO `pk_cms_seo` VALUES ('18', 'contact', 'index', '0', '联系', '联系', '0', '', '', '', '', '0', '0', '1');
INSERT INTO `pk_cms_seo` VALUES ('17', 'custom', 'index', '16', '定制', '定制', '0', '', '雨伞定制-XXXX伞业有限公司 ', '雨伞定制', '雨伞定制', '0', '1502607595', '1');
INSERT INTO `pk_cms_seo` VALUES ('19', 'contact', 'index', '18', '联系', '联系', '0', '', '联系我们-XXXX伞业有限公司 ', '联系我们,XXXX伞业有限公司 ', '联系我们,XXXX伞业有限公司 ', '0', '1502607642', '1');
INSERT INTO `pk_cms_seo` VALUES ('20', 'service', 'index', '0', '服务', '服务', '0', '', '', '', '', '0', '1493780550', '1');
INSERT INTO `pk_cms_seo` VALUES ('21', 'service', 'index', '20', '售后', '售后', '0', '', '售后-XXXX伞业有限公司 ', '售后,XXXX伞业有限公司 ', '售后,XXXX伞业有限公司 ', '0', '1502607668', '1');
INSERT INTO `pk_cms_seo` VALUES ('22', 'news', 'industry', '4', '行业新闻', '行业新闻', '0', '', '行业新闻-XXXX伞业有限公司 ', '行业新闻，XXXX伞业有限公司 ', '', '0', '1502607478', '1');
INSERT INTO `pk_cms_seo` VALUES ('23', 'news', 'industry', '4', '行业新闻详情页', '行业新闻详情页', '1', '', '{info_title}-行业新闻-XXXX伞业有限公司 ', ' 	{info_keywords},行业新闻,XXXX伞业有限公司', '', '0', '1502607615', '1');

-- -----------------------------
-- Table structure for `pk_cms_service_post`
-- -----------------------------
DROP TABLE IF EXISTS `pk_cms_service_post`;
CREATE TABLE `pk_cms_service_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buyfrom` int(1) NOT NULL DEFAULT '0',
  `orderno` varchar(80) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `addtime` int(12) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `updatetime` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `pk_common_unusual`
-- -----------------------------
DROP TABLE IF EXISTS `pk_common_unusual`;
CREATE TABLE `pk_common_unusual` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `info` text NOT NULL COMMENT '信息详情',
  `extra` text,
  `addtime` varchar(40) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1880 DEFAULT CHARSET=utf8 COMMENT='记录异常信息用户调试程序';

-- -----------------------------
-- Records of `pk_common_unusual`
-- -----------------------------
INSERT INTO `pk_common_unusual` VALUES ('1105', '红包数量不足', '', '');
INSERT INTO `pk_common_unusual` VALUES ('1106', '红包数量不足', '', '');
INSERT INTO `pk_common_unusual` VALUES ('1107', '红包数量不足', '', '');
INSERT INTO `pk_common_unusual` VALUES ('1108', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493012065\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.5800000000000000710542735760100185871124267578125;s:6:\"openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"redpack_type\";s:1:\"1\";}', '');
INSERT INTO `pk_common_unusual` VALUES ('1109', '关注', '', '1493016502');
INSERT INTO `pk_common_unusual` VALUES ('1110', '关注红包开启', '', '1493016502');
INSERT INTO `pk_common_unusual` VALUES ('1111', '发送红包', '', '1493016502');
INSERT INTO `pk_common_unusual` VALUES ('1112', '发送红包返回错误', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:108:\"该用户今日操作次数超过限制，如有需要请登录微信支付商户平台更改API安全配置\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:13:\"SENDNUM_LIMIT\";s:12:\"err_code_des\";s:108:\"该用户今日操作次数超过限制，如有需要请登录微信支付商户平台更改API安全配置\";s:10:\"mch_billno\";s:16:\"static1493016801\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"total_amount\";s:3:\"100\";}', '1493016802');
INSERT INTO `pk_common_unusual` VALUES ('1113', '发送红包返回错误', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:108:\"该用户今日操作次数超过限制，如有需要请登录微信支付商户平台更改API安全配置\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:13:\"SENDNUM_LIMIT\";s:12:\"err_code_des\";s:108:\"该用户今日操作次数超过限制，如有需要请登录微信支付商户平台更改API安全配置\";s:10:\"mch_billno\";s:16:\"static1493016846\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"total_amount\";s:3:\"155\";}', '1493016846');
INSERT INTO `pk_common_unusual` VALUES ('1114', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493017615\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wJ6vM59qcDNIV5vmlkZKwc\";s:12:\"total_amount\";s:3:\"184\";s:11:\"send_listid\";s:31:\"1000041701201704243000070876263\";}', '1493017616');
INSERT INTO `pk_common_unusual` VALUES ('1115', '发送关注信息text:', '', '1493018729');
INSERT INTO `pk_common_unusual` VALUES ('1116', '发送关注信息text:', '', '1493019688');
INSERT INTO `pk_common_unusual` VALUES ('1117', '发送关注信息text:', '', '1493020379');
INSERT INTO `pk_common_unusual` VALUES ('1118', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493027848\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008BoS2kdbJ3YuKW17eTII20\";s:12:\"total_amount\";s:3:\"181\";s:11:\"send_listid\";s:31:\"1000041701201704243000095749118\";}', '1493027849');
INSERT INTO `pk_common_unusual` VALUES ('1119', '发送关注信息text:', '', '1493027849');
INSERT INTO `pk_common_unusual` VALUES ('1120', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493027815\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.6999999999999999555910790149937383830547332763671875;s:6:\"openid\";s:28:\"od870023WddlCl8WpbwSVGuUF9S4\";s:12:\"redpack_type\";s:1:\"1\";}', '1493028072');
INSERT INTO `pk_common_unusual` VALUES ('1121', '发送关注信息text:', '', '1493028072');
INSERT INTO `pk_common_unusual` VALUES ('1122', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493027815\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.8000000000000000444089209850062616169452667236328125;s:6:\"openid\";s:28:\"od8700_PPJqg97K4Qz19SwptCj_M\";s:12:\"redpack_type\";s:1:\"1\";}', '1493028424');
INSERT INTO `pk_common_unusual` VALUES ('1123', '发送关注信息text:', '', '1493028424');
INSERT INTO `pk_common_unusual` VALUES ('1124', '发送关注信息text:', '', '1493028537');
INSERT INTO `pk_common_unusual` VALUES ('1125', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493028629\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009byvM7lW_aSI-zzlSjn9sw\";s:12:\"total_amount\";s:3:\"100\";s:11:\"send_listid\";s:31:\"1000041701201704243000097723108\";}', '1493028629');
INSERT INTO `pk_common_unusual` VALUES ('1126', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493028644\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700xMHWRku11VwxfBV9gI6CIc\";s:12:\"total_amount\";s:3:\"100\";s:11:\"send_listid\";s:31:\"1000041701201704243000097600196\";}', '1493028645');
INSERT INTO `pk_common_unusual` VALUES ('1127', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029003\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002966MIIvhOxxAVWaAvsBGs\";s:12:\"total_amount\";s:3:\"150\";s:11:\"send_listid\";s:31:\"1000041701201704243000095878165\";}', '1493029004');
INSERT INTO `pk_common_unusual` VALUES ('1128', '发送关注信息text:', '', '1493029004');
INSERT INTO `pk_common_unusual` VALUES ('1129', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029185\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870023WddlCl8WpbwSVGuUF9S4\";s:12:\"total_amount\";s:3:\"166\";s:11:\"send_listid\";s:31:\"1000041701201704243000098788277\";}', '1493029185');
INSERT INTO `pk_common_unusual` VALUES ('1130', '发送关注信息text:', '', '1493029185');
INSERT INTO `pk_common_unusual` VALUES ('1131', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029218\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87005_WKDoZNFdUccuRAuuaCVE\";s:12:\"total_amount\";s:3:\"142\";s:11:\"send_listid\";s:31:\"1000041701201704243000095855147\";}', '1493029219');
INSERT INTO `pk_common_unusual` VALUES ('1132', '发送关注信息text:', '', '1493029219');
INSERT INTO `pk_common_unusual` VALUES ('1133', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029325\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700y7NqNw8aZwp6SaR3Qf07ZM\";s:12:\"total_amount\";s:3:\"126\";s:11:\"send_listid\";s:31:\"1000041701201704243000098676196\";}', '1493029326');
INSERT INTO `pk_common_unusual` VALUES ('1134', '发送关注信息text:', '', '1493029326');
INSERT INTO `pk_common_unusual` VALUES ('1135', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029392\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009uRL5dGsUIaPnbIGffrUCo\";s:12:\"total_amount\";s:3:\"121\";s:11:\"send_listid\";s:31:\"1000041701201704243000097681177\";}', '1493029393');
INSERT INTO `pk_common_unusual` VALUES ('1136', '发送关注信息text:', '', '1493029393');
INSERT INTO `pk_common_unusual` VALUES ('1137', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029462\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008Y84coZzNEMy1Ah-ylTz7A\";s:12:\"total_amount\";s:3:\"197\";s:11:\"send_listid\";s:31:\"1000041701201704243000100716140\";}', '1493029462');
INSERT INTO `pk_common_unusual` VALUES ('1138', '发送关注信息text:', '', '1493029462');
INSERT INTO `pk_common_unusual` VALUES ('1139', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029496\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003cfPszcMgXWlqZVu8djEIQ\";s:12:\"total_amount\";s:3:\"157\";s:11:\"send_listid\";s:31:\"1000041701201704243000099727111\";}', '1493029496');
INSERT INTO `pk_common_unusual` VALUES ('1140', '发送关注信息text:', '', '1493029496');
INSERT INTO `pk_common_unusual` VALUES ('1141', '发送关注信息text:', '', '1493029522');
INSERT INTO `pk_common_unusual` VALUES ('1142', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029590\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870027kV0ox2z1RF-sOMx2WLjk\";s:12:\"total_amount\";s:3:\"188\";s:11:\"send_listid\";s:31:\"1000041701201704243000099775203\";}', '1493029591');
INSERT INTO `pk_common_unusual` VALUES ('1143', '发送关注信息text:', '', '1493029591');
INSERT INTO `pk_common_unusual` VALUES ('1144', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029693\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009veJMj4_0xrAXG4hqDOSgw\";s:12:\"total_amount\";s:3:\"136\";s:11:\"send_listid\";s:31:\"1000041701201704243000097852184\";}', '1493029693');
INSERT INTO `pk_common_unusual` VALUES ('1145', '发送关注信息text:', '', '1493029694');
INSERT INTO `pk_common_unusual` VALUES ('1146', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029868\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004NSHTWqEsTaS3_88a-uKfY\";s:12:\"total_amount\";s:3:\"171\";s:11:\"send_listid\";s:31:\"1000041701201704243000097825135\";}', '1493029869');
INSERT INTO `pk_common_unusual` VALUES ('1147', '发送关注信息text:', '', '1493029869');
INSERT INTO `pk_common_unusual` VALUES ('1148', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029967\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87000qQUTr66SvmLYuWS7pfGE8\";s:12:\"total_amount\";s:3:\"144\";s:11:\"send_listid\";s:31:\"1000041701201704243000099617264\";}', '1493029968');
INSERT INTO `pk_common_unusual` VALUES ('1149', '发送关注信息text:', '', '1493029968');
INSERT INTO `pk_common_unusual` VALUES ('1150', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493029979\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87000OovHnpCtXNsx5QV9ITJJQ\";s:12:\"total_amount\";s:3:\"180\";s:11:\"send_listid\";s:31:\"1000041701201704243000098697273\";}', '1493029980');
INSERT INTO `pk_common_unusual` VALUES ('1151', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030053\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87005uQI91pU7jv150NPQ2ZFDk\";s:12:\"total_amount\";s:3:\"161\";s:11:\"send_listid\";s:31:\"1000041701201704243000099679139\";}', '1493030054');
INSERT INTO `pk_common_unusual` VALUES ('1152', '发送关注信息text:', '', '1493030054');
INSERT INTO `pk_common_unusual` VALUES ('1153', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030138\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_ZPuHvTE41bN6-GCa4e6aw\";s:12:\"total_amount\";s:3:\"120\";s:11:\"send_listid\";s:31:\"1000041701201704243000098834285\";}', '1493030138');
INSERT INTO `pk_common_unusual` VALUES ('1154', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030225\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007sGf-1lISXL3WXtHDAzF1A\";s:12:\"total_amount\";s:3:\"100\";s:11:\"send_listid\";s:31:\"1000041701201704243000098858261\";}', '1493030226');
INSERT INTO `pk_common_unusual` VALUES ('1155', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030293\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700355D7vvX5WcYi29gwlnP_g\";s:12:\"total_amount\";s:3:\"165\";s:11:\"send_listid\";s:31:\"1000041701201704243000099804150\";}', '1493030293');
INSERT INTO `pk_common_unusual` VALUES ('1156', '发送关注信息text:', '', '1493030293');
INSERT INTO `pk_common_unusual` VALUES ('1157', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030358\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007RNqKU8wpIXLKY9MXh7wi8\";s:12:\"total_amount\";s:3:\"100\";s:11:\"send_listid\";s:31:\"1000041701201704243000100763175\";}', '1493030359');
INSERT INTO `pk_common_unusual` VALUES ('1158', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030419\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002FOzKpmxk4_okhY859UBqI\";s:12:\"total_amount\";s:3:\"100\";s:11:\"send_listid\";s:31:\"1000041701201704243000098805272\";}', '1493030419');
INSERT INTO `pk_common_unusual` VALUES ('1159', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030445\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700zfCECNdG0Jo_XgrKwnglbU\";s:12:\"total_amount\";s:3:\"139\";s:11:\"send_listid\";s:31:\"1000041701201704243000100637157\";}', '1493030446');
INSERT INTO `pk_common_unusual` VALUES ('1160', '发送关注信息text:', '', '1493030446');
INSERT INTO `pk_common_unusual` VALUES ('1161', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030456\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870063adG-Hy_nzxgE74lF09Jc\";s:12:\"total_amount\";s:3:\"127\";s:11:\"send_listid\";s:31:\"1000041701201704243000101604180\";}', '1493030457');
INSERT INTO `pk_common_unusual` VALUES ('1162', '发送关注信息text:', '', '1493030457');
INSERT INTO `pk_common_unusual` VALUES ('1163', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030640\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-DMS20f6XVwNl3qX7ZkIgY\";s:12:\"total_amount\";s:3:\"185\";s:11:\"send_listid\";s:31:\"1000041701201704243000100639170\";}', '1493030641');
INSERT INTO `pk_common_unusual` VALUES ('1164', '发送关注信息text:', '', '1493030641');
INSERT INTO `pk_common_unusual` VALUES ('1165', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493030666\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870073sPLoNH_J8oFUpLMpJLq4\";s:12:\"total_amount\";s:3:\"164\";s:11:\"send_listid\";s:31:\"1000041701201704243000101733268\";}', '1493030666');
INSERT INTO `pk_common_unusual` VALUES ('1166', '发送关注信息text:', '', '1493030666');
INSERT INTO `pk_common_unusual` VALUES ('1167', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493031590\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_WYLFT2X0lQM3BpfYWG6u0\";s:12:\"total_amount\";s:3:\"139\";s:11:\"send_listid\";s:31:\"1000041701201704243000102830213\";}', '1493031591');
INSERT INTO `pk_common_unusual` VALUES ('1168', '发送关注信息text:', '', '1493031591');
INSERT INTO `pk_common_unusual` VALUES ('1169', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493032189\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87005cFrJK9K7DJPgvlugAGQVY\";s:12:\"total_amount\";s:3:\"191\";s:11:\"send_listid\";s:31:\"1000041701201704243000105733233\";}', '1493032189');
INSERT INTO `pk_common_unusual` VALUES ('1170', '发送关注信息text:', '', '1493032189');
INSERT INTO `pk_common_unusual` VALUES ('1171', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493032194\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700y-n2sDbUguW9YebhAtyVa4\";s:12:\"total_amount\";s:3:\"128\";s:11:\"send_listid\";s:31:\"1000041701201704243000105622264\";}', '1493032195');
INSERT INTO `pk_common_unusual` VALUES ('1172', '发送关注信息text:', '', '1493032195');
INSERT INTO `pk_common_unusual` VALUES ('1173', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493033708\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_Nqz4rHbH5sXe7wigtvuKI\";s:12:\"total_amount\";s:3:\"130\";s:11:\"send_listid\";s:31:\"1000041701201704243000105853154\";}', '1493033709');
INSERT INTO `pk_common_unusual` VALUES ('1174', '发送关注信息text:', '', '1493033709');
INSERT INTO `pk_common_unusual` VALUES ('1175', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493035451\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wkY8sFUR9-wcuJv3opHpos\";s:12:\"total_amount\";s:3:\"135\";s:11:\"send_listid\";s:31:\"1000041701201704243000110852250\";}', '1493035452');
INSERT INTO `pk_common_unusual` VALUES ('1176', '发送关注信息text:', '', '1493035452');
INSERT INTO `pk_common_unusual` VALUES ('1177', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493035535\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700yLT2EvSMCkz-qPhE9R8LQg\";s:12:\"total_amount\";s:3:\"130\";s:11:\"send_listid\";s:31:\"1000041701201704243000109885225\";}', '1493035536');
INSERT INTO `pk_common_unusual` VALUES ('1178', '发送关注信息text:', '', '1493035536');
INSERT INTO `pk_common_unusual` VALUES ('1179', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493040836\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700yd8SaXZxbI3qpSGWQw9alU\";s:12:\"total_amount\";s:3:\"109\";s:11:\"send_listid\";s:31:\"1000041701201704243000123794153\";}', '1493040836');
INSERT INTO `pk_common_unusual` VALUES ('1180', '发送关注信息text:', '', '1493040836');
INSERT INTO `pk_common_unusual` VALUES ('1181', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493040972\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008MeeFGgIUfLflIHZk9a3H4\";s:12:\"total_amount\";s:3:\"106\";s:11:\"send_listid\";s:31:\"1000041701201704243000124760226\";}', '1493040973');
INSERT INTO `pk_common_unusual` VALUES ('1182', '发送关注信息text:', '', '1493040973');
INSERT INTO `pk_common_unusual` VALUES ('1183', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041177\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_dUvJA508oAjUVpM1djnjI\";s:12:\"total_amount\";s:3:\"191\";s:11:\"send_listid\";s:31:\"1000041701201704243000124794228\";}', '1493041177');
INSERT INTO `pk_common_unusual` VALUES ('1184', '发送关注信息text:', '', '1493041177');
INSERT INTO `pk_common_unusual` VALUES ('1185', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041292\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004HurwGiizCViYUc26FiyUU\";s:12:\"total_amount\";s:3:\"115\";s:11:\"send_listid\";s:31:\"1000041701201704243000125712228\";}', '1493041293');
INSERT INTO `pk_common_unusual` VALUES ('1186', '发送关注信息text:', '', '1493041293');
INSERT INTO `pk_common_unusual` VALUES ('1187', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041400\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870062GsZhgk3nOrKCsahgpc48\";s:12:\"total_amount\";s:3:\"170\";s:11:\"send_listid\";s:31:\"1000041701201704243000125722134\";}', '1493041401');
INSERT INTO `pk_common_unusual` VALUES ('1188', '发送关注信息text:', '', '1493041401');
INSERT INTO `pk_common_unusual` VALUES ('1189', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041498\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-cnG5gltE1f-l9VG3UZpKo\";s:12:\"total_amount\";s:3:\"143\";s:11:\"send_listid\";s:31:\"1000041701201704243000124816231\";}', '1493041499');
INSERT INTO `pk_common_unusual` VALUES ('1190', '发送关注信息text:', '', '1493041499');
INSERT INTO `pk_common_unusual` VALUES ('1191', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041518\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007D_tpb7tCM0EwD3lHqkEIg\";s:12:\"total_amount\";s:3:\"111\";s:11:\"send_listid\";s:31:\"1000041701201704243000125704172\";}', '1493041519');
INSERT INTO `pk_common_unusual` VALUES ('1192', '发送关注信息text:', '', '1493041519');
INSERT INTO `pk_common_unusual` VALUES ('1193', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041610\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008_UTGcx9wIreaYdEdM6_r0\";s:12:\"total_amount\";s:3:\"124\";s:11:\"send_listid\";s:31:\"1000041701201704243000125758152\";}', '1493041611');
INSERT INTO `pk_common_unusual` VALUES ('1194', '发送关注信息text:', '', '1493041611');
INSERT INTO `pk_common_unusual` VALUES ('1195', '发送关注信息text:', '', '1493041611');
INSERT INTO `pk_common_unusual` VALUES ('1196', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041617\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700yZu9WCpR4uyevU1pOT7_AQ\";s:12:\"total_amount\";s:3:\"104\";s:11:\"send_listid\";s:31:\"1000041701201704243000125760135\";}', '1493041618');
INSERT INTO `pk_common_unusual` VALUES ('1197', '发送关注信息text:', '', '1493041618');
INSERT INTO `pk_common_unusual` VALUES ('1198', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041659\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87001oMExlO_j__UMOikHyuxpI\";s:12:\"total_amount\";s:3:\"145\";s:11:\"send_listid\";s:31:\"1000041701201704243000124888206\";}', '1493041659');
INSERT INTO `pk_common_unusual` VALUES ('1199', '发送关注信息text:', '', '1493041659');
INSERT INTO `pk_common_unusual` VALUES ('1200', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041660\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870008tYV7ctEu7DiXHVrvc_5s\";s:12:\"total_amount\";s:3:\"188\";s:11:\"send_listid\";s:31:\"1000041701201704243000126634120\";}', '1493041660');
INSERT INTO `pk_common_unusual` VALUES ('1201', '发送关注信息text:', '', '1493041660');
INSERT INTO `pk_common_unusual` VALUES ('1202', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041664\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87005-1bLReF3R8sZRKedhDT7M\";s:12:\"total_amount\";s:3:\"150\";s:11:\"send_listid\";s:31:\"1000041701201704243000126700118\";}', '1493041665');
INSERT INTO `pk_common_unusual` VALUES ('1203', '发送关注信息text:', '', '1493041665');
INSERT INTO `pk_common_unusual` VALUES ('1204', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041674\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700yMUnW-erqL8p3d2Nazzacg\";s:12:\"total_amount\";s:3:\"169\";s:11:\"send_listid\";s:31:\"1000041701201704243000125802101\";}', '1493041674');
INSERT INTO `pk_common_unusual` VALUES ('1205', '发送关注信息text:', '', '1493041674');
INSERT INTO `pk_common_unusual` VALUES ('1206', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041699\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_oDLm8FRL65ktKhvTKh1ek\";s:12:\"total_amount\";s:3:\"156\";s:11:\"send_listid\";s:31:\"1000041701201704243000125796121\";}', '1493041700');
INSERT INTO `pk_common_unusual` VALUES ('1207', '发送关注信息text:', '', '1493041700');
INSERT INTO `pk_common_unusual` VALUES ('1208', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041705\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002WFWg0Eil1tUBC9c5CJkG0\";s:12:\"total_amount\";s:3:\"110\";s:11:\"send_listid\";s:31:\"1000041701201704243000123795191\";}', '1493041705');
INSERT INTO `pk_common_unusual` VALUES ('1209', '发送关注信息text:', '', '1493041705');
INSERT INTO `pk_common_unusual` VALUES ('1210', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041722\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008kMiMsx5AQgNuMqtVwBVjk\";s:12:\"total_amount\";s:3:\"181\";s:11:\"send_listid\";s:31:\"1000041701201704243000126650203\";}', '1493041723');
INSERT INTO `pk_common_unusual` VALUES ('1211', '发送关注信息text:', '', '1493041723');
INSERT INTO `pk_common_unusual` VALUES ('1212', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041743\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004jVqff_O8iJItkLEpeXPc8\";s:12:\"total_amount\";s:3:\"149\";s:11:\"send_listid\";s:31:\"1000041701201704243000123849216\";}', '1493041744');
INSERT INTO `pk_common_unusual` VALUES ('1213', '发送关注信息text:', '', '1493041744');
INSERT INTO `pk_common_unusual` VALUES ('1214', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041798\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700456nh6PLWU3HRZzTBCfau8\";s:12:\"total_amount\";s:3:\"173\";s:11:\"send_listid\";s:31:\"1000041701201704243000125725106\";}', '1493041799');
INSERT INTO `pk_common_unusual` VALUES ('1215', '发送关注信息text:', '', '1493041799');
INSERT INTO `pk_common_unusual` VALUES ('1216', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041818\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-CKoGT4sbGQmWw35GSRPIU\";s:12:\"total_amount\";s:3:\"113\";s:11:\"send_listid\";s:31:\"1000041701201704243000125804124\";}', '1493041818');
INSERT INTO `pk_common_unusual` VALUES ('1217', '发送关注信息text:', '', '1493041818');
INSERT INTO `pk_common_unusual` VALUES ('1218', '发送关注信息text:', '', '1493041824');
INSERT INTO `pk_common_unusual` VALUES ('1219', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041824\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003M50N4b9iY3c6xOCJroyNs\";s:12:\"total_amount\";s:3:\"187\";s:11:\"send_listid\";s:31:\"1000041701201704243000126636130\";}', '1493041825');
INSERT INTO `pk_common_unusual` VALUES ('1220', '发送关注信息text:', '', '1493041825');
INSERT INTO `pk_common_unusual` VALUES ('1221', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041830\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007dbqpNVGZ1o_nQbQaJo_u0\";s:12:\"total_amount\";s:3:\"148\";s:11:\"send_listid\";s:31:\"1000041701201704243000125782248\";}', '1493041831');
INSERT INTO `pk_common_unusual` VALUES ('1222', '发送关注信息text:', '', '1493041831');
INSERT INTO `pk_common_unusual` VALUES ('1223', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041876\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700y97SsB3pn-9jZZM6zh44wQ\";s:12:\"total_amount\";s:3:\"194\";s:11:\"send_listid\";s:31:\"1000041701201704243000126730227\";}', '1493041877');
INSERT INTO `pk_common_unusual` VALUES ('1224', '发送关注信息text:', '', '1493041877');
INSERT INTO `pk_common_unusual` VALUES ('1225', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041896\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870091hJydvE75FXAlLnacnRRI\";s:12:\"total_amount\";s:3:\"198\";s:11:\"send_listid\";s:31:\"1000041701201704243000125806138\";}', '1493041897');
INSERT INTO `pk_common_unusual` VALUES ('1226', '发送关注信息text:', '', '1493041897');
INSERT INTO `pk_common_unusual` VALUES ('1227', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041909\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700zmT3yUPwnw0LykkNd58aNQ\";s:12:\"total_amount\";s:3:\"185\";s:11:\"send_listid\";s:31:\"1000041701201704243000124815103\";}', '1493041909');
INSERT INTO `pk_common_unusual` VALUES ('1228', '发送关注信息text:', '', '1493041909');
INSERT INTO `pk_common_unusual` VALUES ('1229', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041917\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870030gb9hcjhbmaNaqsj_OBg4\";s:12:\"total_amount\";s:3:\"192\";s:11:\"send_listid\";s:31:\"1000041701201704243000125852107\";}', '1493041918');
INSERT INTO `pk_common_unusual` VALUES ('1230', '发送关注信息text:', '', '1493041918');
INSERT INTO `pk_common_unusual` VALUES ('1231', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041933\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006NQPZE8R9RBM7HJ2TQwm0k\";s:12:\"total_amount\";s:3:\"139\";s:11:\"send_listid\";s:31:\"1000041701201704243000124896237\";}', '1493041934');
INSERT INTO `pk_common_unusual` VALUES ('1232', '发送关注信息text:', '', '1493041934');
INSERT INTO `pk_common_unusual` VALUES ('1233', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041943\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003yhRARRF-xDucJ8dfU4al4\";s:12:\"total_amount\";s:3:\"103\";s:11:\"send_listid\";s:31:\"1000041701201704243000124892240\";}', '1493041943');
INSERT INTO `pk_common_unusual` VALUES ('1234', '发送关注信息text:', '', '1493041943');
INSERT INTO `pk_common_unusual` VALUES ('1235', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041945\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006j_Pae23S_tXHrhXmu3GYQ\";s:12:\"total_amount\";s:3:\"124\";s:11:\"send_listid\";s:31:\"1000041701201704243000124856179\";}', '1493041946');
INSERT INTO `pk_common_unusual` VALUES ('1236', '发送关注信息text:', '', '1493041946');
INSERT INTO `pk_common_unusual` VALUES ('1237', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041950\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004W15cpDR8LkJ1bjdY8QAko\";s:12:\"total_amount\";s:3:\"118\";s:11:\"send_listid\";s:31:\"1000041701201704243000125824238\";}', '1493041951');
INSERT INTO `pk_common_unusual` VALUES ('1238', '发送关注信息text:', '', '1493041951');
INSERT INTO `pk_common_unusual` VALUES ('1239', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041954\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004xT5zA_ZtBdhzL2Qwkm-DM\";s:12:\"total_amount\";s:3:\"183\";s:11:\"send_listid\";s:31:\"1000041701201704243000124693142\";}', '1493041954');
INSERT INTO `pk_common_unusual` VALUES ('1240', '发送关注信息text:', '', '1493041954');
INSERT INTO `pk_common_unusual` VALUES ('1241', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493041998\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870036xO34KuKB-tm3ZQwgjW5E\";s:12:\"total_amount\";s:3:\"151\";s:11:\"send_listid\";s:31:\"1000041701201704243000123859278\";}', '1493041999');
INSERT INTO `pk_common_unusual` VALUES ('1242', '发送关注信息text:', '', '1493041999');
INSERT INTO `pk_common_unusual` VALUES ('1243', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042018\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006qVssKJ_Lsak0tUqoIh4ww\";s:12:\"total_amount\";s:3:\"146\";s:11:\"send_listid\";s:31:\"1000041701201704243000125763107\";}', '1493042019');
INSERT INTO `pk_common_unusual` VALUES ('1244', '发送关注信息text:', '', '1493042019');
INSERT INTO `pk_common_unusual` VALUES ('1245', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042027\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_kmkiouTs60KQuDDemYLXA\";s:12:\"total_amount\";s:3:\"123\";s:11:\"send_listid\";s:31:\"1000041701201704243000124797250\";}', '1493042028');
INSERT INTO `pk_common_unusual` VALUES ('1246', '发送关注信息text:', '', '1493042028');
INSERT INTO `pk_common_unusual` VALUES ('1247', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042029\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700zZ-_LOwhrFzrHRb3__kh5Q\";s:12:\"total_amount\";s:3:\"116\";s:11:\"send_listid\";s:31:\"1000041701201704243000125711225\";}', '1493042030');
INSERT INTO `pk_common_unusual` VALUES ('1248', '发送关注信息text:', '', '1493042030');
INSERT INTO `pk_common_unusual` VALUES ('1249', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042038\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-sz3lV-fSY33LtRBRxw_Lw\";s:12:\"total_amount\";s:3:\"115\";s:11:\"send_listid\";s:31:\"1000041701201704243000125836134\";}', '1493042039');
INSERT INTO `pk_common_unusual` VALUES ('1250', '发送关注信息text:', '', '1493042039');
INSERT INTO `pk_common_unusual` VALUES ('1251', '发送关注信息text:', '', '1493042055');
INSERT INTO `pk_common_unusual` VALUES ('1252', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042069\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87001CsSCT0g9kfB0ZwEn-MxRE\";s:12:\"total_amount\";s:3:\"165\";s:11:\"send_listid\";s:31:\"1000041701201704243000127608111\";}', '1493042069');
INSERT INTO `pk_common_unusual` VALUES ('1253', '发送关注信息text:', '', '1493042070');
INSERT INTO `pk_common_unusual` VALUES ('1254', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042089\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009hXox2Vomx3a_azV3sWrpM\";s:12:\"total_amount\";s:3:\"153\";s:11:\"send_listid\";s:31:\"1000041701201704243000126646269\";}', '1493042089');
INSERT INTO `pk_common_unusual` VALUES ('1255', '发送关注信息text:', '', '1493042089');
INSERT INTO `pk_common_unusual` VALUES ('1256', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042115\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-E8FjxXyKsQ-kJBVqQt7LY\";s:12:\"total_amount\";s:3:\"168\";s:11:\"send_listid\";s:31:\"1000041701201704243000124857113\";}', '1493042115');
INSERT INTO `pk_common_unusual` VALUES ('1257', '发送关注信息text:', '', '1493042115');
INSERT INTO `pk_common_unusual` VALUES ('1258', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042145\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_g-RHgmS9DVVGpegnVf8Dw\";s:12:\"total_amount\";s:3:\"112\";s:11:\"send_listid\";s:31:\"1000041701201704243000125643276\";}', '1493042146');
INSERT INTO `pk_common_unusual` VALUES ('1259', '发送关注信息text:', '', '1493042146');
INSERT INTO `pk_common_unusual` VALUES ('1260', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:42:\"更换了openid，但商户单号未更新\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:11:\"FATAL_ERROR\";s:12:\"err_code_des\";s:42:\"更换了openid，但商户单号未更新\";s:10:\"mch_billno\";s:16:\"static1493042155\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700z--Za29c4hJSHuJjvJX1PM\";s:12:\"total_amount\";s:3:\"150\";}', '1493042155');
INSERT INTO `pk_common_unusual` VALUES ('1261', '发送关注信息text:', '', '1493042155');
INSERT INTO `pk_common_unusual` VALUES ('1262', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042155\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700xpSNlO2PtvSR8JW1o6etG4\";s:12:\"total_amount\";s:3:\"177\";s:11:\"send_listid\";s:31:\"1000041701201704243000125773220\";}', '1493042156');
INSERT INTO `pk_common_unusual` VALUES ('1263', '发送关注信息text:', '', '1493042156');
INSERT INTO `pk_common_unusual` VALUES ('1264', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042156\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870004yQKaCYsvrtw2sZuLVFt8\";s:12:\"total_amount\";s:3:\"126\";s:11:\"send_listid\";s:31:\"1000041701201704243000124859209\";}', '1493042156');
INSERT INTO `pk_common_unusual` VALUES ('1265', '发送关注信息text:', '', '1493042156');
INSERT INTO `pk_common_unusual` VALUES ('1266', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042181\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87001V79m-8ICJFdNxIo0OfQnw\";s:12:\"total_amount\";s:3:\"188\";s:11:\"send_listid\";s:31:\"1000041701201704243000124821155\";}', '1493042181');
INSERT INTO `pk_common_unusual` VALUES ('1267', '发送关注信息text:', '', '1493042181');
INSERT INTO `pk_common_unusual` VALUES ('1268', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042197\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870019LyIHck-5gyshZbQwIwbU\";s:12:\"total_amount\";s:3:\"168\";s:11:\"send_listid\";s:31:\"1000041701201704243000126664270\";}', '1493042198');
INSERT INTO `pk_common_unusual` VALUES ('1269', '发送关注信息text:', '', '1493042198');
INSERT INTO `pk_common_unusual` VALUES ('1270', '发送关注信息text:', '', '1493042247');
INSERT INTO `pk_common_unusual` VALUES ('1271', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042256\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009fqt8iI0stbN5Q-i0QNWSg\";s:12:\"total_amount\";s:3:\"125\";s:11:\"send_listid\";s:31:\"1000041701201704243000126617224\";}', '1493042257');
INSERT INTO `pk_common_unusual` VALUES ('1272', '发送关注信息text:', '', '1493042257');
INSERT INTO `pk_common_unusual` VALUES ('1273', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042259\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002N1ucruuaepTJ5eyuR3Le4\";s:12:\"total_amount\";s:3:\"179\";s:11:\"send_listid\";s:31:\"1000041701201704243000125836173\";}', '1493042260');
INSERT INTO `pk_common_unusual` VALUES ('1274', '发送关注信息text:', '', '1493042260');
INSERT INTO `pk_common_unusual` VALUES ('1275', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042260\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004__Tnw9-sZ30N1ZlbvlQlI\";s:12:\"total_amount\";s:3:\"100\";s:11:\"send_listid\";s:31:\"1000041701201704243000124781197\";}', '1493042260');
INSERT INTO `pk_common_unusual` VALUES ('1276', '发送关注信息text:', '', '1493042260');
INSERT INTO `pk_common_unusual` VALUES ('1277', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:7:\"NO_AUTH\";s:12:\"err_code_des\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:10:\"mch_billno\";s:16:\"static1493042263\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870082CvXC54FiKbWJBaVqdqbA\";s:12:\"total_amount\";s:3:\"182\";}', '1493042263');
INSERT INTO `pk_common_unusual` VALUES ('1278', '发送关注信息text:', '', '1493042263');
INSERT INTO `pk_common_unusual` VALUES ('1279', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042292\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006W00iD6qET6rrO2GlBZAnA\";s:12:\"total_amount\";s:3:\"143\";s:11:\"send_listid\";s:31:\"1000041701201704243000126635120\";}', '1493042292');
INSERT INTO `pk_common_unusual` VALUES ('1280', '发送关注信息text:', '', '1493042292');
INSERT INTO `pk_common_unusual` VALUES ('1281', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042353\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700xQ6-s8rs1Zc4OBP1j1F_Rg\";s:12:\"total_amount\";s:3:\"119\";s:11:\"send_listid\";s:31:\"1000041701201704243000125797220\";}', '1493042354');
INSERT INTO `pk_common_unusual` VALUES ('1282', '发送关注信息text:', '', '1493042354');
INSERT INTO `pk_common_unusual` VALUES ('1283', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042358\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_LafoBs5qRR2ouiJTM_bKg\";s:12:\"total_amount\";s:3:\"138\";s:11:\"send_listid\";s:31:\"1000041701201704243000127658101\";}', '1493042359');
INSERT INTO `pk_common_unusual` VALUES ('1284', '发送关注信息text:', '', '1493042359');
INSERT INTO `pk_common_unusual` VALUES ('1285', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042403\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870094hYU-ZVOVBAPWLnpT74Y0\";s:12:\"total_amount\";s:3:\"196\";s:11:\"send_listid\";s:31:\"1000041701201704243000125838290\";}', '1493042404');
INSERT INTO `pk_common_unusual` VALUES ('1286', '发送关注信息text:', '', '1493042404');
INSERT INTO `pk_common_unusual` VALUES ('1287', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:7:\"NO_AUTH\";s:12:\"err_code_des\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:10:\"mch_billno\";s:16:\"static1493042413\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_yvGU5JqHTpYbi7Ar-igI4\";s:12:\"total_amount\";s:3:\"118\";}', '1493042413');
INSERT INTO `pk_common_unusual` VALUES ('1288', '发送关注信息text:', '', '1493042413');
INSERT INTO `pk_common_unusual` VALUES ('1289', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042439\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87000re--F5GIHtqEXeUxuXEW8\";s:12:\"total_amount\";s:3:\"128\";s:11:\"send_listid\";s:31:\"1000041701201704243000124843167\";}', '1493042439');
INSERT INTO `pk_common_unusual` VALUES ('1290', '发送关注信息text:', '', '1493042439');
INSERT INTO `pk_common_unusual` VALUES ('1291', '发送关注信息text:', '', '1493042470');
INSERT INTO `pk_common_unusual` VALUES ('1292', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:7:\"NO_AUTH\";s:12:\"err_code_des\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:10:\"mch_billno\";s:16:\"static1493042474\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004I5f-PrElkBV8ryhtbe9vQ\";s:12:\"total_amount\";s:3:\"166\";}', '1493042474');
INSERT INTO `pk_common_unusual` VALUES ('1293', '发送关注信息text:', '', '1493042474');
INSERT INTO `pk_common_unusual` VALUES ('1294', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042537\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700zVM_dwl-wRXRqrx_MAL7uc\";s:12:\"total_amount\";s:3:\"168\";s:11:\"send_listid\";s:31:\"1000041701201704243000126844229\";}', '1493042537');
INSERT INTO `pk_common_unusual` VALUES ('1295', '发送关注信息text:', '', '1493042537');
INSERT INTO `pk_common_unusual` VALUES ('1296', '发送关注信息text:', '', '1493042542');
INSERT INTO `pk_common_unusual` VALUES ('1297', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042544\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700xe-P4fdMLF2texq16OEiVY\";s:12:\"total_amount\";s:3:\"170\";s:11:\"send_listid\";s:31:\"1000041701201704243000124885233\";}', '1493042545');
INSERT INTO `pk_common_unusual` VALUES ('1298', '发送关注信息text:', '', '1493042545');
INSERT INTO `pk_common_unusual` VALUES ('1299', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042556\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wvgrTnhHV_AHhIOnNB0is8\";s:12:\"total_amount\";s:3:\"159\";s:11:\"send_listid\";s:31:\"1000041701201704243000128600104\";}', '1493042556');
INSERT INTO `pk_common_unusual` VALUES ('1300', '发送关注信息text:', '', '1493042556');
INSERT INTO `pk_common_unusual` VALUES ('1301', '发送关注信息text:', '', '1493042589');
INSERT INTO `pk_common_unusual` VALUES ('1302', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042622\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009qrgmCFkcN51ATDzIQ1TkE\";s:12:\"total_amount\";s:3:\"178\";s:11:\"send_listid\";s:31:\"1000041701201704243000126884101\";}', '1493042623');
INSERT INTO `pk_common_unusual` VALUES ('1303', '发送关注信息text:', '', '1493042623');
INSERT INTO `pk_common_unusual` VALUES ('1304', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042625\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700xyt4knjXI5ON5uBQUrcmKY\";s:12:\"total_amount\";s:3:\"196\";s:11:\"send_listid\";s:31:\"1000041701201704243000125679293\";}', '1493042626');
INSERT INTO `pk_common_unusual` VALUES ('1305', '发送关注信息text:', '', '1493042626');
INSERT INTO `pk_common_unusual` VALUES ('1306', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042635\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700yyWSNekspxE7O-dtnorlpY\";s:12:\"total_amount\";s:3:\"139\";s:11:\"send_listid\";s:31:\"1000041701201704243000126820167\";}', '1493042636');
INSERT INTO `pk_common_unusual` VALUES ('1307', '发送关注信息text:', '', '1493042636');
INSERT INTO `pk_common_unusual` VALUES ('1308', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042649\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008DZJ7TY0Ke9yGM4ssnN5_k\";s:12:\"total_amount\";s:3:\"144\";s:11:\"send_listid\";s:31:\"1000041701201704243000125857216\";}', '1493042649');
INSERT INTO `pk_common_unusual` VALUES ('1309', '发送关注信息text:', '', '1493042649');
INSERT INTO `pk_common_unusual` VALUES ('1310', '发送关注信息text:', '', '1493042667');
INSERT INTO `pk_common_unusual` VALUES ('1311', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042666\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700w9dseY-4DqFULt3_KCgvIc\";s:12:\"total_amount\";s:3:\"160\";s:11:\"send_listid\";s:31:\"1000041701201704243000127782213\";}', '1493042667');
INSERT INTO `pk_common_unusual` VALUES ('1312', '发送关注信息text:', '', '1493042667');
INSERT INTO `pk_common_unusual` VALUES ('1313', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042684\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870026o2_s0RRJqPNoV6-HMX8E\";s:12:\"total_amount\";s:3:\"147\";s:11:\"send_listid\";s:31:\"1000041701201704243000126854138\";}', '1493042684');
INSERT INTO `pk_common_unusual` VALUES ('1314', '发送关注信息text:', '', '1493042684');
INSERT INTO `pk_common_unusual` VALUES ('1315', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042702\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-Tjd34wGedaE_JquO4fits\";s:12:\"total_amount\";s:3:\"104\";s:11:\"send_listid\";s:31:\"1000041701201704243000126824266\";}', '1493042702');
INSERT INTO `pk_common_unusual` VALUES ('1316', '发送关注信息text:', '', '1493042702');
INSERT INTO `pk_common_unusual` VALUES ('1317', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042705\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wS90Whajmtc7I8XzPitG9E\";s:12:\"total_amount\";s:3:\"155\";s:11:\"send_listid\";s:31:\"1000041701201704243000127760143\";}', '1493042705');
INSERT INTO `pk_common_unusual` VALUES ('1318', '发送关注信息text:', '', '1493042705');
INSERT INTO `pk_common_unusual` VALUES ('1319', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042708\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009jOlooPQvS9hZV2gHMDcHY\";s:12:\"total_amount\";s:3:\"123\";s:11:\"send_listid\";s:31:\"1000041701201704243000126767112\";}', '1493042709');
INSERT INTO `pk_common_unusual` VALUES ('1320', '发送关注信息text:', '', '1493042709');
INSERT INTO `pk_common_unusual` VALUES ('1321', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:42:\"更换了openid，但商户单号未更新\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:11:\"FATAL_ERROR\";s:12:\"err_code_des\";s:42:\"更换了openid，但商户单号未更新\";s:10:\"mch_billno\";s:16:\"static1493042733\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003E6VzKelB9CwuoFCeeStNQ\";s:12:\"total_amount\";s:3:\"163\";}', '1493042734');
INSERT INTO `pk_common_unusual` VALUES ('1322', '发送关注信息text:', '', '1493042734');
INSERT INTO `pk_common_unusual` VALUES ('1323', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042733\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87005xGTLIks2wlc6a4UbSNUsg\";s:12:\"total_amount\";s:3:\"198\";s:11:\"send_listid\";s:31:\"1000041701201704243000126834158\";}', '1493042734');
INSERT INTO `pk_common_unusual` VALUES ('1324', '发送关注信息text:', '', '1493042734');
INSERT INTO `pk_common_unusual` VALUES ('1325', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042734\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700w4bHF7Hz3NgtakX72kcAkQ\";s:12:\"total_amount\";s:3:\"106\";s:11:\"send_listid\";s:31:\"1000041701201704243000127764143\";}', '1493042735');
INSERT INTO `pk_common_unusual` VALUES ('1326', '发送关注信息text:', '', '1493042735');
INSERT INTO `pk_common_unusual` VALUES ('1327', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:7:\"NO_AUTH\";s:12:\"err_code_des\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:10:\"mch_billno\";s:16:\"static1493042751\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87005X6RN1zH8Phhm2IseL90Dc\";s:12:\"total_amount\";s:3:\"148\";}', '1493042751');
INSERT INTO `pk_common_unusual` VALUES ('1328', '发送关注信息text:', '', '1493042751');
INSERT INTO `pk_common_unusual` VALUES ('1329', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042755\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002RGXSrbY4TB3xa9YeLAf-4\";s:12:\"total_amount\";s:3:\"133\";s:11:\"send_listid\";s:31:\"1000041701201704243000127746269\";}', '1493042756');
INSERT INTO `pk_common_unusual` VALUES ('1330', '发送关注信息text:', '', '1493042756');
INSERT INTO `pk_common_unusual` VALUES ('1331', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042758\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700z0yo4oWDjPtyzFporjHlz0\";s:12:\"total_amount\";s:3:\"138\";s:11:\"send_listid\";s:31:\"1000041701201704243000125789265\";}', '1493042758');
INSERT INTO `pk_common_unusual` VALUES ('1332', '发送关注信息text:', '', '1493042758');
INSERT INTO `pk_common_unusual` VALUES ('1333', '发送关注信息text:', '', '1493042775');
INSERT INTO `pk_common_unusual` VALUES ('1334', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042775\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870084oQIx-kkSGkAb1Ul2M12w\";s:12:\"total_amount\";s:3:\"173\";s:11:\"send_listid\";s:31:\"1000041701201704243000126850247\";}', '1493042776');
INSERT INTO `pk_common_unusual` VALUES ('1335', '发送关注信息text:', '', '1493042776');
INSERT INTO `pk_common_unusual` VALUES ('1336', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042794\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009bWYnenM_x8YqlmuzDyWjw\";s:12:\"total_amount\";s:3:\"106\";s:11:\"send_listid\";s:31:\"1000041701201704243000127686263\";}', '1493042795');
INSERT INTO `pk_common_unusual` VALUES ('1337', '发送关注信息text:', '', '1493042795');
INSERT INTO `pk_common_unusual` VALUES ('1338', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042799\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006cW8OtEiiSvdUpPnZHQQDY\";s:12:\"total_amount\";s:3:\"118\";s:11:\"send_listid\";s:31:\"1000041701201704243000126852156\";}', '1493042799');
INSERT INTO `pk_common_unusual` VALUES ('1339', '发送关注信息text:', '', '1493042799');
INSERT INTO `pk_common_unusual` VALUES ('1340', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493042802\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007f3g2QQ2jGMtuhzxn82LWU\";s:12:\"total_amount\";s:3:\"180\";s:11:\"send_listid\";s:31:\"1000041701201704243000127794128\";}', '1493042803');
INSERT INTO `pk_common_unusual` VALUES ('1341', '发送关注信息text:', '', '1493042803');
INSERT INTO `pk_common_unusual` VALUES ('1342', '发送关注信息text:', '', '1493042833');
INSERT INTO `pk_common_unusual` VALUES ('1343', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.2600000000000000088817841970012523233890533447265625;s:6:\"openid\";s:28:\"od87004b4n15E0jYwruqXbKryFmM\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042834');
INSERT INTO `pk_common_unusual` VALUES ('1344', '发送关注信息text:', '', '1493042834');
INSERT INTO `pk_common_unusual` VALUES ('1345', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.5500000000000000444089209850062616169452667236328125;s:6:\"openid\";s:28:\"od8700-G_EWsPe4E89Bx9KFiXIts\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042858');
INSERT INTO `pk_common_unusual` VALUES ('1346', '发送关注信息text:', '', '1493042858');
INSERT INTO `pk_common_unusual` VALUES ('1347', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.3300000000000000710542735760100185871124267578125;s:6:\"openid\";s:28:\"od87007cq6ii6d6oxEDyuBGoY3TQ\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042860');
INSERT INTO `pk_common_unusual` VALUES ('1348', '发送关注信息text:', '', '1493042860');
INSERT INTO `pk_common_unusual` VALUES ('1349', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.8600000000000000976996261670137755572795867919921875;s:6:\"openid\";s:28:\"od8700wvebtxIe3vyQYtMr4jdqzk\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042871');
INSERT INTO `pk_common_unusual` VALUES ('1350', '发送关注信息text:', '', '1493042871');
INSERT INTO `pk_common_unusual` VALUES ('1351', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.1399999999999999023003738329862244427204132080078125;s:6:\"openid\";s:28:\"od8700_wOIMmdZTrvH-HurMn0DLw\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042886');
INSERT INTO `pk_common_unusual` VALUES ('1352', '发送关注信息text:', '', '1493042886');
INSERT INTO `pk_common_unusual` VALUES ('1353', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.5800000000000000710542735760100185871124267578125;s:6:\"openid\";s:28:\"od8700w4BrYnxhaGjjEBUyfjUtv8\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042898');
INSERT INTO `pk_common_unusual` VALUES ('1354', '发送关注信息text:', '', '1493042898');
INSERT INTO `pk_common_unusual` VALUES ('1355', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.560000000000000053290705182007513940334320068359375;s:6:\"openid\";s:28:\"od87008HeAYlcfcU9_Kn7G1kIOUY\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042905');
INSERT INTO `pk_common_unusual` VALUES ('1356', '发送关注信息text:', '', '1493042905');
INSERT INTO `pk_common_unusual` VALUES ('1357', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.350000000000000088817841970012523233890533447265625;s:6:\"openid\";s:28:\"od870025usaBmfVn6F_-ch6ds7Ic\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042914');
INSERT INTO `pk_common_unusual` VALUES ('1358', '发送关注信息text:', '', '1493042914');
INSERT INTO `pk_common_unusual` VALUES ('1359', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.2600000000000000088817841970012523233890533447265625;s:6:\"openid\";s:28:\"od8700z4zZ5Su2AO_9A3XxCDJ7E0\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042919');
INSERT INTO `pk_common_unusual` VALUES ('1360', '发送关注信息text:', '', '1493042919');
INSERT INTO `pk_common_unusual` VALUES ('1361', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.5100000000000000088817841970012523233890533447265625;s:6:\"openid\";s:28:\"od87000HZ7D7behDkhOqOIKZhgE0\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042926');
INSERT INTO `pk_common_unusual` VALUES ('1362', '发送关注信息text:', '', '1493042926');
INSERT INTO `pk_common_unusual` VALUES ('1363', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.79000000000000003552713678800500929355621337890625;s:6:\"openid\";s:28:\"od87007juWAJ0w0BAUAJ7P0HNvYU\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042955');
INSERT INTO `pk_common_unusual` VALUES ('1364', '发送关注信息text:', '', '1493042955');
INSERT INTO `pk_common_unusual` VALUES ('1365', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.149999999999999911182158029987476766109466552734375;s:6:\"openid\";s:28:\"od87000nHffvNEHugFgducqeMnGg\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042969');
INSERT INTO `pk_common_unusual` VALUES ('1366', '发送关注信息text:', '', '1493042969');
INSERT INTO `pk_common_unusual` VALUES ('1367', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.95999999999999996447286321199499070644378662109375;s:6:\"openid\";s:28:\"od870046Ea_hZIhAuhbFRBAM9GTg\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042969');
INSERT INTO `pk_common_unusual` VALUES ('1368', '发送关注信息text:', '', '1493042969');
INSERT INTO `pk_common_unusual` VALUES ('1369', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.729999999999999982236431605997495353221893310546875;s:6:\"openid\";s:28:\"od87000v_tfr9DwJl95dbmw_GvAY\";s:12:\"redpack_type\";s:1:\"1\";}', '1493042975');
INSERT INTO `pk_common_unusual` VALUES ('1370', '发送关注信息text:', '', '1493042975');
INSERT INTO `pk_common_unusual` VALUES ('1371', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.3300000000000000710542735760100185871124267578125;s:6:\"openid\";s:28:\"od8700ylH4Kpjg4bLTRAPQpgPLSQ\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043004');
INSERT INTO `pk_common_unusual` VALUES ('1372', '发送关注信息text:', '', '1493043004');
INSERT INTO `pk_common_unusual` VALUES ('1373', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.04000000000000003552713678800500929355621337890625;s:6:\"openid\";s:28:\"od8700_bfkWoD28lVWIT0TIZ99x4\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043026');
INSERT INTO `pk_common_unusual` VALUES ('1374', '发送关注信息text:', '', '1493043026');
INSERT INTO `pk_common_unusual` VALUES ('1375', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.37000000000000010658141036401502788066864013671875;s:6:\"openid\";s:28:\"od87008Jqc9bqWWegFfMCrr-wV1I\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043050');
INSERT INTO `pk_common_unusual` VALUES ('1376', '发送关注信息text:', '', '1493043050');
INSERT INTO `pk_common_unusual` VALUES ('1377', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.8400000000000000799360577730112709105014801025390625;s:6:\"openid\";s:28:\"od87006bER0XCdhvZWU90-rk4L6o\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043061');
INSERT INTO `pk_common_unusual` VALUES ('1378', '发送关注信息text:', '', '1493043061');
INSERT INTO `pk_common_unusual` VALUES ('1379', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.729999999999999982236431605997495353221893310546875;s:6:\"openid\";s:28:\"od87006Gd_-NX6514WJ25E0uBy9w\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043081');
INSERT INTO `pk_common_unusual` VALUES ('1380', '发送关注信息text:', '', '1493043081');
INSERT INTO `pk_common_unusual` VALUES ('1381', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.4899999999999999911182158029987476766109466552734375;s:6:\"openid\";s:28:\"od87002ayLxho1YL64_EjiBS_pi0\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043087');
INSERT INTO `pk_common_unusual` VALUES ('1382', '发送关注信息text:', '', '1493043087');
INSERT INTO `pk_common_unusual` VALUES ('1383', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.3300000000000000710542735760100185871124267578125;s:6:\"openid\";s:28:\"od87000cxT4Pr-MYitIWmkhF-iio\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043094');
INSERT INTO `pk_common_unusual` VALUES ('1384', '发送关注信息text:', '', '1493043094');
INSERT INTO `pk_common_unusual` VALUES ('1385', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.25;s:6:\"openid\";s:28:\"od87007juWAJ0w0BAUAJ7P0HNvYU\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043100');
INSERT INTO `pk_common_unusual` VALUES ('1386', '发送关注信息text:', '', '1493043100');
INSERT INTO `pk_common_unusual` VALUES ('1387', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.979999999999999982236431605997495353221893310546875;s:6:\"openid\";s:28:\"od87004b4n15E0jYwruqXbKryFmM\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043104');
INSERT INTO `pk_common_unusual` VALUES ('1388', '发送关注信息text:', '', '1493043104');
INSERT INTO `pk_common_unusual` VALUES ('1389', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.9099999999999999200639422269887290894985198974609375;s:6:\"openid\";s:28:\"od870008RNDsJdSFbNQ1a-yF5RRI\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043140');
INSERT INTO `pk_common_unusual` VALUES ('1390', '发送关注信息text:', '', '1493043140');
INSERT INTO `pk_common_unusual` VALUES ('1391', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.70999999999999996447286321199499070644378662109375;s:6:\"openid\";s:28:\"od87004vhdEWecM1un334uMcuLjs\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043189');
INSERT INTO `pk_common_unusual` VALUES ('1392', '发送关注信息text:', '', '1493043189');
INSERT INTO `pk_common_unusual` VALUES ('1393', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.8200000000000000621724893790087662637233734130859375;s:6:\"openid\";s:28:\"od8700_P9D1EuLpntiwLOGPUig2g\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043249');
INSERT INTO `pk_common_unusual` VALUES ('1394', '发送关注信息text:', '', '1493043249');
INSERT INTO `pk_common_unusual` VALUES ('1395', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.060000000000000053290705182007513940334320068359375;s:6:\"openid\";s:28:\"od87004JTjATVrShdYkBK-xT_v_E\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043266');
INSERT INTO `pk_common_unusual` VALUES ('1396', '发送关注信息text:', '', '1493043266');
INSERT INTO `pk_common_unusual` VALUES ('1397', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.1699999999999999289457264239899814128875732421875;s:6:\"openid\";s:28:\"od8700-WIWu-sHRmHlaCw8Zc3oFE\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043302');
INSERT INTO `pk_common_unusual` VALUES ('1398', '发送关注信息text:', '', '1493043302');
INSERT INTO `pk_common_unusual` VALUES ('1399', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.6999999999999999555910790149937383830547332763671875;s:6:\"openid\";s:28:\"od8700_suACK-iJsQaPI2Xcd0D2A\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043309');
INSERT INTO `pk_common_unusual` VALUES ('1400', '发送关注信息text:', '', '1493043309');
INSERT INTO `pk_common_unusual` VALUES ('1401', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.79000000000000003552713678800500929355621337890625;s:6:\"openid\";s:28:\"od87002M19UAWWmA0ridKBW3l9jY\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043353');
INSERT INTO `pk_common_unusual` VALUES ('1402', '发送关注信息text:', '', '1493043353');
INSERT INTO `pk_common_unusual` VALUES ('1403', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.3899999999999999023003738329862244427204132080078125;s:6:\"openid\";s:28:\"od8700wvebtxIe3vyQYtMr4jdqzk\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043360');
INSERT INTO `pk_common_unusual` VALUES ('1404', '发送关注信息text:', '', '1493043360');
INSERT INTO `pk_common_unusual` VALUES ('1405', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.5800000000000000710542735760100185871124267578125;s:6:\"openid\";s:28:\"od8700zeY5ffneXQk6dFOJIpmWyQ\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043406');
INSERT INTO `pk_common_unusual` VALUES ('1406', '发送关注信息text:', '', '1493043406');
INSERT INTO `pk_common_unusual` VALUES ('1407', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.9199999999999999289457264239899814128875732421875;s:6:\"openid\";s:28:\"od8700-oTSXDQKRjNIHi5bVqTNPg\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043456');
INSERT INTO `pk_common_unusual` VALUES ('1408', '发送关注信息text:', '', '1493043456');
INSERT INTO `pk_common_unusual` VALUES ('1409', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.29000000000000003552713678800500929355621337890625;s:6:\"openid\";s:28:\"od8700xFZ1_KqQOZyBWrvz6jVZys\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043460');
INSERT INTO `pk_common_unusual` VALUES ('1410', '发送关注信息text:', '', '1493043460');
INSERT INTO `pk_common_unusual` VALUES ('1411', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.5700000000000000621724893790087662637233734130859375;s:6:\"openid\";s:28:\"od870065FXY3upShTrGSweF0z4pI\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043462');
INSERT INTO `pk_common_unusual` VALUES ('1412', '发送关注信息text:', '', '1493043462');
INSERT INTO `pk_common_unusual` VALUES ('1413', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.0500000000000000444089209850062616169452667236328125;s:6:\"openid\";s:28:\"od8700-9MRmThhA47t1Rq7tcoHBM\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043465');
INSERT INTO `pk_common_unusual` VALUES ('1414', '发送关注信息text:', '', '1493043465');
INSERT INTO `pk_common_unusual` VALUES ('1415', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.479999999999999982236431605997495353221893310546875;s:6:\"openid\";s:28:\"od8700ysu4EY3Zt3J9UewmCKSl5g\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043492');
INSERT INTO `pk_common_unusual` VALUES ('1416', '发送关注信息text:', '', '1493043492');
INSERT INTO `pk_common_unusual` VALUES ('1417', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.37000000000000010658141036401502788066864013671875;s:6:\"openid\";s:28:\"od87009YPx3qlvzR_Y0isXcb9EHU\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043528');
INSERT INTO `pk_common_unusual` VALUES ('1418', '发送关注信息text:', '', '1493043528');
INSERT INTO `pk_common_unusual` VALUES ('1419', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.2600000000000000088817841970012523233890533447265625;s:6:\"openid\";s:28:\"od870018ojTppV33Q4aHIitGVpCM\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043539');
INSERT INTO `pk_common_unusual` VALUES ('1420', '发送关注信息text:', '', '1493043539');
INSERT INTO `pk_common_unusual` VALUES ('1421', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.149999999999999911182158029987476766109466552734375;s:6:\"openid\";s:28:\"od87004qMqmcxnuVZgygSl0Ak0Rw\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043539');
INSERT INTO `pk_common_unusual` VALUES ('1422', '发送关注信息text:', '', '1493043539');
INSERT INTO `pk_common_unusual` VALUES ('1423', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.7600000000000000088817841970012523233890533447265625;s:6:\"openid\";s:28:\"od87009BfrBqc1L0CM80VyKmdbPw\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043569');
INSERT INTO `pk_common_unusual` VALUES ('1424', '发送关注信息text:', '', '1493043569');
INSERT INTO `pk_common_unusual` VALUES ('1425', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.3400000000000000799360577730112709105014801025390625;s:6:\"openid\";s:28:\"od8700wtjzeHIwgvYWqqyXt3_qoA\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043570');
INSERT INTO `pk_common_unusual` VALUES ('1426', '发送关注信息text:', '', '1493043570');
INSERT INTO `pk_common_unusual` VALUES ('1427', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.5900000000000000799360577730112709105014801025390625;s:6:\"openid\";s:28:\"od8700wJs-bCbRPOvxDHvZ_Foefs\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043586');
INSERT INTO `pk_common_unusual` VALUES ('1428', '发送关注信息text:', '', '1493043586');
INSERT INTO `pk_common_unusual` VALUES ('1429', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.6100000000000000976996261670137755572795867919921875;s:6:\"openid\";s:28:\"od8700xFZ1_KqQOZyBWrvz6jVZys\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043596');
INSERT INTO `pk_common_unusual` VALUES ('1430', '发送关注信息text:', '', '1493043596');
INSERT INTO `pk_common_unusual` VALUES ('1431', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.95999999999999996447286321199499070644378662109375;s:6:\"openid\";s:28:\"od87002ayLxho1YL64_EjiBS_pi0\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043622');
INSERT INTO `pk_common_unusual` VALUES ('1432', '发送关注信息text:', '', '1493043622');
INSERT INTO `pk_common_unusual` VALUES ('1433', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.2800000000000000266453525910037569701671600341796875;s:6:\"openid\";s:28:\"od87008Edd4jUCrxSbNS-fKYKoW0\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043645');
INSERT INTO `pk_common_unusual` VALUES ('1434', '发送关注信息text:', '', '1493043645');
INSERT INTO `pk_common_unusual` VALUES ('1435', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.1599999999999999200639422269887290894985198974609375;s:6:\"openid\";s:28:\"od8700-WIWu-sHRmHlaCw8Zc3oFE\";s:12:\"redpack_type\";s:1:\"1\";}', '1493043688');
INSERT INTO `pk_common_unusual` VALUES ('1436', '发送关注信息text:', '', '1493043688');
INSERT INTO `pk_common_unusual` VALUES ('1437', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.020000000000000017763568394002504646778106689453125;s:6:\"openid\";s:28:\"od87001htcZx9vO0WeJpeUPkbASg\";s:12:\"redpack_type\";s:1:\"1\";}', '1493044030');
INSERT INTO `pk_common_unusual` VALUES ('1438', '发送关注信息text:', '', '1493044030');
INSERT INTO `pk_common_unusual` VALUES ('1439', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.850000000000000088817841970012523233890533447265625;s:6:\"openid\";s:28:\"od8700xZpMXrMomsdRYHkx_Uu9FY\";s:12:\"redpack_type\";s:1:\"1\";}', '1493044062');
INSERT INTO `pk_common_unusual` VALUES ('1440', '发送关注信息text:', '', '1493044062');
INSERT INTO `pk_common_unusual` VALUES ('1441', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.37000000000000010658141036401502788066864013671875;s:6:\"openid\";s:28:\"od87008x9GOljSeYAsTFoDzGatoM\";s:12:\"redpack_type\";s:1:\"1\";}', '1493044076');
INSERT INTO `pk_common_unusual` VALUES ('1442', '发送关注信息text:', '', '1493044076');
INSERT INTO `pk_common_unusual` VALUES ('1443', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.8000000000000000444089209850062616169452667236328125;s:6:\"openid\";s:28:\"od8700_pZyzTqbHCuJinCEgrThoE\";s:12:\"redpack_type\";s:1:\"1\";}', '1493044078');
INSERT INTO `pk_common_unusual` VALUES ('1444', '发送关注信息text:', '', '1493044078');
INSERT INTO `pk_common_unusual` VALUES ('1445', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493028796\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.0700000000000000621724893790087662637233734130859375;s:6:\"openid\";s:28:\"od87003RvsRl7D_BKDc8RhO8qi64\";s:12:\"redpack_type\";s:1:\"1\";}', '1493044110');
INSERT INTO `pk_common_unusual` VALUES ('1446', '发送关注信息text:', '', '1493044110');
INSERT INTO `pk_common_unusual` VALUES ('1447', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044258\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870093xw9ucBr6Uu6jlNQhUfRc\";s:12:\"total_amount\";s:3:\"156\";s:11:\"send_listid\";s:31:\"1000041701201704243000129675109\";}', '1493044258');
INSERT INTO `pk_common_unusual` VALUES ('1448', '发送关注信息text:', '', '1493044258');
INSERT INTO `pk_common_unusual` VALUES ('1449', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044267\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007HaWTtJfixdWhBDlMV91T4\";s:12:\"total_amount\";s:3:\"144\";s:11:\"send_listid\";s:31:\"1000041701201704243000128753179\";}', '1493044267');
INSERT INTO `pk_common_unusual` VALUES ('1450', '发送关注信息text:', '', '1493044267');
INSERT INTO `pk_common_unusual` VALUES ('1451', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044304\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008x9GOljSeYAsTFoDzGatoM\";s:12:\"total_amount\";s:3:\"158\";s:11:\"send_listid\";s:31:\"1000041701201704243000128795239\";}', '1493044305');
INSERT INTO `pk_common_unusual` VALUES ('1452', '发送关注信息text:', '', '1493044305');
INSERT INTO `pk_common_unusual` VALUES ('1453', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044312\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wrj4h4PxZc1mrphT8BOqX0\";s:12:\"total_amount\";s:3:\"162\";s:11:\"send_listid\";s:31:\"1000041701201704243000128789147\";}', '1493044313');
INSERT INTO `pk_common_unusual` VALUES ('1454', '发送关注信息text:', '', '1493044313');
INSERT INTO `pk_common_unusual` VALUES ('1455', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044344\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87005dfqjNGNW7JlajVrvRnQMc\";s:12:\"total_amount\";s:3:\"194\";s:11:\"send_listid\";s:31:\"1000041701201704243000129780188\";}', '1493044344');
INSERT INTO `pk_common_unusual` VALUES ('1456', '发送关注信息text:', '', '1493044344');
INSERT INTO `pk_common_unusual` VALUES ('1457', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044428\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003epUqEa7U4jyiOSS3k6WX4\";s:12:\"total_amount\";s:3:\"155\";s:11:\"send_listid\";s:31:\"1000041701201704243000129635147\";}', '1493044429');
INSERT INTO `pk_common_unusual` VALUES ('1458', '发送关注信息text:', '', '1493044429');
INSERT INTO `pk_common_unusual` VALUES ('1459', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044464\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870081-XFHr5k-9cdcPPoL3OQw\";s:12:\"total_amount\";s:3:\"191\";s:11:\"send_listid\";s:31:\"1000041701201704243000130712171\";}', '1493044464');
INSERT INTO `pk_common_unusual` VALUES ('1460', '发送关注信息text:', '', '1493044464');
INSERT INTO `pk_common_unusual` VALUES ('1461', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044515\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009ULlt3FUkofZq7DYCPy-8c\";s:12:\"total_amount\";s:3:\"196\";s:11:\"send_listid\";s:31:\"1000041701201704243000130682254\";}', '1493044516');
INSERT INTO `pk_common_unusual` VALUES ('1462', '发送关注信息text:', '', '1493044516');
INSERT INTO `pk_common_unusual` VALUES ('1463', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044598\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-9MRmThhA47t1Rq7tcoHBM\";s:12:\"total_amount\";s:3:\"185\";s:11:\"send_listid\";s:31:\"1000041701201704243000131602150\";}', '1493044599');
INSERT INTO `pk_common_unusual` VALUES ('1464', '发送关注信息text:', '', '1493044599');
INSERT INTO `pk_common_unusual` VALUES ('1465', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044608\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-oUwodjhAQn5t4YOArulms\";s:12:\"total_amount\";s:3:\"188\";s:11:\"send_listid\";s:31:\"1000041701201704243000128881147\";}', '1493044609');
INSERT INTO `pk_common_unusual` VALUES ('1466', '发送关注信息text:', '', '1493044609');
INSERT INTO `pk_common_unusual` VALUES ('1467', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044672\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004vhdEWecM1un334uMcuLjs\";s:12:\"total_amount\";s:3:\"173\";s:11:\"send_listid\";s:31:\"1000041701201704243000130609135\";}', '1493044673');
INSERT INTO `pk_common_unusual` VALUES ('1468', '发送关注信息text:', '', '1493044673');
INSERT INTO `pk_common_unusual` VALUES ('1469', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044689\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007vX2FFtUqV8a3Dnki0ak5s\";s:12:\"total_amount\";s:3:\"144\";s:11:\"send_listid\";s:31:\"1000041701201704243000130840108\";}', '1493044689');
INSERT INTO `pk_common_unusual` VALUES ('1470', '发送关注信息text:', '', '1493044689');
INSERT INTO `pk_common_unusual` VALUES ('1471', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044720\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870087_RZx7nXwsoten78z1c3U\";s:12:\"total_amount\";s:3:\"189\";s:11:\"send_listid\";s:31:\"1000041701201704243000130818134\";}', '1493044721');
INSERT INTO `pk_common_unusual` VALUES ('1472', '发送关注信息text:', '', '1493044721');
INSERT INTO `pk_common_unusual` VALUES ('1473', '发送关注信息text:', '', '1493044721');
INSERT INTO `pk_common_unusual` VALUES ('1474', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044804\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700yCeXkQjxOB70vB9jzkwA2U\";s:12:\"total_amount\";s:3:\"171\";s:11:\"send_listid\";s:31:\"1000041701201704243000131660106\";}', '1493044805');
INSERT INTO `pk_common_unusual` VALUES ('1475', '发送关注信息text:', '', '1493044805');
INSERT INTO `pk_common_unusual` VALUES ('1476', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044818\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870071DDxHq2LkuUus33vyPhX4\";s:12:\"total_amount\";s:3:\"172\";s:11:\"send_listid\";s:31:\"1000041701201704243000129775157\";}', '1493044819');
INSERT INTO `pk_common_unusual` VALUES ('1477', '发送关注信息text:', '', '1493044819');
INSERT INTO `pk_common_unusual` VALUES ('1478', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044851\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700z80yN9uVw5Q6gTsn6n_FKM\";s:12:\"total_amount\";s:3:\"180\";s:11:\"send_listid\";s:31:\"1000041701201704243000131634250\";}', '1493044852');
INSERT INTO `pk_common_unusual` VALUES ('1479', '发送关注信息text:', '', '1493044852');
INSERT INTO `pk_common_unusual` VALUES ('1480', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044953\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002-ICc-ee3MPBy8-OAPYahY\";s:12:\"total_amount\";s:3:\"142\";s:11:\"send_listid\";s:31:\"1000041701201704243000130788286\";}', '1493044953');
INSERT INTO `pk_common_unusual` VALUES ('1481', '发送关注信息text:', '', '1493044953');
INSERT INTO `pk_common_unusual` VALUES ('1482', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493044998\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009L9OO171R6l4Nnq3EKKen4\";s:12:\"total_amount\";s:3:\"174\";s:11:\"send_listid\";s:31:\"1000041701201704243000130848237\";}', '1493044999');
INSERT INTO `pk_common_unusual` VALUES ('1483', '发送关注信息text:', '', '1493044999');
INSERT INTO `pk_common_unusual` VALUES ('1484', '发送关注信息text:', '', '1493045044');
INSERT INTO `pk_common_unusual` VALUES ('1485', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493045074\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700x8hcsLZHSLbVdoWFsq98lo\";s:12:\"total_amount\";s:3:\"115\";s:11:\"send_listid\";s:31:\"1000041701201704243000131702293\";}', '1493045074');
INSERT INTO `pk_common_unusual` VALUES ('1486', '发送关注信息text:', '', '1493045074');
INSERT INTO `pk_common_unusual` VALUES ('1487', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493045147\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_pZyzTqbHCuJinCEgrThoE\";s:12:\"total_amount\";s:3:\"151\";s:11:\"send_listid\";s:31:\"1000041701201704243000128891272\";}', '1493045148');
INSERT INTO `pk_common_unusual` VALUES ('1488', '发送关注信息text:', '', '1493045148');
INSERT INTO `pk_common_unusual` VALUES ('1489', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493045197\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700xucxKctZAlM6svOYqR4wDY\";s:12:\"total_amount\";s:3:\"184\";s:11:\"send_listid\";s:31:\"1000041701201704243000130840265\";}', '1493045198');
INSERT INTO `pk_common_unusual` VALUES ('1490', '发送关注信息text:', '', '1493045198');
INSERT INTO `pk_common_unusual` VALUES ('1491', '发送关注信息text:', '', '1493045298');
INSERT INTO `pk_common_unusual` VALUES ('1492', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493045415\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007eDwVnwqVx0DL08AinxJaw\";s:12:\"total_amount\";s:3:\"132\";s:11:\"send_listid\";s:31:\"1000041701201704243000130645279\";}', '1493045416');
INSERT INTO `pk_common_unusual` VALUES ('1493', '发送关注信息text:', '', '1493045416');
INSERT INTO `pk_common_unusual` VALUES ('1494', '发送关注信息text:', '', '1493045469');
INSERT INTO `pk_common_unusual` VALUES ('1495', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493045553\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009Q1gc0qPjRuMF269KXl-RA\";s:12:\"total_amount\";s:3:\"109\";s:11:\"send_listid\";s:31:\"1000041701201704243000129841272\";}', '1493045553');
INSERT INTO `pk_common_unusual` VALUES ('1496', '发送关注信息text:', '', '1493045553');
INSERT INTO `pk_common_unusual` VALUES ('1497', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493045791\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_lJWyVxHJ0BUVQ4010rKAM\";s:12:\"total_amount\";s:3:\"110\";s:11:\"send_listid\";s:31:\"1000041701201704243000131796287\";}', '1493045792');
INSERT INTO `pk_common_unusual` VALUES ('1498', '发送关注信息text:', '', '1493045792');
INSERT INTO `pk_common_unusual` VALUES ('1499', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:7:\"NO_AUTH\";s:12:\"err_code_des\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:10:\"mch_billno\";s:16:\"static1493045831\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_0L_A10_LdD3MZRNPCqyaw\";s:12:\"total_amount\";s:3:\"182\";}', '1493045831');
INSERT INTO `pk_common_unusual` VALUES ('1500', '发送关注信息text:', '', '1493045831');
INSERT INTO `pk_common_unusual` VALUES ('1501', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493046065\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87000FVqTnSfCIAWVix0ZQDly8\";s:12:\"total_amount\";s:3:\"187\";s:11:\"send_listid\";s:31:\"1000041701201704243000130851271\";}', '1493046065');
INSERT INTO `pk_common_unusual` VALUES ('1502', '发送关注信息text:', '', '1493046065');
INSERT INTO `pk_common_unusual` VALUES ('1503', '发送关注信息text:', '', '1493046225');
INSERT INTO `pk_common_unusual` VALUES ('1504', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493046253\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700yjFgRU4-EVDuN4NaJLmS7c\";s:12:\"total_amount\";s:3:\"158\";s:11:\"send_listid\";s:31:\"1000041701201704243000132653105\";}', '1493046254');
INSERT INTO `pk_common_unusual` VALUES ('1505', '发送关注信息text:', '', '1493046254');
INSERT INTO `pk_common_unusual` VALUES ('1506', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493046547\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87000aDBrv4Ze-ZJcQIJuISM54\";s:12:\"total_amount\";s:3:\"181\";s:11:\"send_listid\";s:31:\"1000041701201704243000131791172\";}', '1493046547');
INSERT INTO `pk_common_unusual` VALUES ('1507', '发送关注信息text:', '', '1493046547');
INSERT INTO `pk_common_unusual` VALUES ('1508', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493046639\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-8sZAv4sckqkdnjWUqMKQQ\";s:12:\"total_amount\";s:3:\"134\";s:11:\"send_listid\";s:31:\"1000041701201704243000132731123\";}', '1493046640');
INSERT INTO `pk_common_unusual` VALUES ('1509', '发送关注信息text:', '', '1493046640');
INSERT INTO `pk_common_unusual` VALUES ('1510', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493046854\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006XXxGQY36gooLwTadnrWCI\";s:12:\"total_amount\";s:3:\"132\";s:11:\"send_listid\";s:31:\"1000041701201704243000131837181\";}', '1493046855');
INSERT INTO `pk_common_unusual` VALUES ('1511', '发送关注信息text:', '', '1493046855');
INSERT INTO `pk_common_unusual` VALUES ('1512', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493046861\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-saJi7X2KQUcmSWy4PtZwg\";s:12:\"total_amount\";s:3:\"140\";s:11:\"send_listid\";s:31:\"1000041701201704243000134600128\";}', '1493046861');
INSERT INTO `pk_common_unusual` VALUES ('1513', '发送关注信息text:', '', '1493046861');
INSERT INTO `pk_common_unusual` VALUES ('1514', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493046957\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700ystfgHJCbP1HjJLniWqP-k\";s:12:\"total_amount\";s:3:\"119\";s:11:\"send_listid\";s:31:\"1000041701201704243000134634120\";}', '1493046958');
INSERT INTO `pk_common_unusual` VALUES ('1515', '发送关注信息text:', '', '1493046958');
INSERT INTO `pk_common_unusual` VALUES ('1516', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493046974\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003ZEW2APXLGBnX0YD2Hgj6Y\";s:12:\"total_amount\";s:3:\"185\";s:11:\"send_listid\";s:31:\"1000041701201704243000133762163\";}', '1493046975');
INSERT INTO `pk_common_unusual` VALUES ('1517', '发送关注信息text:', '', '1493046975');
INSERT INTO `pk_common_unusual` VALUES ('1518', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493047041\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007Q9UgYhy67ZYBQxHKnbzTo\";s:12:\"total_amount\";s:3:\"153\";s:11:\"send_listid\";s:31:\"1000041701201704243000133676279\";}', '1493047042');
INSERT INTO `pk_common_unusual` VALUES ('1519', '发送关注信息text:', '', '1493047042');
INSERT INTO `pk_common_unusual` VALUES ('1520', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493047115\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004cw5W8t_EQecgxCrQV0A6g\";s:12:\"total_amount\";s:3:\"148\";s:11:\"send_listid\";s:31:\"1000041701201704243000133658196\";}', '1493047116');
INSERT INTO `pk_common_unusual` VALUES ('1521', '发送关注信息text:', '', '1493047116');
INSERT INTO `pk_common_unusual` VALUES ('1522', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493047241\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87000vEave8jSczp67jcPJrc1Q\";s:12:\"total_amount\";s:3:\"154\";s:11:\"send_listid\";s:31:\"1000041701201704243000133627241\";}', '1493047241');
INSERT INTO `pk_common_unusual` VALUES ('1523', '发送关注信息text:', '', '1493047241');
INSERT INTO `pk_common_unusual` VALUES ('1524', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493047250\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870036iFhQFLdzrrYc2RsFoPaU\";s:12:\"total_amount\";s:3:\"170\";s:11:\"send_listid\";s:31:\"1000041701201704243000132869138\";}', '1493047251');
INSERT INTO `pk_common_unusual` VALUES ('1525', '发送关注信息text:', '', '1493047251');
INSERT INTO `pk_common_unusual` VALUES ('1526', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:7:\"NO_AUTH\";s:12:\"err_code_des\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:10:\"mch_billno\";s:16:\"static1493047256\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002ApAxjneEoiYkHF5p0JXAE\";s:12:\"total_amount\";s:3:\"141\";}', '1493047256');
INSERT INTO `pk_common_unusual` VALUES ('1527', '发送关注信息text:', '', '1493047256');
INSERT INTO `pk_common_unusual` VALUES ('1528', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493047684\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009Ps32Xrn_DRcw3HT9ZAN_0\";s:12:\"total_amount\";s:3:\"136\";s:11:\"send_listid\";s:31:\"1000041701201704243000132779289\";}', '1493047685');
INSERT INTO `pk_common_unusual` VALUES ('1529', '发送关注信息text:', '', '1493047685');
INSERT INTO `pk_common_unusual` VALUES ('1530', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493047782\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-ha8kC3gt7gbR0ccggwo4o\";s:12:\"total_amount\";s:3:\"150\";s:11:\"send_listid\";s:31:\"1000041701201704243000134800180\";}', '1493047782');
INSERT INTO `pk_common_unusual` VALUES ('1531', '发送关注信息text:', '', '1493047782');
INSERT INTO `pk_common_unusual` VALUES ('1532', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048238\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009OcDcYdPTLd4qMpKpT6QBc\";s:12:\"total_amount\";s:3:\"178\";s:11:\"send_listid\";s:31:\"1000041701201704243000135826204\";}', '1493048239');
INSERT INTO `pk_common_unusual` VALUES ('1533', '发送关注信息text:', '', '1493048239');
INSERT INTO `pk_common_unusual` VALUES ('1534', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048402\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700zaN1LBcmK5maxw2mp3vPOE\";s:12:\"total_amount\";s:3:\"126\";s:11:\"send_listid\";s:31:\"1000041701201704243000135616177\";}', '1493048403');
INSERT INTO `pk_common_unusual` VALUES ('1535', '发送关注信息text:', '', '1493048403');
INSERT INTO `pk_common_unusual` VALUES ('1536', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048416\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_3PvJnFBcyvOWEFvpkKKr8\";s:12:\"total_amount\";s:3:\"157\";s:11:\"send_listid\";s:31:\"1000041701201704243000133869180\";}', '1493048417');
INSERT INTO `pk_common_unusual` VALUES ('1537', '发送关注信息text:', '', '1493048417');
INSERT INTO `pk_common_unusual` VALUES ('1538', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048423\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002XK3_HA1A2YjpYpXRc8gYk\";s:12:\"total_amount\";s:3:\"177\";s:11:\"send_listid\";s:31:\"1000041701201704243000133695282\";}', '1493048424');
INSERT INTO `pk_common_unusual` VALUES ('1539', '发送关注信息text:', '', '1493048424');
INSERT INTO `pk_common_unusual` VALUES ('1540', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048457\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wmuIqo4_7xJtPjlrr6NFVc\";s:12:\"total_amount\";s:3:\"150\";s:11:\"send_listid\";s:31:\"1000041701201704243000134856191\";}', '1493048458');
INSERT INTO `pk_common_unusual` VALUES ('1541', '发送关注信息text:', '', '1493048458');
INSERT INTO `pk_common_unusual` VALUES ('1542', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048458\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003C0W8BD9djMHjKWEDYfM8o\";s:12:\"total_amount\";s:3:\"129\";s:11:\"send_listid\";s:31:\"1000041701201704243000135670255\";}', '1493048459');
INSERT INTO `pk_common_unusual` VALUES ('1543', '发送关注信息text:', '', '1493048459');
INSERT INTO `pk_common_unusual` VALUES ('1544', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048475\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002IR0UQreLQnrfPkFT2Dlms\";s:12:\"total_amount\";s:3:\"189\";s:11:\"send_listid\";s:31:\"1000041701201704243000134719152\";}', '1493048476');
INSERT INTO `pk_common_unusual` VALUES ('1545', '发送关注信息text:', '', '1493048476');
INSERT INTO `pk_common_unusual` VALUES ('1546', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048489\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004xXvGrkHKJTQ4Ih4j2RyNM\";s:12:\"total_amount\";s:3:\"169\";s:11:\"send_listid\";s:31:\"1000041701201704243000133837277\";}', '1493048490');
INSERT INTO `pk_common_unusual` VALUES ('1547', '发送关注信息text:', '', '1493048490');
INSERT INTO `pk_common_unusual` VALUES ('1548', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048492\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700zcgwJX4z8wdB8DYlIyG4uQ\";s:12:\"total_amount\";s:3:\"166\";s:11:\"send_listid\";s:31:\"1000041701201704243000135656174\";}', '1493048493');
INSERT INTO `pk_common_unusual` VALUES ('1549', '发送关注信息text:', '', '1493048493');
INSERT INTO `pk_common_unusual` VALUES ('1550', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048528\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008HFO_QZa_ExswWQkkSvSwg\";s:12:\"total_amount\";s:3:\"196\";s:11:\"send_listid\";s:31:\"1000041701201704243000134874185\";}', '1493048529');
INSERT INTO `pk_common_unusual` VALUES ('1551', '发送关注信息text:', '', '1493048529');
INSERT INTO `pk_common_unusual` VALUES ('1552', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048636\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-JYTKjdt3SjZ8xWqmo8gJo\";s:12:\"total_amount\";s:3:\"124\";s:11:\"send_listid\";s:31:\"1000041701201704243000135852213\";}', '1493048636');
INSERT INTO `pk_common_unusual` VALUES ('1553', '发送关注信息text:', '', '1493048636');
INSERT INTO `pk_common_unusual` VALUES ('1554', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048743\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003ztO-ie-aKt62CswYSw_wI\";s:12:\"total_amount\";s:3:\"153\";s:11:\"send_listid\";s:31:\"1000041701201704243000134745153\";}', '1493048744');
INSERT INTO `pk_common_unusual` VALUES ('1555', '发送关注信息text:', '', '1493048744');
INSERT INTO `pk_common_unusual` VALUES ('1556', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048792\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870089kTPmwZ1KfVQUZjnGYD1E\";s:12:\"total_amount\";s:3:\"163\";s:11:\"send_listid\";s:31:\"1000041701201704243000134809191\";}', '1493048793');
INSERT INTO `pk_common_unusual` VALUES ('1557', '发送关注信息text:', '', '1493048793');
INSERT INTO `pk_common_unusual` VALUES ('1558', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048835\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700zHLjWdT3VLVSf7Fcwj1VbY\";s:12:\"total_amount\";s:3:\"134\";s:11:\"send_listid\";s:31:\"1000041701201704243000134611196\";}', '1493048836');
INSERT INTO `pk_common_unusual` VALUES ('1559', '发送关注信息text:', '', '1493048836');
INSERT INTO `pk_common_unusual` VALUES ('1560', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048869\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870050ie4y0jCqDgslOOJqlWDQ\";s:12:\"total_amount\";s:3:\"149\";s:11:\"send_listid\";s:31:\"1000041701201704243000134831265\";}', '1493048869');
INSERT INTO `pk_common_unusual` VALUES ('1561', '发送关注信息text:', '', '1493048869');
INSERT INTO `pk_common_unusual` VALUES ('1562', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493048971\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008MOKpcFpm5BdDwNbXa021Q\";s:12:\"total_amount\";s:3:\"185\";s:11:\"send_listid\";s:31:\"1000041701201704243000134649295\";}', '1493048971');
INSERT INTO `pk_common_unusual` VALUES ('1563', '发送关注信息text:', '', '1493048971');
INSERT INTO `pk_common_unusual` VALUES ('1564', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493049084\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700ww6Kh-KtmvFZOrC51EfqwQ\";s:12:\"total_amount\";s:3:\"177\";s:11:\"send_listid\";s:31:\"1000041701201704243000134793209\";}', '1493049085');
INSERT INTO `pk_common_unusual` VALUES ('1565', '发送关注信息text:', '', '1493049085');
INSERT INTO `pk_common_unusual` VALUES ('1566', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493050412\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wDuvOWP6Uhe4-waa6ZKihw\";s:12:\"total_amount\";s:3:\"155\";s:11:\"send_listid\";s:31:\"1000041701201704253000001648178\";}', '1493050413');
INSERT INTO `pk_common_unusual` VALUES ('1567', '发送关注信息text:', '', '1493050413');
INSERT INTO `pk_common_unusual` VALUES ('1568', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493051558\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007z6In7zoYyoyXqUJklzlOg\";s:12:\"total_amount\";s:3:\"200\";s:11:\"send_listid\";s:31:\"1000041701201704253000000819169\";}', '1493051559');
INSERT INTO `pk_common_unusual` VALUES ('1569', '发送关注信息text:', '', '1493051559');
INSERT INTO `pk_common_unusual` VALUES ('1570', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493051581\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_rwmaV8nBI5UWotFroRF_g\";s:12:\"total_amount\";s:3:\"135\";s:11:\"send_listid\";s:31:\"1000041701201704253000002617170\";}', '1493051582');
INSERT INTO `pk_common_unusual` VALUES ('1571', '发送关注信息text:', '', '1493051582');
INSERT INTO `pk_common_unusual` VALUES ('1572', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493051926\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87009LJApB_jSra23OSg5cyEV4\";s:12:\"total_amount\";s:3:\"179\";s:11:\"send_listid\";s:31:\"1000041701201704253000001621298\";}', '1493051927');
INSERT INTO `pk_common_unusual` VALUES ('1573', '发送关注信息text:', '', '1493051927');
INSERT INTO `pk_common_unusual` VALUES ('1574', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493052035\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wWOkcXQzr-APgpqMTOrZaU\";s:12:\"total_amount\";s:3:\"190\";s:11:\"send_listid\";s:31:\"1000041701201704253000001763272\";}', '1493052036');
INSERT INTO `pk_common_unusual` VALUES ('1575', '发送关注信息text:', '', '1493052036');
INSERT INTO `pk_common_unusual` VALUES ('1576', '发送关注信息text:', '', '1493052132');
INSERT INTO `pk_common_unusual` VALUES ('1577', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493052207\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87007_rRhRFzpAqC-KZIn3YXzM\";s:12:\"total_amount\";s:3:\"135\";s:11:\"send_listid\";s:31:\"1000041701201704253000000749198\";}', '1493052208');
INSERT INTO `pk_common_unusual` VALUES ('1578', '发送关注信息text:', '', '1493052208');
INSERT INTO `pk_common_unusual` VALUES ('1579', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493053264\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004aeZJLtaybeWdg0l-d3dSA\";s:12:\"total_amount\";s:3:\"109\";s:11:\"send_listid\";s:31:\"1000041701201704253000003846271\";}', '1493053265');
INSERT INTO `pk_common_unusual` VALUES ('1580', '发送关注信息text:', '', '1493053265');
INSERT INTO `pk_common_unusual` VALUES ('1581', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:7:\"NO_AUTH\";s:12:\"err_code_des\";s:63:\"发放失败，此请求可能存在风险，已被微信拦截\";s:10:\"mch_billno\";s:16:\"static1493054455\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008YaG4ModcSrW_O4A0wiHFE\";s:12:\"total_amount\";s:3:\"141\";}', '1493054455');
INSERT INTO `pk_common_unusual` VALUES ('1582', '发送关注信息text:', '', '1493054455');
INSERT INTO `pk_common_unusual` VALUES ('1583', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493054599\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008zf0jSatWzZDCKoEPARcaM\";s:12:\"total_amount\";s:3:\"157\";s:11:\"send_listid\";s:31:\"1000041701201704253000003695129\";}', '1493054600');
INSERT INTO `pk_common_unusual` VALUES ('1584', '发送关注信息text:', '', '1493054600');
INSERT INTO `pk_common_unusual` VALUES ('1585', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493054723\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002W3h_WcXFwn1CxA7S643SI\";s:12:\"total_amount\";s:3:\"159\";s:11:\"send_listid\";s:31:\"1000041701201704253000003655147\";}', '1493054724');
INSERT INTO `pk_common_unusual` VALUES ('1586', '发送关注信息text:', '', '1493054724');
INSERT INTO `pk_common_unusual` VALUES ('1587', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493054966\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004wTgkKdTIc4UUi56nDvAz4\";s:12:\"total_amount\";s:3:\"143\";s:11:\"send_listid\";s:31:\"1000041701201704253000003677157\";}', '1493054967');
INSERT INTO `pk_common_unusual` VALUES ('1588', '发送关注信息text:', '', '1493054967');
INSERT INTO `pk_common_unusual` VALUES ('1589', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493055273\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003bNW0PMxaLUeUqvfmg-sLM\";s:12:\"total_amount\";s:3:\"149\";s:11:\"send_listid\";s:31:\"1000041701201704253000002679287\";}', '1493055274');
INSERT INTO `pk_common_unusual` VALUES ('1590', '发送关注信息text:', '', '1493055274');
INSERT INTO `pk_common_unusual` VALUES ('1591', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493057318\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002Xrd4ZNiH7VHDvZnOVdIxE\";s:12:\"total_amount\";s:3:\"160\";s:11:\"send_listid\";s:31:\"1000041701201704253000006718141\";}', '1493057319');
INSERT INTO `pk_common_unusual` VALUES ('1592', '发送关注信息text:', '', '1493057319');
INSERT INTO `pk_common_unusual` VALUES ('1593', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493058436\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_yS_gSblU6dj-aOBJuREbY\";s:12:\"total_amount\";s:3:\"144\";s:11:\"send_listid\";s:31:\"1000041701201704253000006656175\";}', '1493058437');
INSERT INTO `pk_common_unusual` VALUES ('1594', '发送关注信息text:', '', '1493058437');
INSERT INTO `pk_common_unusual` VALUES ('1595', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493058696\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004fT_VegXj0ko4F_Z3I-ZSQ\";s:12:\"total_amount\";s:3:\"193\";}', '1493058696');
INSERT INTO `pk_common_unusual` VALUES ('1596', '发送关注信息text:', '', '1493058696');
INSERT INTO `pk_common_unusual` VALUES ('1597', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493059667\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87001hYvTjblhzsRaJ-nIlbDAo\";s:12:\"total_amount\";s:3:\"155\";}', '1493059667');
INSERT INTO `pk_common_unusual` VALUES ('1598', '发送关注信息text:', '', '1493059667');
INSERT INTO `pk_common_unusual` VALUES ('1599', '发送关注信息text:', '', '1493060380');
INSERT INTO `pk_common_unusual` VALUES ('1600', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493061624\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870026vygKJ4yjVeDvyyUZemIk\";s:12:\"total_amount\";s:3:\"125\";s:11:\"send_listid\";s:31:\"1000041701201704253000007617226\";}', '1493061625');
INSERT INTO `pk_common_unusual` VALUES ('1601', '发送关注信息text:', '', '1493061625');
INSERT INTO `pk_common_unusual` VALUES ('1602', '发送关注信息text:', '', '1493065954');
INSERT INTO `pk_common_unusual` VALUES ('1603', '发送关注信息text:', '', '1493066052');
INSERT INTO `pk_common_unusual` VALUES ('1604', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493068119\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87001PmsDbqydfPGmUGIlffujg\";s:12:\"total_amount\";s:3:\"144\";}', '1493068120');
INSERT INTO `pk_common_unusual` VALUES ('1605', '发送关注信息text:', '', '1493068120');
INSERT INTO `pk_common_unusual` VALUES ('1606', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493068222\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87001HpkNUtjYG8BuYk26JnsGs\";s:12:\"total_amount\";s:3:\"180\";}', '1493068222');
INSERT INTO `pk_common_unusual` VALUES ('1607', '发送关注信息text:', '', '1493068222');
INSERT INTO `pk_common_unusual` VALUES ('1608', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493068938\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_XTBHVaPERBid1Wfuehedk\";s:12:\"total_amount\";s:3:\"114\";}', '1493068938');
INSERT INTO `pk_common_unusual` VALUES ('1609', '发送关注信息text:', '', '1493068938');
INSERT INTO `pk_common_unusual` VALUES ('1610', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493068981\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002obpr8Ei66u2kGP54F9I0I\";s:12:\"total_amount\";s:3:\"166\";}', '1493068981');
INSERT INTO `pk_common_unusual` VALUES ('1611', '发送关注信息text:', '', '1493068981');
INSERT INTO `pk_common_unusual` VALUES ('1612', '发送关注信息text:', '', '1493068986');
INSERT INTO `pk_common_unusual` VALUES ('1613', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493070138\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87003ZAx6_IdfSoPw4TUa83R3w\";s:12:\"total_amount\";s:3:\"144\";}', '1493070139');
INSERT INTO `pk_common_unusual` VALUES ('1614', '发送关注信息text:', '', '1493070139');
INSERT INTO `pk_common_unusual` VALUES ('1615', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493070252\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700-cUe3IE83qbOb8xPFY8EPU\";s:12:\"total_amount\";s:3:\"191\";}', '1493070253');
INSERT INTO `pk_common_unusual` VALUES ('1616', '发送关注信息text:', '', '1493070253');
INSERT INTO `pk_common_unusual` VALUES ('1617', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493070391\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700xquaTGOnMkwyHMJyISbHLs\";s:12:\"total_amount\";s:3:\"168\";}', '1493070391');
INSERT INTO `pk_common_unusual` VALUES ('1618', '发送关注信息text:', '', '1493070391');
INSERT INTO `pk_common_unusual` VALUES ('1619', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493070441\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_KRFEw0_yiPtkuDCy2Z2yw\";s:12:\"total_amount\";s:3:\"190\";}', '1493070441');
INSERT INTO `pk_common_unusual` VALUES ('1620', '发送关注信息text:', '', '1493070441');
INSERT INTO `pk_common_unusual` VALUES ('1621', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493071975\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870010w4Aao57RU9e7PMttzOC4\";s:12:\"total_amount\";s:3:\"142\";}', '1493071976');
INSERT INTO `pk_common_unusual` VALUES ('1622', '发送关注信息text:', '', '1493071976');
INSERT INTO `pk_common_unusual` VALUES ('1623', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493072048\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wMRIPYwLF4vK2-gRc01HOU\";s:12:\"total_amount\";s:3:\"187\";}', '1493072049');
INSERT INTO `pk_common_unusual` VALUES ('1624', '发送关注信息text:', '', '1493072049');
INSERT INTO `pk_common_unusual` VALUES ('1625', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493072872\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700zdwp1GszlXpMHAk2omxj3o\";s:12:\"total_amount\";s:3:\"161\";}', '1493072873');
INSERT INTO `pk_common_unusual` VALUES ('1626', '发送关注信息text:', '', '1493072873');
INSERT INTO `pk_common_unusual` VALUES ('1627', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493072904\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87005VcGWoUkvADzG6IZKvV1j8\";s:12:\"total_amount\";s:3:\"143\";}', '1493072904');
INSERT INTO `pk_common_unusual` VALUES ('1628', '发送关注信息text:', '', '1493072904');
INSERT INTO `pk_common_unusual` VALUES ('1629', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493073357\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700_tF6jNyXeNPPUWKgzukZNE\";s:12:\"total_amount\";s:3:\"140\";}', '1493073358');
INSERT INTO `pk_common_unusual` VALUES ('1630', '发送关注信息text:', '', '1493073358');
INSERT INTO `pk_common_unusual` VALUES ('1631', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493073589\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700239ZXV4OY59xYW85VGoTd4\";s:12:\"total_amount\";s:3:\"117\";}', '1493073590');
INSERT INTO `pk_common_unusual` VALUES ('1632', '发送关注信息text:', '', '1493073590');
INSERT INTO `pk_common_unusual` VALUES ('1633', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493074380\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700wxVrsNB6RcD4OM3xsYjz98\";s:12:\"total_amount\";s:3:\"125\";}', '1493074381');
INSERT INTO `pk_common_unusual` VALUES ('1634', '发送关注信息text:', '', '1493074381');
INSERT INTO `pk_common_unusual` VALUES ('1635', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493074561\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700y86ywj0TZT9HDZRUvImyxo\";s:12:\"total_amount\";s:3:\"106\";}', '1493074562');
INSERT INTO `pk_common_unusual` VALUES ('1636', '发送关注信息text:', '', '1493074562');
INSERT INTO `pk_common_unusual` VALUES ('1637', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493074664\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700__c7PY297sMFWJctRQKKyU\";s:12:\"total_amount\";s:3:\"158\";}', '1493074664');
INSERT INTO `pk_common_unusual` VALUES ('1638', '发送关注信息text:', '', '1493074664');
INSERT INTO `pk_common_unusual` VALUES ('1639', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493074785\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700xE8m8x0H8YGTLSZK6XFjrA\";s:12:\"total_amount\";s:3:\"196\";}', '1493074786');
INSERT INTO `pk_common_unusual` VALUES ('1640', '发送关注信息text:', '', '1493074786');
INSERT INTO `pk_common_unusual` VALUES ('1641', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493075086\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od8700yUoxCctqWhc94r_ISJwOYs\";s:12:\"total_amount\";s:3:\"200\";}', '1493075087');
INSERT INTO `pk_common_unusual` VALUES ('1642', '发送关注信息text:', '', '1493075087');
INSERT INTO `pk_common_unusual` VALUES ('1643', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493075849\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87001yk3vz1BDYTqpY7WaIS3dY\";s:12:\"total_amount\";s:3:\"124\";}', '1493075850');
INSERT INTO `pk_common_unusual` VALUES ('1644', '发送关注信息text:', '', '1493075850');
INSERT INTO `pk_common_unusual` VALUES ('1645', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493076135\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008wsh9ZAifTMKePga3VoDp4\";s:12:\"total_amount\";s:3:\"196\";}', '1493076135');
INSERT INTO `pk_common_unusual` VALUES ('1646', '发送关注信息text:', '', '1493076135');
INSERT INTO `pk_common_unusual` VALUES ('1647', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493076234\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87001Fv47qC3YcmeePDGiFXVsU\";s:12:\"total_amount\";s:3:\"124\";}', '1493076234');
INSERT INTO `pk_common_unusual` VALUES ('1648', '发送关注信息text:', '', '1493076234');
INSERT INTO `pk_common_unusual` VALUES ('1649', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493076611\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87004G1-V57ClVuvifwl5x02M0\";s:12:\"total_amount\";s:3:\"170\";}', '1493076612');
INSERT INTO `pk_common_unusual` VALUES ('1650', '发送关注信息text:', '', '1493076612');
INSERT INTO `pk_common_unusual` VALUES ('1651', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493076623\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87008hbCobZoDFamzVBfqZx0n8\";s:12:\"total_amount\";s:3:\"171\";}', '1493076624');
INSERT INTO `pk_common_unusual` VALUES ('1652', '发送关注信息text:', '', '1493076624');
INSERT INTO `pk_common_unusual` VALUES ('1653', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493076890\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87002apkIv2WkvvxjyrE4DRPKk\";s:12:\"total_amount\";s:3:\"105\";}', '1493076890');
INSERT INTO `pk_common_unusual` VALUES ('1654', '发送关注信息text:', '', '1493076890');
INSERT INTO `pk_common_unusual` VALUES ('1655', '发送红包成功', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:9:\"NOTENOUGH\";s:12:\"err_code_des\";s:57:\"帐号余额不足，请到商户平台充值后再重试\";s:10:\"mch_billno\";s:16:\"static1493077634\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od870024f4TJ5uMdlC2P8MS6Ronc\";s:12:\"total_amount\";s:3:\"149\";}', '1493077635');
INSERT INTO `pk_common_unusual` VALUES ('1656', '发送关注信息text:', '', '1493077635');
INSERT INTO `pk_common_unusual` VALUES ('1657', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493044249\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.3600000000000000976996261670137755572795867919921875;s:6:\"openid\";s:28:\"od87006fSqVoPolfnsO8FQu1_ofo\";s:12:\"redpack_type\";s:1:\"1\";}', '1493077786');
INSERT INTO `pk_common_unusual` VALUES ('1658', '发送关注信息text:', '', '1493077786');
INSERT INTO `pk_common_unusual` VALUES ('1659', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493044249\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.6399999999999999023003738329862244427204132080078125;s:6:\"openid\";s:28:\"od8700whaeimnjzjUIy7VWoPozvo\";s:12:\"redpack_type\";s:1:\"1\";}', '1493078102');
INSERT INTO `pk_common_unusual` VALUES ('1660', '发送关注信息text:', '', '1493078102');
INSERT INTO `pk_common_unusual` VALUES ('1661', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493044249\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.54000000000000003552713678800500929355621337890625;s:6:\"openid\";s:28:\"od8700yRLAFnEBtHp04krgeCIfaw\";s:12:\"redpack_type\";s:1:\"1\";}', '1493078680');
INSERT INTO `pk_common_unusual` VALUES ('1662', '发送关注信息text:', '', '1493078680');
INSERT INTO `pk_common_unusual` VALUES ('1663', '发送关注信息text:', '', '1493078741');
INSERT INTO `pk_common_unusual` VALUES ('1664', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493044249\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.6999999999999999555910790149937383830547332763671875;s:6:\"openid\";s:28:\"od8700748gTeMYMVFI2esr7_7-RY\";s:12:\"redpack_type\";s:1:\"1\";}', '1493078860');
INSERT INTO `pk_common_unusual` VALUES ('1665', '发送关注信息text:', '', '1493078860');
INSERT INTO `pk_common_unusual` VALUES ('1666', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493044249\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.25;s:6:\"openid\";s:28:\"od8700yAp6Jj-_w2_7-AyQk9OK3Y\";s:12:\"redpack_type\";s:1:\"1\";}', '1493079781');
INSERT INTO `pk_common_unusual` VALUES ('1667', '发送关注信息text:', '', '1493079781');
INSERT INTO `pk_common_unusual` VALUES ('1668', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493044249\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.5900000000000000799360577730112709105014801025390625;s:6:\"openid\";s:28:\"od87007E5QPO-iHZIAszOazNeGFs\";s:12:\"redpack_type\";s:1:\"1\";}', '1493081358');
INSERT INTO `pk_common_unusual` VALUES ('1669', '发送关注信息text:', '', '1493081358');
INSERT INTO `pk_common_unusual` VALUES ('1670', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493044249\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.62999999999999989341858963598497211933135986328125;s:6:\"openid\";s:28:\"od87008mkdLRGMJhm9YgmX-gCOFM\";s:12:\"redpack_type\";s:1:\"1\";}', '1493081998');
INSERT INTO `pk_common_unusual` VALUES ('1671', '发送关注信息text:', '', '1493081998');
INSERT INTO `pk_common_unusual` VALUES ('1672', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493044249\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.1799999999999999378275106209912337362766265869140625;s:6:\"openid\";s:28:\"od87009D9Pbn7II2khMl4FSevepA\";s:12:\"redpack_type\";s:1:\"1\";}', '1493084655');
INSERT INTO `pk_common_unusual` VALUES ('1673', '发送关注信息text:', '', '1493084655');
INSERT INTO `pk_common_unusual` VALUES ('1674', '发送关注信息text:', '', '1493086067');
INSERT INTO `pk_common_unusual` VALUES ('1675', '发送关注信息text:', '', '1493086086');
INSERT INTO `pk_common_unusual` VALUES ('1676', '发送关注信息text:', '', '1493086103');
INSERT INTO `pk_common_unusual` VALUES ('1677', '发送关注信息text:', '', '1493086733');
INSERT INTO `pk_common_unusual` VALUES ('1678', '发送关注信息text:', '', '1493086754');
INSERT INTO `pk_common_unusual` VALUES ('1679', '发送关注信息text:', '', '1493086768');
INSERT INTO `pk_common_unusual` VALUES ('1680', '发送关注信息text:', '', '1493086904');
INSERT INTO `pk_common_unusual` VALUES ('1681', '发送关注信息text:', '', '1493087041');
INSERT INTO `pk_common_unusual` VALUES ('1682', '发送关注信息text:', '', '1493087303');
INSERT INTO `pk_common_unusual` VALUES ('1683', '发送关注信息text:', '', '1493087926');
INSERT INTO `pk_common_unusual` VALUES ('1684', '发送关注信息text:', '', '1493088435');
INSERT INTO `pk_common_unusual` VALUES ('1685', '发送关注信息text:', '', '1493088454');
INSERT INTO `pk_common_unusual` VALUES ('1686', '发送关注信息text:', '', '1493089714');
INSERT INTO `pk_common_unusual` VALUES ('1687', '发送关注信息text:', '', '1493090031');
INSERT INTO `pk_common_unusual` VALUES ('1688', '发送关注信息text:', '', '1493092141');
INSERT INTO `pk_common_unusual` VALUES ('1689', '发送关注信息text:', '', '1493092906');
INSERT INTO `pk_common_unusual` VALUES ('1690', '发送关注信息text:', '', '1493094089');
INSERT INTO `pk_common_unusual` VALUES ('1691', '发送关注信息text:', '', '1493094544');
INSERT INTO `pk_common_unusual` VALUES ('1692', '发送关注信息text:', '', '1493094601');
INSERT INTO `pk_common_unusual` VALUES ('1693', '发送关注信息text:', '', '1493094695');
INSERT INTO `pk_common_unusual` VALUES ('1694', '发送关注信息text:', '', '1493098377');
INSERT INTO `pk_common_unusual` VALUES ('1695', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493100024\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.939999999999999946709294817992486059665679931640625;s:6:\"openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"redpack_type\";s:1:\"1\";}', '1493100095');
INSERT INTO `pk_common_unusual` VALUES ('1696', '发送关注信息text:', '', '1493100095');
INSERT INTO `pk_common_unusual` VALUES ('1697', '发送红包成功', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1493100169\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"total_amount\";s:3:\"167\";s:11:\"send_listid\";s:31:\"1000041701201704253000061633246\";}', '1493100170');
INSERT INTO `pk_common_unusual` VALUES ('1698', '发送关注信息text:', '', '1493100170');
INSERT INTO `pk_common_unusual` VALUES ('1699', '发送关注信息text:', '', '1493102067');
INSERT INTO `pk_common_unusual` VALUES ('1700', '发送关注信息text:', '', '1493102401');
INSERT INTO `pk_common_unusual` VALUES ('1701', '发送关注信息text:', '', '1493102759');
INSERT INTO `pk_common_unusual` VALUES ('1702', '发送关注信息text:', '', '1493102853');
INSERT INTO `pk_common_unusual` VALUES ('1703', '发送关注信息text:', '', '1493102888');
INSERT INTO `pk_common_unusual` VALUES ('1704', '红包数量不足', 'a:16:{s:2:\"id\";s:3:\"444\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:21:\"语记关注送红包\";s:4:\"type\";s:1:\"1\";s:9:\"min_value\";s:4:\"1.00\";s:9:\"max_value\";s:4:\"2.00\";s:3:\"num\";s:1:\"0\";s:7:\"wishing\";s:39:\"欢迎关注“语记雨伞”公众号\";s:8:\"act_name\";s:30:\"感恩粉丝们的支持厚爱\";s:6:\"remark\";s:30:\"感恩粉丝们的支持厚爱\";s:8:\"add_time\";s:1:\"0\";s:11:\"update_time\";s:10:\"1493102714\";s:6:\"status\";s:1:\"1\";s:5:\"money\";d:1.4699999999999999733546474089962430298328399658203125;s:6:\"openid\";s:28:\"od87002m9pZTryOZYGY61ljoXxLg\";s:12:\"redpack_type\";s:1:\"1\";}', '1493106206');
INSERT INTO `pk_common_unusual` VALUES ('1705', '发送关注信息text:', '', '1493106206');
INSERT INTO `pk_common_unusual` VALUES ('1706', '发送关注信息text:', '', '1493107227');
INSERT INTO `pk_common_unusual` VALUES ('1707', '发送关注信息text:', '', '1493112312');
INSERT INTO `pk_common_unusual` VALUES ('1708', '发送关注信息text:', '', '1493112727');
INSERT INTO `pk_common_unusual` VALUES ('1709', '发送关注信息text:', '', '1493113866');
INSERT INTO `pk_common_unusual` VALUES ('1710', '发送关注信息text:', '', '1493113928');
INSERT INTO `pk_common_unusual` VALUES ('1711', '发送关注信息text:', '', '1493114627');
INSERT INTO `pk_common_unusual` VALUES ('1712', '发送关注信息text:', '', '1493114696');
INSERT INTO `pk_common_unusual` VALUES ('1713', '发送关注信息text:', '', '1493115077');
INSERT INTO `pk_common_unusual` VALUES ('1714', '发送关注信息text:', '', '1493117198');
INSERT INTO `pk_common_unusual` VALUES ('1715', '发送关注信息text:', '', '1493117616');
INSERT INTO `pk_common_unusual` VALUES ('1716', '接受到来自微信的群发结束的通知，来自event', '', '1493277208');
INSERT INTO `pk_common_unusual` VALUES ('1717', 'public_id:gh_26c67b09cb87,msg_id:3147483655接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483655\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"0\";s:9:\"SentCount\";s:1:\"0\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1493277614');
INSERT INTO `pk_common_unusual` VALUES ('1718', 'msg_id:3147483656', '', '1493277960');
INSERT INTO `pk_common_unusual` VALUES ('1719', 'public_id:gh_26c67b09cb87,msg_id:3147483656接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483656\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"0\";s:9:\"SentCount\";s:1:\"0\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1493277962');
INSERT INTO `pk_common_unusual` VALUES ('1720', 'msg_id:3147483657', '', '1493278414');
INSERT INTO `pk_common_unusual` VALUES ('1721', 'save msg_id:3147483657', '', '1493278414');
INSERT INTO `pk_common_unusual` VALUES ('1722', 'public_id:gh_26c67b09cb87,msg_id:3147483657接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483657\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"0\";s:9:\"SentCount\";s:1:\"0\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1493278417');
INSERT INTO `pk_common_unusual` VALUES ('1723', 'msg_id:3147483658', '', '1493278673');
INSERT INTO `pk_common_unusual` VALUES ('1724', 'save msg_id:3147483658', '', '1493278673');
INSERT INTO `pk_common_unusual` VALUES ('1725', 'public_id:gh_26c67b09cb87,msg_id:3147483658接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483658\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"0\";s:9:\"SentCount\";s:1:\"0\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1493278675');
INSERT INTO `pk_common_unusual` VALUES ('1726', '全部回复===', '', '1493371580');
INSERT INTO `pk_common_unusual` VALUES ('1727', '0全部回复2===JVcALzQknkVneRbAfbE8KulCebEtmC_Wx7NR17Xc4JY', '', '1493371580');
INSERT INTO `pk_common_unusual` VALUES ('1728', '1全部回复1===17', '', '1493371580');
INSERT INTO `pk_common_unusual` VALUES ('1729', '2全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1493371581');
INSERT INTO `pk_common_unusual` VALUES ('1730', '3全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1493371581');
INSERT INTO `pk_common_unusual` VALUES ('1731', '全部回复===', '', '1493371611');
INSERT INTO `pk_common_unusual` VALUES ('1732', '0全部回复2===JVcALzQknkVneRbAfbE8KulCebEtmC_Wx7NR17Xc4JY', '', '1493371611');
INSERT INTO `pk_common_unusual` VALUES ('1733', '1全部回复1===17', '', '1493371611');
INSERT INTO `pk_common_unusual` VALUES ('1734', '2全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1493371611');
INSERT INTO `pk_common_unusual` VALUES ('1735', '3全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1493371611');
INSERT INTO `pk_common_unusual` VALUES ('1736', '4全部回复1===17', '', '1493371611');
INSERT INTO `pk_common_unusual` VALUES ('1737', 'od87006dZbELiKqoGDFjQ9g4Ow48取消了订阅', '', '1493862804');
INSERT INTO `pk_common_unusual` VALUES ('1738', 'N;', '', '1493866005');
INSERT INTO `pk_common_unusual` VALUES ('1739', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:7:\"asdfsdf\";s:12:\"media_id_str\";s:2:\"17\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1486450293\";s:10:\"updatetime\";s:10:\"1493865527\";}', '', '1493866109');
INSERT INTO `pk_common_unusual` VALUES ('1740', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:9:\"|asdfsdf|\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1493866160\";}', '', '1493867040');
INSERT INTO `pk_common_unusual` VALUES ('1741', '0全部回复1===17', '', '1493867040');
INSERT INTO `pk_common_unusual` VALUES ('1742', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1493867041');
INSERT INTO `pk_common_unusual` VALUES ('1743', '0全部回复1===17', '', '1493870155');
INSERT INTO `pk_common_unusual` VALUES ('1744', '1全部回复2===JVcALzQknkVneRbAfbE8Ks_0OdHIL7ER7VAMKZpScOs', '', '1493870155');
INSERT INTO `pk_common_unusual` VALUES ('1745', '0全部回复1===17', '', '1493870757');
INSERT INTO `pk_common_unusual` VALUES ('1746', '1全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1493870757');
INSERT INTO `pk_common_unusual` VALUES ('1747', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"1\";s:10:\"reply_type\";s:1:\"2\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:11:\"|二手车|\";s:12:\"media_id_str\";s:43:\"efzRilNNFDo0wX9aR4jkLKylwHwbuQO4JptwawC8K8I\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1493637098\";}', '', '1493875905');
INSERT INTO `pk_common_unusual` VALUES ('1748', 'public_id:gh_268611be4300,msg_id:1000000004接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"1000000004\";s:10:\"TotalCount\";s:3:\"309\";s:11:\"FilterCount\";s:3:\"309\";s:9:\"SentCount\";s:3:\"309\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1493976533');
INSERT INTO `pk_common_unusual` VALUES ('1749', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"1\";s:10:\"reply_type\";s:1:\"2\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:11:\"|二手车|\";s:12:\"media_id_str\";s:43:\"efzRilNNFDo0wX9aR4jkLKylwHwbuQO4JptwawC8K8I\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1493637098\";}', '', '1494036155');
INSERT INTO `pk_common_unusual` VALUES ('1750', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494235726');
INSERT INTO `pk_common_unusual` VALUES ('1751', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494239410');
INSERT INTO `pk_common_unusual` VALUES ('1752', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494241797');
INSERT INTO `pk_common_unusual` VALUES ('1753', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494381012');
INSERT INTO `pk_common_unusual` VALUES ('1754', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494396607');
INSERT INTO `pk_common_unusual` VALUES ('1755', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494406266');
INSERT INTO `pk_common_unusual` VALUES ('1756', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1493869335\";}', '', '1494457909');
INSERT INTO `pk_common_unusual` VALUES ('1757', '0全部回复1===17', '', '1494457909');
INSERT INTO `pk_common_unusual` VALUES ('1758', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1494457909');
INSERT INTO `pk_common_unusual` VALUES ('1759', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1493869335\";}', '', '1494499424');
INSERT INTO `pk_common_unusual` VALUES ('1760', '0全部回复1===17', '', '1494499424');
INSERT INTO `pk_common_unusual` VALUES ('1761', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1494499424');
INSERT INTO `pk_common_unusual` VALUES ('1762', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494517133');
INSERT INTO `pk_common_unusual` VALUES ('1763', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494518471');
INSERT INTO `pk_common_unusual` VALUES ('1764', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494541139');
INSERT INTO `pk_common_unusual` VALUES ('1765', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494543155');
INSERT INTO `pk_common_unusual` VALUES ('1766', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494660492');
INSERT INTO `pk_common_unusual` VALUES ('1767', '0全部回复1===17', '', '1494660932');
INSERT INTO `pk_common_unusual` VALUES ('1768', '1全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1494660932');
INSERT INTO `pk_common_unusual` VALUES ('1769', '0全部回复1===17', '', '1494660939');
INSERT INTO `pk_common_unusual` VALUES ('1770', '1全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1494660940');
INSERT INTO `pk_common_unusual` VALUES ('1771', 'public_id:gh_26c67b09cb87,msg_id:1000000011接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"1000000011\";s:10:\"TotalCount\";s:1:\"2\";s:11:\"FilterCount\";s:1:\"2\";s:9:\"SentCount\";s:1:\"2\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1494667533');
INSERT INTO `pk_common_unusual` VALUES ('1772', 'public_id:gh_26c67b09cb87,msg_id:1000000012接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"1000000012\";s:10:\"TotalCount\";s:1:\"2\";s:11:\"FilterCount\";s:1:\"2\";s:9:\"SentCount\";s:1:\"2\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1494667604');
INSERT INTO `pk_common_unusual` VALUES ('1773', 'public_id:gh_26c67b09cb87,msg_id:3147483661接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483661\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"1\";s:9:\"SentCount\";s:1:\"1\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1494667817');
INSERT INTO `pk_common_unusual` VALUES ('1774', 'public_id:gh_26c67b09cb87,msg_id:3147483662接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483662\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"1\";s:9:\"SentCount\";s:1:\"1\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1494667967');
INSERT INTO `pk_common_unusual` VALUES ('1775', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1494669021');
INSERT INTO `pk_common_unusual` VALUES ('1776', '0全部回复1===17', '', '1494669021');
INSERT INTO `pk_common_unusual` VALUES ('1777', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1494669021');
INSERT INTO `pk_common_unusual` VALUES ('1778', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1494710951');
INSERT INTO `pk_common_unusual` VALUES ('1779', '0全部回复1===17', '', '1494710951');
INSERT INTO `pk_common_unusual` VALUES ('1780', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1494710951');
INSERT INTO `pk_common_unusual` VALUES ('1781', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494756214');
INSERT INTO `pk_common_unusual` VALUES ('1782', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494851638');
INSERT INTO `pk_common_unusual` VALUES ('1783', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1494946228');
INSERT INTO `pk_common_unusual` VALUES ('1784', '0全部回复1===17', '', '1495005126');
INSERT INTO `pk_common_unusual` VALUES ('1785', '1全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1495005126');
INSERT INTO `pk_common_unusual` VALUES ('1786', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1495097036');
INSERT INTO `pk_common_unusual` VALUES ('1787', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1495199381');
INSERT INTO `pk_common_unusual` VALUES ('1788', '0全部回复1===17', '', '1495448087');
INSERT INTO `pk_common_unusual` VALUES ('1789', '1全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1495448088');
INSERT INTO `pk_common_unusual` VALUES ('1790', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1495458536');
INSERT INTO `pk_common_unusual` VALUES ('1791', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1495501247');
INSERT INTO `pk_common_unusual` VALUES ('1792', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1495503861');
INSERT INTO `pk_common_unusual` VALUES ('1793', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1495603600');
INSERT INTO `pk_common_unusual` VALUES ('1794', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1495621666');
INSERT INTO `pk_common_unusual` VALUES ('1795', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1495718959');
INSERT INTO `pk_common_unusual` VALUES ('1796', '0全部回复1===17', '', '1495718959');
INSERT INTO `pk_common_unusual` VALUES ('1797', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1495718959');
INSERT INTO `pk_common_unusual` VALUES ('1798', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1495719957');
INSERT INTO `pk_common_unusual` VALUES ('1799', '0全部回复1===17', '', '1495719957');
INSERT INTO `pk_common_unusual` VALUES ('1800', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1495719957');
INSERT INTO `pk_common_unusual` VALUES ('1801', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1495756006');
INSERT INTO `pk_common_unusual` VALUES ('1802', '0全部回复1===17', '', '1495756006');
INSERT INTO `pk_common_unusual` VALUES ('1803', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1495756006');
INSERT INTO `pk_common_unusual` VALUES ('1804', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1495791105');
INSERT INTO `pk_common_unusual` VALUES ('1805', '0全部回复1===17', '', '1495791105');
INSERT INTO `pk_common_unusual` VALUES ('1806', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1495791105');
INSERT INTO `pk_common_unusual` VALUES ('1807', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1495893580');
INSERT INTO `pk_common_unusual` VALUES ('1808', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496124421');
INSERT INTO `pk_common_unusual` VALUES ('1809', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1496229587');
INSERT INTO `pk_common_unusual` VALUES ('1810', '0全部回复1===17', '', '1496229587');
INSERT INTO `pk_common_unusual` VALUES ('1811', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1496229587');
INSERT INTO `pk_common_unusual` VALUES ('1812', '0全部回复1===17', '', '1496229625');
INSERT INTO `pk_common_unusual` VALUES ('1813', '1全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1496229625');
INSERT INTO `pk_common_unusual` VALUES ('1814', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496295360');
INSERT INTO `pk_common_unusual` VALUES ('1815', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1496362204');
INSERT INTO `pk_common_unusual` VALUES ('1816', '0全部回复1===17', '', '1496362204');
INSERT INTO `pk_common_unusual` VALUES ('1817', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1496362204');
INSERT INTO `pk_common_unusual` VALUES ('1818', 'massmessage sendText a:3:{s:6:\"touser\";a:1:{i:0;N;}s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:27:\"撒旦发生地方按时的\";}}', '', '1496369209');
INSERT INTO `pk_common_unusual` VALUES ('1819', 'massmessage sendText a:3:{s:6:\"touser\";a:1:{i:0;N;}s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:37:\"啊撒旦法撒旦法所得到的2222\";}}', '', '1496369334');
INSERT INTO `pk_common_unusual` VALUES ('1820', 'massmessage sendText res b:0;', '', '1496369334');
INSERT INTO `pk_common_unusual` VALUES ('1821', 'massmessage sendText we_obj O:19:\"Weixin\\SDK\\TPWechat\":21:{s:24:\"\0Weixin\\SDK\\Wechat\0token\";s:8:\"cpktoken\";s:33:\"\0Weixin\\SDK\\Wechat\0encodingAesKey\";s:43:\"aAlvXvRXnnyrNoSvyaflEehqD6yV2W2Cf7zDHunG2S5\";s:31:\"\0Weixin\\SDK\\Wechat\0encrypt_type\";N;s:24:\"\0Weixin\\SDK\\Wechat\0appid\";s:18:\"wx13501fa5efd1c493\";s:28:\"\0Weixin\\SDK\\Wechat\0appsecret\";s:32:\"0c915391cefee2809676c095683273d6\";s:31:\"\0Weixin\\SDK\\Wechat\0access_token\";s:138:\"7RLz7jV91okXfMAnNfTbX8hUYwHzdWjP5FS2ftY-AQLOBz2V4b0-_W_cB4GsY_U-Z3vLjXtoZSQCPkHJ6exbZAg1VQZw-ZaSkSWrSe_F88fbiMvtyujtYWtvigTXtavVIBQiAGALET\";s:31:\"\0Weixin\\SDK\\Wechat\0jsapi_ticket\";N;s:29:\"\0Weixin\\SDK\\Wechat\0api_ticket\";N;s:29:\"\0Weixin\\SDK\\Wechat\0user_token\";N;s:28:\"\0Weixin\\SDK\\Wechat\0partnerid\";N;s:29:\"\0Weixin\\SDK\\Wechat\0partnerkey\";N;s:29:\"\0Weixin\\SDK\\Wechat\0paysignkey\";N;s:26:\"\0Weixin\\SDK\\Wechat\0postxml\";N;s:23:\"\0Weixin\\SDK\\Wechat\0_msg\";N;s:28:\"\0Weixin\\SDK\\Wechat\0_funcflag\";b:0;s:27:\"\0Weixin\\SDK\\Wechat\0_receive\";N;s:31:\"\0Weixin\\SDK\\Wechat\0_text_filter\";b:1;s:5:\"debug\";b:0;s:7:\"errCode\";i:40130;s:6:\"errMsg\";s:68:\"invalid openid list size, at least two openid hint: [dPy8pA0334ge21]\";s:11:\"logcallback\";b:0;}', '', '1496369334');
INSERT INTO `pk_common_unusual` VALUES ('1822', 'massmessage sendText a:3:{s:6:\"touser\";a:2:{i:0;N;i:1;N;}s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:15:\"测试群发123\";}}', '', '1496369438');
INSERT INTO `pk_common_unusual` VALUES ('1823', 'massmessage sendText res b:0;', '', '1496369438');
INSERT INTO `pk_common_unusual` VALUES ('1824', 'massmessage sendText we_obj O:19:\"Weixin\\SDK\\TPWechat\":21:{s:24:\"\0Weixin\\SDK\\Wechat\0token\";s:8:\"cpktoken\";s:33:\"\0Weixin\\SDK\\Wechat\0encodingAesKey\";s:43:\"aAlvXvRXnnyrNoSvyaflEehqD6yV2W2Cf7zDHunG2S5\";s:31:\"\0Weixin\\SDK\\Wechat\0encrypt_type\";N;s:24:\"\0Weixin\\SDK\\Wechat\0appid\";s:18:\"wx13501fa5efd1c493\";s:28:\"\0Weixin\\SDK\\Wechat\0appsecret\";s:32:\"0c915391cefee2809676c095683273d6\";s:31:\"\0Weixin\\SDK\\Wechat\0access_token\";s:138:\"7RLz7jV91okXfMAnNfTbX8hUYwHzdWjP5FS2ftY-AQLOBz2V4b0-_W_cB4GsY_U-Z3vLjXtoZSQCPkHJ6exbZAg1VQZw-ZaSkSWrSe_F88fbiMvtyujtYWtvigTXtavVIBQiAGALET\";s:31:\"\0Weixin\\SDK\\Wechat\0jsapi_ticket\";N;s:29:\"\0Weixin\\SDK\\Wechat\0api_ticket\";N;s:29:\"\0Weixin\\SDK\\Wechat\0user_token\";N;s:28:\"\0Weixin\\SDK\\Wechat\0partnerid\";N;s:29:\"\0Weixin\\SDK\\Wechat\0partnerkey\";N;s:29:\"\0Weixin\\SDK\\Wechat\0paysignkey\";N;s:26:\"\0Weixin\\SDK\\Wechat\0postxml\";N;s:23:\"\0Weixin\\SDK\\Wechat\0_msg\";N;s:28:\"\0Weixin\\SDK\\Wechat\0_funcflag\";b:0;s:27:\"\0Weixin\\SDK\\Wechat\0_receive\";N;s:31:\"\0Weixin\\SDK\\Wechat\0_text_filter\";b:1;s:5:\"debug\";b:0;s:7:\"errCode\";i:40031;s:6:\"errMsg\";s:42:\"invalid openid list hint: [T6HSsa0438ge20]\";s:11:\"logcallback\";b:0;}', '', '1496369438');
INSERT INTO `pk_common_unusual` VALUES ('1825', 'massmessage sendText a:3:{s:6:\"touser\";a:2:{i:0;s:28:\"opuAS1OLeRjJGH7BkFFrP7BJhk0c\";i:1;s:28:\"opuAS1J2Jtoa-D5TPOIIToCT8xck\";}s:7:\"msgtype\";s:4:\"text\";s:4:\"text\";a:1:{s:7:\"content\";s:18:\"测试群发内容\";}}', '', '1496369633');
INSERT INTO `pk_common_unusual` VALUES ('1826', 'massmessage sendText res a:3:{s:7:\"errcode\";i:0;s:6:\"errmsg\";s:27:\"send job submission success\";s:6:\"msg_id\";i:3147483663;}', '', '1496369633');
INSERT INTO `pk_common_unusual` VALUES ('1827', 'massmessage sendText we_obj O:19:\"Weixin\\SDK\\TPWechat\":21:{s:24:\"\0Weixin\\SDK\\Wechat\0token\";s:8:\"cpktoken\";s:33:\"\0Weixin\\SDK\\Wechat\0encodingAesKey\";s:43:\"aAlvXvRXnnyrNoSvyaflEehqD6yV2W2Cf7zDHunG2S5\";s:31:\"\0Weixin\\SDK\\Wechat\0encrypt_type\";N;s:24:\"\0Weixin\\SDK\\Wechat\0appid\";s:18:\"wx13501fa5efd1c493\";s:28:\"\0Weixin\\SDK\\Wechat\0appsecret\";s:32:\"0c915391cefee2809676c095683273d6\";s:31:\"\0Weixin\\SDK\\Wechat\0access_token\";s:138:\"PNIx0Ut8FNJ68sMcS55zEOG1rkLcbyLi1UYlLCZVP8eOda0gFtgh3iVoNoQ-gkupE4ngRiLIWnHC411lF0RUeABEqwzMDzSGFYHVpZfMHz8sTOwU9WumcSYOMDrppJwiLFIhAFAFZC\";s:31:\"\0Weixin\\SDK\\Wechat\0jsapi_ticket\";N;s:29:\"\0Weixin\\SDK\\Wechat\0api_ticket\";N;s:29:\"\0Weixin\\SDK\\Wechat\0user_token\";N;s:28:\"\0Weixin\\SDK\\Wechat\0partnerid\";N;s:29:\"\0Weixin\\SDK\\Wechat\0partnerkey\";N;s:29:\"\0Weixin\\SDK\\Wechat\0paysignkey\";N;s:26:\"\0Weixin\\SDK\\Wechat\0postxml\";N;s:23:\"\0Weixin\\SDK\\Wechat\0_msg\";N;s:28:\"\0Weixin\\SDK\\Wechat\0_funcflag\";b:0;s:27:\"\0Weixin\\SDK\\Wechat\0_receive\";N;s:31:\"\0Weixin\\SDK\\Wechat\0_text_filter\";b:1;s:5:\"debug\";b:0;s:7:\"errCode\";i:40001;s:6:\"errMsg\";s:9:\"no access\";s:11:\"logcallback\";b:0;}', '', '1496369633');
INSERT INTO `pk_common_unusual` VALUES ('1828', 'public_id:gh_26c67b09cb87,msg_id:3147483663接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483663\";s:10:\"TotalCount\";s:1:\"2\";s:11:\"FilterCount\";s:1:\"2\";s:9:\"SentCount\";s:1:\"2\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496369634');
INSERT INTO `pk_common_unusual` VALUES ('1829', 'public_id:gh_26c67b09cb87,msg_id:3147483664接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483664\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"1\";s:9:\"SentCount\";s:1:\"1\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496370467');
INSERT INTO `pk_common_unusual` VALUES ('1830', 'public_id:gh_26c67b09cb87,msg_id:3147483665接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483665\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"1\";s:9:\"SentCount\";s:1:\"1\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496371311');
INSERT INTO `pk_common_unusual` VALUES ('1831', 'public_id:gh_26c67b09cb87,msg_id:3147483666接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483666\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"1\";s:9:\"SentCount\";s:1:\"1\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496372105');
INSERT INTO `pk_common_unusual` VALUES ('1832', '0全部回复1===17', '', '1496372946');
INSERT INTO `pk_common_unusual` VALUES ('1833', '1全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1496372946');
INSERT INTO `pk_common_unusual` VALUES ('1834', 'public_id:gh_26c67b09cb87,msg_id:3147483667接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483667\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"1\";s:9:\"SentCount\";s:1:\"1\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496373161');
INSERT INTO `pk_common_unusual` VALUES ('1835', 'public_id:gh_268611be4300,msg_id:1000000005接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"1000000005\";s:10:\"TotalCount\";s:3:\"286\";s:11:\"FilterCount\";s:3:\"286\";s:9:\"SentCount\";s:3:\"286\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496397752');
INSERT INTO `pk_common_unusual` VALUES ('1836', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1496449486');
INSERT INTO `pk_common_unusual` VALUES ('1837', '0全部回复1===17', '', '1496449486');
INSERT INTO `pk_common_unusual` VALUES ('1838', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1496449486');
INSERT INTO `pk_common_unusual` VALUES ('1839', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496472198');
INSERT INTO `pk_common_unusual` VALUES ('1840', '0全部回复1===17', '', '1496478209');
INSERT INTO `pk_common_unusual` VALUES ('1841', '1全部回复3===JVcALzQknkVneRbAfbE8KmSUpMncpsm9Y4qQ_D0KEXw', '', '1496478209');
INSERT INTO `pk_common_unusual` VALUES ('1842', 'public_id:gh_26c67b09cb87,msg_id:3147483668接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483668\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"0\";s:9:\"SentCount\";s:1:\"0\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496478223');
INSERT INTO `pk_common_unusual` VALUES ('1843', '0全部回复1===17', '', '1496478738');
INSERT INTO `pk_common_unusual` VALUES ('1844', '1全部回复3===JVcALzQknkVneRbAfbE8KtvkIzrB6BuQgW0d8YMP4Ac', '', '1496478738');
INSERT INTO `pk_common_unusual` VALUES ('1845', '0全部回复1===17', '', '1496478765');
INSERT INTO `pk_common_unusual` VALUES ('1846', '1全部回复3===JVcALzQknkVneRbAfbE8KuDneGjgJybdP9sxKc5TKGM', '', '1496478765');
INSERT INTO `pk_common_unusual` VALUES ('1847', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496482585');
INSERT INTO `pk_common_unusual` VALUES ('1848', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496498426');
INSERT INTO `pk_common_unusual` VALUES ('1849', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496657181');
INSERT INTO `pk_common_unusual` VALUES ('1850', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496722153');
INSERT INTO `pk_common_unusual` VALUES ('1851', 'public_id:gh_268611be4300,msg_id:3147483654接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483654\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"1\";s:9:\"SentCount\";s:1:\"1\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496742315');
INSERT INTO `pk_common_unusual` VALUES ('1852', '0全部回复1===17', '', '1496801981');
INSERT INTO `pk_common_unusual` VALUES ('1853', '1全部回复3===JVcALzQknkVneRbAfbE8KuDneGjgJybdP9sxKc5TKGM', '', '1496801981');
INSERT INTO `pk_common_unusual` VALUES ('1854', 'public_id:gh_26c67b09cb87,msg_id:3147483669接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483669\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"0\";s:9:\"SentCount\";s:1:\"0\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1496801996');
INSERT INTO `pk_common_unusual` VALUES ('1855', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496900892');
INSERT INTO `pk_common_unusual` VALUES ('1856', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1496905848');
INSERT INTO `pk_common_unusual` VALUES ('1857', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497077805');
INSERT INTO `pk_common_unusual` VALUES ('1858', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497078017');
INSERT INTO `pk_common_unusual` VALUES ('1859', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497178238');
INSERT INTO `pk_common_unusual` VALUES ('1860', 'a:14:{s:2:\"id\";s:2:\"17\";s:9:\"public_id\";s:15:\"gh_26c67b09cb87\";s:5:\"title\";s:15:\"二手车关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:2:\"-1\";s:9:\"reply_num\";s:1:\"2\";s:14:\"reply_type_ids\";s:3:\"1|2\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:46:\"17|JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1493866990\";s:10:\"updatetime\";s:10:\"1494647301\";}', '', '1497343828');
INSERT INTO `pk_common_unusual` VALUES ('1861', '0全部回复1===17', '', '1497343828');
INSERT INTO `pk_common_unusual` VALUES ('1862', '1全部回复2===JVcALzQknkVneRbAfbE8KqbMnpk4h_-sZWdPDTAxTtQ', '', '1497343828');
INSERT INTO `pk_common_unusual` VALUES ('1863', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497346989');
INSERT INTO `pk_common_unusual` VALUES ('1864', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497420413');
INSERT INTO `pk_common_unusual` VALUES ('1865', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497424025');
INSERT INTO `pk_common_unusual` VALUES ('1866', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497445369');
INSERT INTO `pk_common_unusual` VALUES ('1867', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497445381');
INSERT INTO `pk_common_unusual` VALUES ('1868', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497445418');
INSERT INTO `pk_common_unusual` VALUES ('1869', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497482692');
INSERT INTO `pk_common_unusual` VALUES ('1870', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497595094');
INSERT INTO `pk_common_unusual` VALUES ('1871', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497615590');
INSERT INTO `pk_common_unusual` VALUES ('1872', 'a:14:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1497767955');
INSERT INTO `pk_common_unusual` VALUES ('1873', 'public_id:gh_268611be4300,msg_id:3147483655接受到来自微信的群发结束的通知，来自eventa:6:{s:6:\"Status\";s:12:\"send success\";s:5:\"MsgID\";s:10:\"3147483655\";s:10:\"TotalCount\";s:1:\"1\";s:11:\"FilterCount\";s:1:\"1\";s:9:\"SentCount\";s:1:\"1\";s:10:\"ErrorCount\";s:1:\"0\";}', '', '1498275654');
INSERT INTO `pk_common_unusual` VALUES ('1874', '发送红包返回结果', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:38:\"参数错误:输入的商户号有误.\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:11:\"PARAM_ERROR\";s:12:\"err_code_des\";s:38:\"参数错误:输入的商户号有误.\";s:10:\"mch_billno\";s:16:\"static1498618819\";s:6:\"mch_id\";a:0:{}s:7:\"wxappid\";a:0:{}s:9:\"re_openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"total_amount\";s:3:\"100\";}', '1498618819');
INSERT INTO `pk_common_unusual` VALUES ('1875', '发送红包返回结果', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:60:\"证书出错，请登录微信支付商户平台下载证书\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:8:\"CA_ERROR\";s:12:\"err_code_des\";s:60:\"证书出错，请登录微信支付商户平台下载证书\";s:10:\"mch_billno\";s:16:\"static1498619254\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"total_amount\";s:3:\"100\";}', '1498619254');
INSERT INTO `pk_common_unusual` VALUES ('1876', '发送红包返回结果', 'a:10:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:60:\"证书出错，请登录微信支付商户平台下载证书\";s:11:\"result_code\";s:4:\"FAIL\";s:8:\"err_code\";s:8:\"CA_ERROR\";s:12:\"err_code_des\";s:60:\"证书出错，请登录微信支付商户平台下载证书\";s:10:\"mch_billno\";s:16:\"static1498619581\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"total_amount\";s:3:\"100\";}', '1498619581');
INSERT INTO `pk_common_unusual` VALUES ('1877', '发送红包返回结果', 'a:11:{s:11:\"return_code\";s:7:\"SUCCESS\";s:10:\"return_msg\";s:12:\"发放成功\";s:11:\"result_code\";s:7:\"SUCCESS\";s:8:\"err_code\";s:7:\"SUCCESS\";s:12:\"err_code_des\";s:12:\"发放成功\";s:10:\"mch_billno\";s:16:\"static1498619770\";s:6:\"mch_id\";s:10:\"1456756702\";s:7:\"wxappid\";s:18:\"wx91792eed99d54d82\";s:9:\"re_openid\";s:28:\"od87006dZbELiKqoGDFjQ9g4Ow48\";s:12:\"total_amount\";s:3:\"100\";s:11:\"send_listid\";s:31:\"1000041701201706283000040699129\";}', '1498619771');
INSERT INTO `pk_common_unusual` VALUES ('1878', 'a:15:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:12:\"local_status\";s:1:\"1\";s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1498636593');
INSERT INTO `pk_common_unusual` VALUES ('1879', 'a:15:{s:2:\"id\";s:2:\"21\";s:9:\"public_id\";s:15:\"gh_268611be4300\";s:5:\"title\";s:12:\"语记关注\";s:12:\"trigger_type\";s:2:\"-1\";s:13:\"is_reply_rand\";s:1:\"0\";s:10:\"reply_type\";s:1:\"1\";s:9:\"reply_num\";s:1:\"1\";s:14:\"reply_type_ids\";s:1:\"1\";s:14:\"reply_nums_str\";s:0:\"\";s:12:\"keywords_str\";s:2:\"||\";s:12:\"media_id_str\";s:0:\"\";s:5:\"token\";N;s:12:\"local_status\";s:1:\"1\";s:7:\"addtime\";s:10:\"1492847867\";s:10:\"updatetime\";s:10:\"1494230472\";}', '', '1498970696');

-- -----------------------------
-- Table structure for `pk_file`
-- -----------------------------
DROP TABLE IF EXISTS `pk_file`;
CREATE TABLE `pk_file` (
  `id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(12) NOT NULL COMMENT '所属项目ID',
  `code` varchar(50) NOT NULL COMMENT '项目标识',
  `uid` int(12) DEFAULT '0' COMMENT '所属会员',
  `url` varchar(255) NOT NULL COMMENT '资源地址',
  `filename` varchar(255) NOT NULL,
  `media_id` varchar(50) DEFAULT '',
  `wechat_url` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL COMMENT '文件原始名称',
  `sha1` varchar(40) NOT NULL COMMENT '文件内容的秘串',
  `ext` varchar(60) NOT NULL,
  `filesize` int(12) NOT NULL,
  `width` int(6) NOT NULL,
  `height` int(6) NOT NULL,
  `addtime` int(12) NOT NULL COMMENT '上传时间',
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_file`
-- -----------------------------
INSERT INTO `pk_file` VALUES ('1', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/1d9b987e216d60292.jpg', '1d9b987e216d60292', 'efzRilNNFDo0wX9aR4jkLOwKTcRo_v7iWwdPcA-DoRY', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzYguuNhpNkvJrNl6ZiczXrRfcza2xiagP2OVf70yfqW7KRgEUw3WOicE82cnqDKoI41mMkVhUN5zbliaQ/0?wx_fmt=jpeg', '品牌_03.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '99134', '0', '0', '1502498526', '1');
INSERT INTO `pk_file` VALUES ('2', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/2336f472193977515.jpg', '2336f472193977515', 'efzRilNNFDo0wX9aR4jkLNgrWv8Nk9ixz-6MKdy9a0Q', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzYguuNhpNkvJrNl6ZiczXrRfo2QeQcU7NohNUPKEGaicOwM5OhHKXyVeTSRKBcEaChxykDm7zpKdqaA/0?wx_fmt=jpeg', '品牌_02.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '166801', '0', '0', '1502498526', '1');
INSERT INTO `pk_file` VALUES ('3', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/a0bcf04bdf652adc2.jpg', 'a0bcf04bdf652adc2', 'efzRilNNFDo0wX9aR4jkLH_Ogh_Cag47-1OrE2s-UXg', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzYguuNhpNkvJrNl6ZiczXrRfUI8D05U0vZQQ0uDDfic1YthB9IiceQVJFgmQDWkiar0RzPicT855uibUItw/0?wx_fmt=jpeg', '品牌_01.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '150348', '0', '0', '1502498527', '1');
INSERT INTO `pk_file` VALUES ('4', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0e97069a38a7233e3.jpg', '0e97069a38a7233e3', 'efzRilNNFDo0wX9aR4jkLG0Ib_corAQdkJnzbtrkP6w', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzYguuNhpNkvJrNl6ZiczXrRfAYXwAOT9aAr57sxse8nD7qRW2oUvTrxBswpKjtfibTygqY5F86biadGQ/0?wx_fmt=jpeg', '900.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '22346', '0', '0', '1502498527', '1');
INSERT INTO `pk_file` VALUES ('5', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e35c24c22cacaec70.jpg', 'e35c24c22cacaec70', 'efzRilNNFDo0wX9aR4jkLHU-T7gEDybA9U0KXEz2OUc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzaibwshy5MLI3icy5dz8VIWcPHiclIbMcYzrYWcgERjRaiaG71FdB38EfumMicHyNkevQfJTKJGWz1ibcpw/0?wx_fmt=jpeg', '/home/hott/website/base-think/data/uploads/201706/weixin_news_cover/d47c74169b891f70c.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '52726', '0', '0', '1502498527', '1');
INSERT INTO `pk_file` VALUES ('6', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/6d1098dd752c56832.jpg', '6d1098dd752c56832', 'efzRilNNFDo0wX9aR4jkLCj2474khL5FvGZ6gpdihmQ', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzbvmtUoFVWXKOhCaozwY2Eh7wSlYRpUVzYeHHhB26iaTzWqVeBJ5hK1qFR8icTObcrv2GVFpkveKRxQ/0?wx_fmt=jpeg', 'apic18931.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '31138', '0', '0', '1502498528', '1');
INSERT INTO `pk_file` VALUES ('7', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/81f2c432a8b68998e.jpg', '81f2c432a8b68998e', 'efzRilNNFDo0wX9aR4jkLFACw0U0gVy-WChHR-8ISeI', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzZicdqicJphQZaozS8HpyJNd6DMBB1adE3uRCcg5sLT88sRGl0y89Jc71xiaiasueDVD0PH49UGnWyQaw/0?wx_fmt=jpeg', '/home/hott/website/base-think/data/uploads/201705/weixin_news_cover/efc4592fed74faab5.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '57097', '0', '0', '1502498528', '1');
INSERT INTO `pk_file` VALUES ('8', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/65c498d91d566636b.jpg', '65c498d91d566636b', 'efzRilNNFDo0wX9aR4jkLCDiQwPFNn-F8dogPBTrpII', 'http://mmbiz.qpic.cn/mmbiz_png/LCKF8M32tzZicdqicJphQZaozS8HpyJNd6OHcqCoal7Qpfu4kbzu2vfKqaoiaPuc9Dl7ibzFAQwGCsqsoG51EtmRsQ/0?wx_fmt=png', '/home/hott/website/base-think/data/uploads/201705/weixin_news_cover/d4e1394e36bacdc65.png', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '34438', '0', '0', '1502498528', '1');
INSERT INTO `pk_file` VALUES ('9', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/7e5db11df0b6aa946.jpg', '7e5db11df0b6aa946', 'efzRilNNFDo0wX9aR4jkLEHAquXZ_NqNWrwO90Fpxxo', 'http://mmbiz.qpic.cn/mmbiz_png/LCKF8M32tzaUCoMOlQYRfJkN2j7Q6tAynr8kQxkUCbMDKyzCovickibPvfTJzow1SYsBm4j8opIFM5m9GoS9bTqQ/0?wx_fmt=png', '/home/hott/website/base-think/data/uploads/201705/weixin_news_cover/e3b75d123160df597.png', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '23357', '0', '0', '1502498528', '1');
INSERT INTO `pk_file` VALUES ('10', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/832e2cc1e8088f820.jpg', '832e2cc1e8088f820', 'efzRilNNFDo0wX9aR4jkLIPR6hb3_p2_gB1bRo7I4sw', 'http://mmbiz.qpic.cn/mmbiz_png/LCKF8M32tzbSkk2aCEgibmt8J2cnSzpCanI0nhQfibU5UibqG6EKPYptgWh8xO7W1cL67KAzGIjmLFoo3qpbWhrbg/0?wx_fmt=png', 'logo.png', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '27189', '0', '0', '1502498529', '1');
INSERT INTO `pk_file` VALUES ('11', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/52048e31c8820a2ff.jpg', '52048e31c8820a2ff', 'efzRilNNFDo0wX9aR4jkLETC7uQeYsXp3wcwIDIF29w', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzYVOHibicKYpk4eqh01bctc4z3iaicjd74iaT0LnEcSqd3303VcnnXqYI7zlFqp8QttflG4ASic6HolFOnA/0?wx_fmt=jpeg', 'timg (17).jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '22828', '0', '0', '1502498529', '1');
INSERT INTO `pk_file` VALUES ('12', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/188eba60bebc6a4dd.jpg', '188eba60bebc6a4dd', 'efzRilNNFDo0wX9aR4jkLPIVSVDw3C6zvD2obx1VrW8', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a8OiaJ4icYtgv9zBJHJpV1U1GUBbVzv7mVLZq5lwibl2icIwKJslY5vtYFQ/0?wx_fmt=jpeg', 'timg.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '32712', '0', '0', '1502498529', '1');
INSERT INTO `pk_file` VALUES ('13', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/995ea8cbdd1b89617.jpg', '995ea8cbdd1b89617', 'efzRilNNFDo0wX9aR4jkLD5jlT7qurJL0mFM9IB0z0s', 'http://mmbiz.qpic.cn/mmbiz_png/LCKF8M32tzarpHu6AMV40QIwb1xLAI1amQHg1QeNas00ic5gPVeU7jiaOzzj1cTPd5bzSicSSL7FV6lU6CNib2uG8A/0?wx_fmt=png', 'QQ截图20170331130626.png', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '34585', '0', '0', '1502498529', '1');
INSERT INTO `pk_file` VALUES ('14', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e842c929a79fef0d4.jpg', 'e842c929a79fef0d4', 'efzRilNNFDo0wX9aR4jkLHW9YVc_EsXin2ZLr-a_6ME', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a0rCulfb3Bx8FOLCY0icXlkSJlbeic276xkowFgIlAhe7jjBcJvgMd9gg/0?wx_fmt=jpeg', '084A5787.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '24848', '0', '0', '1502498530', '1');
INSERT INTO `pk_file` VALUES ('15', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/f83f8ddc4f7882d09.jpg', 'f83f8ddc4f7882d09', 'efzRilNNFDo0wX9aR4jkLHjyfMlySeas0JuBQMwuLls', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aSXtvuTvJ6sKX4yyQ53r9bXXSbLrHneliaaMiaIpzic6s98hA65GOMMWXA/0?wx_fmt=jpeg', '084A5732.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '8779', '0', '0', '1502498530', '1');
INSERT INTO `pk_file` VALUES ('16', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/68e2630276e13a0eb.jpg', '68e2630276e13a0eb', 'efzRilNNFDo0wX9aR4jkLIa2z6VTx43snOH2Nn50DFY', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aBjOYp2ZHManFAI8wSbtfPGabZMcYCSGP5jZr8Fks8QvP3XHf7ZxJXw/0?wx_fmt=jpeg', '084A5698.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10920', '0', '0', '1502498530', '1');
INSERT INTO `pk_file` VALUES ('17', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0e194198a76f77a4a.jpg', '0e194198a76f77a4a', 'efzRilNNFDo0wX9aR4jkLJ6kflWoTyLrHPrtz80NkkE', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1ad3nqTFEdDsiaJ05v6PHYKl9Quw6g4XFxWdpHq67pJMWWJHjPcHck8UQ/0?wx_fmt=jpeg', '084A5696.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10499', '0', '0', '1502498530', '1');
INSERT INTO `pk_file` VALUES ('18', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/17a480c86f46997e2.jpg', '17a480c86f46997e2', 'efzRilNNFDo0wX9aR4jkLIulsWlIqGjWhM6WXbfrptY', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aCibQ9RQj5d6o97gGRsKtz2RhVwHo31Y281PlKvx6iagLNZ7pIl3lFK7Q/0?wx_fmt=jpeg', '084A5695.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10291', '0', '0', '1502498531', '1');
INSERT INTO `pk_file` VALUES ('19', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0574c62025f9ffe13.jpg', '0574c62025f9ffe13', 'efzRilNNFDo0wX9aR4jkLIJSwmvgpuOpb1pxUjdrWn0', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aX0Ebia3GnHOU4JkdRHWVMqiaibvr6rlrGz6sKwvC4DvcIBkRbfFzKYtIA/0?wx_fmt=jpeg', '084A5694.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10702', '0', '0', '1502498531', '1');
INSERT INTO `pk_file` VALUES ('20', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/64a1c61512e9117a1.jpg', '64a1c61512e9117a1', 'efzRilNNFDo0wX9aR4jkLIffTHufcgVsI1UtzI9fkcM', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1ajmz7t5FTIZ6ZkNibibB8tIMe82Bf1F4ic5TC5ibLuEHXjXicbVTANm445WA/0?wx_fmt=jpeg', '084A5693.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10923', '0', '0', '1502498531', '1');
INSERT INTO `pk_file` VALUES ('21', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/f36cba1558826d1ab.jpg', 'f36cba1558826d1ab', 'efzRilNNFDo0wX9aR4jkLAy7tW2iIOPrDjZxMczoH08', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1arvH3c9ebXN17p589RGziaSws2zwmAkMqKHwAxg8eD9IibEv9hKySVicaA/0?wx_fmt=jpeg', '084A5692.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '9693', '0', '0', '1502498533', '1');
INSERT INTO `pk_file` VALUES ('22', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/499d193cf6792ec51.jpg', '499d193cf6792ec51', 'efzRilNNFDo0wX9aR4jkLB1o2_jyA5SyZzkoWiFfEvc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aYDibSN84LIMWyOX1PzIyBicqUAJmEbqvD9wIeovOYmASiaIP9BTzibdzVw/0?wx_fmt=jpeg', '084A5657.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '26190', '0', '0', '1502498533', '1');
INSERT INTO `pk_file` VALUES ('23', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/fe7bfccbc9ae7a129.jpg', 'fe7bfccbc9ae7a129', 'efzRilNNFDo0wX9aR4jkLLnRwIWsTNGx2Fc77XXMV-s', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1ahCwNo4nfOggY8FzLugI1pj8pU4yIzD6DicFiaRJ6NQAmTJd8AXW3KJ1g/0?wx_fmt=jpeg', '084A5616.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '21814', '0', '0', '1502498533', '1');
INSERT INTO `pk_file` VALUES ('24', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/00d10a86a10573007.jpg', '00d10a86a10573007', 'efzRilNNFDo0wX9aR4jkLFqOytEPycN_qOZC2Q8Q43k', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1ahERd42uG0ojGTictxKRKMYDlJiaN9aQkkqzTFOcerM6BEOz0C6iaT57gA/0?wx_fmt=jpeg', '084A5658.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '15358', '0', '0', '1502498533', '1');
INSERT INTO `pk_file` VALUES ('25', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/d32ddef4e573f0f62.jpg', 'd32ddef4e573f0f62', 'efzRilNNFDo0wX9aR4jkLADWi6A99wB3jzazXgcE-z8', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aybEnpwZGbEVVChKcXTQ5NMnYPjkaunJbWklq3AXCHl838ftOcVW68g/0?wx_fmt=jpeg', '084A5663.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '12313', '0', '0', '1502498533', '1');
INSERT INTO `pk_file` VALUES ('26', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/c20fe3a323b806cda.jpg', 'c20fe3a323b806cda', 'efzRilNNFDo0wX9aR4jkLKTzk_pAb_Nq5gheZD_ifjk', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aQ6lHrQcIVgqdrCJIEXyphWNfufMEAZibx0B6lIhbnnOFarBaPibjM1ww/0?wx_fmt=jpeg', '084A5691.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10781', '0', '0', '1502498534', '1');
INSERT INTO `pk_file` VALUES ('27', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0f87c7670878095bf.jpg', '0f87c7670878095bf', 'efzRilNNFDo0wX9aR4jkLHJyHFrlkEUXflnjiewvKiM', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aBDgXBqbSoyOA13zV8rCibuicc96sx3sNn8e4ReskXNy14kxBO3pQibsBQ/0?wx_fmt=jpeg', '084A5606.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '42959', '0', '0', '1502498534', '1');
INSERT INTO `pk_file` VALUES ('28', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/d0b6bccf1a8394fe0.jpg', 'd0b6bccf1a8394fe0', 'efzRilNNFDo0wX9aR4jkLBrC6KjslsKSgjPunHWZZ1I', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1amEjUIDIxyJfECosEVLvnGF3uORCfN3lOOk1gGtUSG83eNorME3wFXQ/0?wx_fmt=jpeg', '084A5599.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '37769', '0', '0', '1502498535', '1');
INSERT INTO `pk_file` VALUES ('29', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/478f6f5fe60504c1e.jpg', '478f6f5fe60504c1e', 'efzRilNNFDo0wX9aR4jkLJjyLNSp6RRejPLBRji54m8', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1abcvRiamlsV8kbtdt93pPkdQp5DQyfRiaRyNr4JSa7AfTiaWmxs5Qqhr0w/0?wx_fmt=jpeg', '084A5590.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '12592', '0', '0', '1502498535', '1');
INSERT INTO `pk_file` VALUES ('30', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/9c34a3e8acbebb554.jpg', '9c34a3e8acbebb554', 'efzRilNNFDo0wX9aR4jkLB3ZdePC-mv-25q-R3ApsqQ', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aO1uxotxTFy8EpdY5TLY6dibSq2Zib1JKADwZdiap2OkE6NykDmrH5ab6A/0?wx_fmt=jpeg', '084A5585.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '13136', '0', '0', '1502498535', '1');
INSERT INTO `pk_file` VALUES ('31', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/11d19ac135aaf2d0b.jpg', '11d19ac135aaf2d0b', 'efzRilNNFDo0wX9aR4jkLLpk-jVOsZ1E6E4keE5kbg4', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aKEze0aOfC6IxrAtQxS1LibjlXe1tgheZIMvYLNDjBmibGsOwas208u1A/0?wx_fmt=jpeg', '084A5785.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '34195', '0', '0', '1502498535', '1');
INSERT INTO `pk_file` VALUES ('32', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/d554594219230f946.jpg', 'd554594219230f946', 'efzRilNNFDo0wX9aR4jkLNneKpoPDtEo1I7o2KDsY30', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aLfLWlaiaWO8kdgE14shbibK2gPCCwV9Z6BVNT7cXOkicxHGwiashEe4BfA/0?wx_fmt=jpeg', '084A5779.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '46355', '0', '0', '1502498536', '1');
INSERT INTO `pk_file` VALUES ('33', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e818d0ab0bcec198e.jpg', 'e818d0ab0bcec198e', 'efzRilNNFDo0wX9aR4jkLLPIlPsgL5uRuxlpQGrdOVU', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1alxSUkxOaMjebjosVVgfVH8qhEsnUqs16RoT0oz4swm9eEZcOOXMI6Q/0?wx_fmt=jpeg', '084A5765.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '11835', '0', '0', '1502498536', '1');
INSERT INTO `pk_file` VALUES ('34', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/9f140070e5d290ae4.jpg', '9f140070e5d290ae4', 'efzRilNNFDo0wX9aR4jkLOfjg5h-9XTPO97sISB95NU', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aCicoWMwibKDsXSIspBp9A0Vbvquib5BFC42iaR4fjmuXoWxOa3nfI60CGg/0?wx_fmt=jpeg', '084A5762.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '8738', '0', '0', '1502498536', '1');
INSERT INTO `pk_file` VALUES ('35', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/f91082855fc597523.jpg', 'f91082855fc597523', 'efzRilNNFDo0wX9aR4jkLJAdUgLHkhcZMf9-ymuk2ig', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aTMLicE7ib7WT4mkIwW84kRP1edJAA1icBMKCUserGqcA0PLhhq6D9lsAA/0?wx_fmt=jpeg', '084A5739.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '6460', '0', '0', '1502498536', '1');
INSERT INTO `pk_file` VALUES ('36', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/2def4fb7b3425a3a4.jpg', '2def4fb7b3425a3a4', 'efzRilNNFDo0wX9aR4jkLAAQOQ-fYEfmBUJ8OquZSLc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aMaUk8r6I1ib4ribKbpUugrF0rks49M8oDShiceGBj6hQvz0VIcrSHiaPGA/0?wx_fmt=jpeg', '084A5764.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '21446', '0', '0', '1502498536', '1');
INSERT INTO `pk_file` VALUES ('37', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/6ab8c6e71e0f2096c.jpg', '6ab8c6e71e0f2096c', 'efzRilNNFDo0wX9aR4jkLH5IiHmUdNJXbyOePQPnyJc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aiavuwf44J3ediauLZ2q9h1DEa1d8eRS8ic3vWgmvZokhibugAKuPAp4IiaQ/0?wx_fmt=jpeg', '084A5717.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '12293', '0', '0', '1502498537', '1');
INSERT INTO `pk_file` VALUES ('38', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/2af0482a60b8441c4.jpg', '2af0482a60b8441c4', 'efzRilNNFDo0wX9aR4jkLI33gfAt4dCH-37cd4dUhpU', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1auRfLsIfrTCjXoYl5OZrucicKEgY3UQkNKLvhaKEyoicrNLZGtfDdkJfQ/0?wx_fmt=jpeg', '084A5716.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10222', '0', '0', '1502498537', '1');
INSERT INTO `pk_file` VALUES ('39', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/2a19b740383ee94a0.jpg', '2a19b740383ee94a0', 'efzRilNNFDo0wX9aR4jkLJg6FVhiyqRKChvlz9Ym69k', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aiaTtzDerO1skk9SMn9NoiaCra1rwQIDaMNMw35icKCXZoedcdNQ1UxJkg/0?wx_fmt=jpeg', '084A5715.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10178', '0', '0', '1502498537', '1');
INSERT INTO `pk_file` VALUES ('40', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e3e805ac30c80b611.jpg', 'e3e805ac30c80b611', 'efzRilNNFDo0wX9aR4jkLN8vS0zT0f9OTuY239qFoxU', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aLbaFGb3B6v6ucE9f6nQHibzaERiapoD8ZDfAiaVWoLRYlO4RnYLNSS1Jg/0?wx_fmt=jpeg', '084A5714.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10486', '0', '0', '1502498537', '1');
INSERT INTO `pk_file` VALUES ('41', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/cd8dcea57b2844bf5.jpg', 'cd8dcea57b2844bf5', 'efzRilNNFDo0wX9aR4jkLFnASQtMs-X_1s5Kahgv7GA', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aUybiciaB1KlxjicPmDW9HXtJ9TfK4CFic083fvd1rbo7A6gaGPK7D6IfVQ/0?wx_fmt=jpeg', '084A5713.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '9643', '0', '0', '1502498539', '1');
INSERT INTO `pk_file` VALUES ('42', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/c6a64c165a79fda08.jpg', 'c6a64c165a79fda08', 'efzRilNNFDo0wX9aR4jkLJ-bmykN6VOmcLKpK1-oIjo', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1as2NZ3SaRUfszttU66PgNclqEiaHNpgraybVZsxtMS3gJO6QWTnq0jZg/0?wx_fmt=jpeg', '084A5706.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10717', '0', '0', '1502498539', '1');
INSERT INTO `pk_file` VALUES ('43', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/307184f16f71a0146.jpg', '307184f16f71a0146', 'efzRilNNFDo0wX9aR4jkLByr1es6afoo97snXZ1RF-c', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aDhahCLpj6oGhzVKH1QOZlPbp2Qt5o0G9xPPXNdqHrZHuyo3iavuZtZQ/0?wx_fmt=jpeg', '084A5620.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '41402', '0', '0', '1502498539', '1');
INSERT INTO `pk_file` VALUES ('44', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/a9648ede4505484eb.jpg', 'a9648ede4505484eb', 'efzRilNNFDo0wX9aR4jkLIUBDVAcuCH8B4jVw9av8Xs', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aKOvZryF3WvZ2aOJNwnicGMTpQB3jHhuUNmbqIAOEIa4uUSIbsgibPib0w/0?wx_fmt=jpeg', '084A5618.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '14204', '0', '0', '1502498540', '1');
INSERT INTO `pk_file` VALUES ('45', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/37f3f2196eedebaf7.jpg', '37f3f2196eedebaf7', 'efzRilNNFDo0wX9aR4jkLHiWfKH3yt7TJUmcl-QJP2s', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a0kYa4OGYdErOMLG7lw5IY6M3sEfZeqanUIQZ5AZv1nyqgBehU8jqrA/0?wx_fmt=jpeg', '084A5774.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '23825', '0', '0', '1502498540', '1');
INSERT INTO `pk_file` VALUES ('46', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e965acb0157fd586a.jpg', 'e965acb0157fd586a', 'efzRilNNFDo0wX9aR4jkLNi97g8Ezn02maEHmHdu8Lc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aScfw6UWOrSBTcTkxkjFh5mpO3w1VC3yXdsqibGzJrSssVI0KgkXNcFQ/0?wx_fmt=jpeg', '084A5759.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '5222', '0', '0', '1502498540', '1');
INSERT INTO `pk_file` VALUES ('47', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/a3b0bdaa92e78d6f7.jpg', 'a3b0bdaa92e78d6f7', 'efzRilNNFDo0wX9aR4jkLFpeRGkWVQJSp419SHcWWyQ', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1apPRezatzy1Vicia1cbbU434ibXop3YTemScHVwarEMX3eEuS5mN9LoC3A/0?wx_fmt=jpeg', '084A5753.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '6723', '0', '0', '1502498540', '1');
INSERT INTO `pk_file` VALUES ('48', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/bcd8e9db7a3dc4626.jpg', 'bcd8e9db7a3dc4626', 'efzRilNNFDo0wX9aR4jkLHYT527L57p6zxrPPXsNqH0', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aibH4Gdiafe18OaiaBCzAY0CCegzapNJlS9XH7baAJiaJhnTiaduooZoicH4g/0?wx_fmt=jpeg', '084A5742.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '6109', '0', '0', '1502498540', '1');
INSERT INTO `pk_file` VALUES ('49', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/fa9f706ca4b5fdce7.jpg', 'fa9f706ca4b5fdce7', 'efzRilNNFDo0wX9aR4jkLGqerdjGJB0PF2SxH1Ood2Y', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aic9oLKL2A1EnmvKS1VibpXAhCeJnpWIajssb8Uaicbt7mP7h6sR0eYMrw/0?wx_fmt=jpeg', '084A5720.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '8573', '0', '0', '1502498541', '1');
INSERT INTO `pk_file` VALUES ('50', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/b5c31b2306920ecdc.jpg', 'b5c31b2306920ecdc', 'efzRilNNFDo0wX9aR4jkLBGZBbZcS5PF6Kmm1qE3vzA', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aEhkMfrv2Hm1ZchRoVX3HmvTjBpjnthTFZGAUSo8FaRCZF3iaqIQicrVw/0?wx_fmt=jpeg', '084A5747.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '16570', '0', '0', '1502498541', '1');
INSERT INTO `pk_file` VALUES ('51', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/da6c323c145c2f1b5.jpg', 'da6c323c145c2f1b5', 'efzRilNNFDo0wX9aR4jkLDqLxjDlfIXfi1ZYvlFQpas', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aIFViaSanh4DXq74Iic5pfcYAdMI1khExaGpWX7txnuuzR7pzO5f61puA/0?wx_fmt=jpeg', '084A5675.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '14598', '0', '0', '1502498541', '1');
INSERT INTO `pk_file` VALUES ('52', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/c8ffba1793d16fa49.jpg', 'c8ffba1793d16fa49', 'efzRilNNFDo0wX9aR4jkLKawbmIQqdKk2gWur82wjGc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a0OxgrRQ56DFaLT4czo02rDrUCG1rNkIkEAXzVdIq3nm5MOj6GsQZSQ/0?wx_fmt=jpeg', '084A5651.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '9014', '0', '0', '1502498541', '1');
INSERT INTO `pk_file` VALUES ('53', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0ffaca71aca962272.jpg', '0ffaca71aca962272', 'efzRilNNFDo0wX9aR4jkLJ8TU7pxlMqyHKZwJCO-7oQ', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aSyXaJHQPy5XKF84hs6KR1pBjxfwA6PuNup7uCxzHhiaukXN6MUjXribQ/0?wx_fmt=jpeg', '084A5642.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10752', '0', '0', '1502498542', '1');
INSERT INTO `pk_file` VALUES ('54', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/15c87a679c872c2e5.jpg', '15c87a679c872c2e5', 'efzRilNNFDo0wX9aR4jkLHH9GrpqKoIP-MF0aF2Js_g', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a1GNhVoXhHuqE2lgYiaBmEe3M3CT9b2qIf44WczmugOvWvWC2kxE6VPA/0?wx_fmt=jpeg', '084A5640.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '26368', '0', '0', '1502498542', '1');
INSERT INTO `pk_file` VALUES ('55', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e161d1fb762006493.jpg', 'e161d1fb762006493', 'efzRilNNFDo0wX9aR4jkLEc0FduYhc15Pe1zwaqCs3A', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aDw8MsbMRBexPtgqiccLzjFTTYEFoZibBTqTkzkwt1r3iacwrADthpo93Q/0?wx_fmt=jpeg', '084A5581.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '33484', '0', '0', '1502498542', '1');
INSERT INTO `pk_file` VALUES ('56', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/ca2754b88db2f18c2.jpg', 'ca2754b88db2f18c2', 'efzRilNNFDo0wX9aR4jkLGNfjAqJyvtL8iJjQ8TBBSY', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aGMbaOc2e4yCOVbJ99EmNaRW7yDgSPTLDSVvr0icTrPQPjFSkV0YuOGw/0?wx_fmt=jpeg', '084A5583.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '16947', '0', '0', '1502498542', '1');
INSERT INTO `pk_file` VALUES ('57', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/9d1ec2916348f359e.jpg', '9d1ec2916348f359e', 'efzRilNNFDo0wX9aR4jkLJxLlyDbzzxW9wo6HOnhu9M', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aObhCAILbGhSGTFyGCummnsiaBx31MTkLICsv8XEfwXhjsSzSAtkAZ4Q/0?wx_fmt=jpeg', '084A5579.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '36649', '0', '0', '1502498543', '1');
INSERT INTO `pk_file` VALUES ('58', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/d61c3a7b6d42fbdb5.jpg', 'd61c3a7b6d42fbdb5', 'efzRilNNFDo0wX9aR4jkLAPK5pwqmjER3ktW0yuNVVY', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aiaYic3hk3LvibFLJYPJ62ojiar7QDTiba15U12mYjYYAeZHTtgMGnAz2xiaQ/0?wx_fmt=jpeg', '084A5570.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '36514', '0', '0', '1502498543', '1');
INSERT INTO `pk_file` VALUES ('59', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0f7d3ec54cf60ea45.jpg', '0f7d3ec54cf60ea45', 'efzRilNNFDo0wX9aR4jkLFkZHdJSFiFrSKHI98ZeFyM', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1ab9yb3JWE1BrHtvf2DE28Q9uhz3N3oLxjT4IN46ajTgTrgBTNr97epw/0?wx_fmt=jpeg', '084A5575.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '34057', '0', '0', '1502498543', '1');
INSERT INTO `pk_file` VALUES ('60', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/65c444e05712e2079.jpg', '65c444e05712e2079', 'efzRilNNFDo0wX9aR4jkLKCNOa2ljjaaOWP5fjmn7NI', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1as9ibXiay1x5NiaLqibxFRYt0IwV7XbZnlxBrgOia23f8PF94lLGacVqVMjQ/0?wx_fmt=jpeg', '084A5568.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '42218', '0', '0', '1502498543', '1');
INSERT INTO `pk_file` VALUES ('61', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/c668467bc7046a1b5.jpg', 'c668467bc7046a1b5', 'efzRilNNFDo0wX9aR4jkLPWaGowP_kJ_69R-zcBTV0o', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a4TaaSNgEckgXCoXccZcFDNb5mrVG7BV8qoSqYRGsa7g7CAvnb1S8Lw/0?wx_fmt=jpeg', '084A5562.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '7768', '0', '0', '1502498545', '1');
INSERT INTO `pk_file` VALUES ('62', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e767cc2fb2f2c5a81.jpg', 'e767cc2fb2f2c5a81', 'efzRilNNFDo0wX9aR4jkLMew_IAb92PQOa6ryY3KmUQ', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aiajd4fVlzRux9kXlM1v39anX8qaiaCiadoaFHV3XSzu7AXYnlvlpNECibQ/0?wx_fmt=jpeg', '084A5430.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '14250', '0', '0', '1502498545', '1');
INSERT INTO `pk_file` VALUES ('63', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/28285924b60909da1.jpg', '28285924b60909da1', 'efzRilNNFDo0wX9aR4jkLMUn-qkiI1KvoAbiQx6R8Oc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aPicIr25m50Fgbb5nTzER5s1kR0w9FfPrfKXeiak8YIsCDHJh9FssHnKQ/0?wx_fmt=jpeg', '084A5767.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '24922', '0', '0', '1502498546', '1');
INSERT INTO `pk_file` VALUES ('64', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/9f110c8cac193a736.jpg', '9f110c8cac193a736', 'efzRilNNFDo0wX9aR4jkLLmDa8T8_UPk9wfBu9XKsTg', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a78SzFQPPuAqv64PcXkcDUmRoepGpPryo7NHKQhDG94FjEIYbd9cmSA/0?wx_fmt=jpeg', '084A5729.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '14222', '0', '0', '1502498546', '1');
INSERT INTO `pk_file` VALUES ('65', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/81589903cac39c7f2.jpg', '81589903cac39c7f2', 'efzRilNNFDo0wX9aR4jkLM-u91NffLTv8JO3BaVvIFM', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1acSwKECXzCtRfTo19YFEC4IBVxJQVcdpI0IajD0qic1FGSgFFK0o4j0A/0?wx_fmt=jpeg', '084A5684.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '17282', '0', '0', '1502498546', '1');
INSERT INTO `pk_file` VALUES ('66', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0a6c9a1881fe6a2dd.jpg', '0a6c9a1881fe6a2dd', 'efzRilNNFDo0wX9aR4jkLHOYERG1STIoEWBQlxXc_KI', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a79x2y4zjQpyUIr3XxXFOsDPs4OY8n2JgNxkAhNjUibQ1D5al1cGnlcw/0?wx_fmt=jpeg', '084A5682.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '39727', '0', '0', '1502498547', '1');
INSERT INTO `pk_file` VALUES ('67', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/b27f0b117a42084c6.jpg', 'b27f0b117a42084c6', 'efzRilNNFDo0wX9aR4jkLDkC_YpElGctJmFB2XgYqdc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aLiax3csvvuL4yN6Y6kAMdbjAwxJcibIJZYfu7NyJkQ3S6pqfribwz3p5g/0?wx_fmt=jpeg', '084A5689.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10463', '0', '0', '1502498547', '1');
INSERT INTO `pk_file` VALUES ('68', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e629e3a2d06b73ac8.jpg', 'e629e3a2d06b73ac8', 'efzRilNNFDo0wX9aR4jkLO9PsMW9hUCfOjVLOWaDEbE', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aWS6Idcry6SbFzGX0NUJZjZXBvfmictcw4MN7GIoKvAmJoRSK3YVZ2fw/0?wx_fmt=jpeg', '084A5670.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '21423', '0', '0', '1502498547', '1');
INSERT INTO `pk_file` VALUES ('69', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/bb8a0913975a956c5.jpg', 'bb8a0913975a956c5', 'efzRilNNFDo0wX9aR4jkLLsmUs-M2TLNVuS7_Wcmrk8', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aFwpXF68wwgUAEuOKqeZ0JHyum0FbibTHvbpqrdicDJCrfZ4iaEUnEzN6Q/0?wx_fmt=jpeg', '084A5638.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '36576', '0', '0', '1502498547', '1');
INSERT INTO `pk_file` VALUES ('70', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/171d17ca5d7fc6621.jpg', '171d17ca5d7fc6621', 'efzRilNNFDo0wX9aR4jkLMq6AgxCLlE33nAewixNUN4', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a7noGk1H5VWgVk19nwRIQVb2icNY0F1HCA55HCfaFD1m1UxQEeFIgMSA/0?wx_fmt=jpeg', '084A5635.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '33286', '0', '0', '1502498547', '1');
INSERT INTO `pk_file` VALUES ('71', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/5a85fd071df6a4b27.jpg', '5a85fd071df6a4b27', 'efzRilNNFDo0wX9aR4jkLLZCPgSJSLJaM6MWI30cw9Q', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aGjUjJ4wbbXoONzAVFc7m6zs7WG44Dnh12sdDz7Nv4kBZWAPKxmCuiaw/0?wx_fmt=jpeg', '084A5631.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '22046', '0', '0', '1502498548', '1');
INSERT INTO `pk_file` VALUES ('72', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/45239d40519f2b70b.jpg', '45239d40519f2b70b', 'efzRilNNFDo0wX9aR4jkLGBZE22t6e50wcP_eXf8jzE', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a3LdUYtPOBH6wZs2rn7VH3DFLD7ogI9tRJq1FARyRLibkSeEYF93ia28g/0?wx_fmt=jpeg', '084A5629.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '12221', '0', '0', '1502498548', '1');
INSERT INTO `pk_file` VALUES ('73', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/fd97094d718e203b3.jpg', 'fd97094d718e203b3', 'efzRilNNFDo0wX9aR4jkLL5HM2Ek3QdFWb_0zHTt4d8', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1anAQNEvZwicZB0WhjTmR1Ppa19T3icpXGKOGjgyjr39Nibx9ksL91w4ySA/0?wx_fmt=jpeg', '084A5560.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '43554', '0', '0', '1502498548', '1');
INSERT INTO `pk_file` VALUES ('74', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/ed3831f346709af97.jpg', 'ed3831f346709af97', 'efzRilNNFDo0wX9aR4jkLG-c4CZrxch6xOEJpsDuQL0', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aDBUzAP1yO8mGoqqOAu1ozyrGylKA3kvAxUQX5pnFc3HeZlM9WQU6AQ/0?wx_fmt=jpeg', '084A5559.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '40121', '0', '0', '1502498549', '1');
INSERT INTO `pk_file` VALUES ('75', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/a74860a69b501c2ad.jpg', 'a74860a69b501c2ad', 'efzRilNNFDo0wX9aR4jkLLJ9Wf1F6YHvFMZKh-gWCUA', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a9iarAVBhPD3b7Lc36GU3hcJDSxAicBsupmXohucc2QFcGzaibzp2Kec4w/0?wx_fmt=jpeg', '084A5556.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '52221', '0', '0', '1502498549', '1');
INSERT INTO `pk_file` VALUES ('76', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/81f55a542ffa62dad.jpg', '81f55a542ffa62dad', 'efzRilNNFDo0wX9aR4jkLIuAFoKf4Qt6aA3fpZwzX5U', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1abzBzGs9Vicd3rsezFVHHib8lXPFB8BhrdGcX5rOlucjicZ9dm9icuFia39A/0?wx_fmt=jpeg', '084A5550.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '16274', '0', '0', '1502498549', '1');
INSERT INTO `pk_file` VALUES ('77', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/ae10d0a792c59dedf.jpg', 'ae10d0a792c59dedf', 'efzRilNNFDo0wX9aR4jkLHr9YbpRIyzH9f1OGF1iD7w', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aamFxdrP7un0RogECqiccpdLjCh1iaYe1rIHw38VC2xic8uOgOrS63hy8A/0?wx_fmt=jpeg', '084A5554.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '38762', '0', '0', '1502498550', '1');
INSERT INTO `pk_file` VALUES ('78', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/efbee0fef86dd4a5f.jpg', 'efbee0fef86dd4a5f', 'efzRilNNFDo0wX9aR4jkLB3CDOrx1pJUUfUSJd1JaTw', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aaEaWUwZRRkhm50b1EYeJm6OYBZx9bBJLU4qyOpO4X3RrN65ic7RKnqQ/0?wx_fmt=jpeg', '084A5557.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '49817', '0', '0', '1502498550', '1');
INSERT INTO `pk_file` VALUES ('79', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e324e5f4b770944f4.jpg', 'e324e5f4b770944f4', 'efzRilNNFDo0wX9aR4jkLGf2TQQ3DYglnDuw2ayv2as', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a9H62aLW2UtHnDfq0gzCelx06nadPCia9fnsibTaPgFvDnbnTzCI3rqwQ/0?wx_fmt=jpeg', '084A5772.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '18621', '0', '0', '1502498550', '1');
INSERT INTO `pk_file` VALUES ('80', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/dbd754b61142339e4.jpg', 'dbd754b61142339e4', 'efzRilNNFDo0wX9aR4jkLDNU1sPrIpVP3hvBLWw5ZaY', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aibfOpTias8NibghzGGK0fKHU7HiaJfQ8yQgO1jz1xDc3FvadCJzQDtcib5g/0?wx_fmt=jpeg', '084A5745.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '9043', '0', '0', '1502498550', '1');
INSERT INTO `pk_file` VALUES ('81', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/dbea893944602f0d5.jpg', 'dbea893944602f0d5', 'efzRilNNFDo0wX9aR4jkLE4AvWtvZyR7S2QE4Wt1BVI', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aP5dc9ibicxxCicERbsRAx3d1NXJJXPLI39jbibianVM1icGZZzF0TMrbtiaTg/0?wx_fmt=jpeg', '084A5546.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '41083', '0', '0', '1502498552', '1');
INSERT INTO `pk_file` VALUES ('82', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/8ce4d070bd2226ee7.jpg', '8ce4d070bd2226ee7', 'efzRilNNFDo0wX9aR4jkLI9X7_ZCbBbuATzdXJeuRHI', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aWyuURC5VNv0fHmbBqKHicDOrMuOp6gMoJDJ5Lqqule8VAGLugrgKr5w/0?wx_fmt=jpeg', '084A5534.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10921', '0', '0', '1502498552', '1');
INSERT INTO `pk_file` VALUES ('83', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/3d02f253608ec5a5e.jpg', '3d02f253608ec5a5e', 'efzRilNNFDo0wX9aR4jkLN3OCK-PilQ-h6t5xpZFp_I', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a8oellGFZWic1YJkr6DNSTMj19hJ9uR1gFRcgFBokTSfuVCJoua1QKNQ/0?wx_fmt=jpeg', '084A5533.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '29376', '0', '0', '1502498553', '1');
INSERT INTO `pk_file` VALUES ('84', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/8d376f722c06a774a.jpg', '8d376f722c06a774a', 'efzRilNNFDo0wX9aR4jkLI1efytkT9n1QNLLw-QqVzo', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aFGdfART82skItpgEVeFNAibzW3XjLea0shIRwPdsKbhJ9SyBU9TxjPw/0?wx_fmt=jpeg', '084A5529.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10671', '0', '0', '1502498553', '1');
INSERT INTO `pk_file` VALUES ('85', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0f2387a2f7968396a.jpg', '0f2387a2f7968396a', 'efzRilNNFDo0wX9aR4jkLG5pHyawLzHsoQ73xnr7gWw', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1avCgiarwpibR9ZvE0fosMeJV047PT5LS3KojsUNyXoYfelLJAF3BeM5rA/0?wx_fmt=jpeg', '084A5502.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '45719', '0', '0', '1502498553', '1');
INSERT INTO `pk_file` VALUES ('86', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/f6e196f57c123edcb.jpg', 'f6e196f57c123edcb', 'efzRilNNFDo0wX9aR4jkLEwwid2x9keKfO1HXdPGbP8', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aEWSFxCgRgEYSAtkYFxv1Hib3yIFbA9YE0xibLmF0X884zRnUbbVnttOQ/0?wx_fmt=jpeg', '084A5517.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '18916', '0', '0', '1502498553', '1');
INSERT INTO `pk_file` VALUES ('87', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/126903dcb65e91bd4.jpg', '126903dcb65e91bd4', 'efzRilNNFDo0wX9aR4jkLH-c81bnkoisVBeWdSI_7jY', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aVQvuiaibB7icPr51oUictWBuBv6aRygLV7BPLICdOS5syLBINFU4qPlRvw/0?wx_fmt=jpeg', '084A5483.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '19354', '0', '0', '1502498553', '1');
INSERT INTO `pk_file` VALUES ('88', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/704bd3a927fa951ac.jpg', '704bd3a927fa951ac', 'efzRilNNFDo0wX9aR4jkLFevnMvJM_w_A5ZmPRRhTxY', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1atLm7lmTzGnT0ia81ohgFZoA2DKZtqaO2VN9WRWF3FcEDee89iarBxdvg/0?wx_fmt=jpeg', '084A5470.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '11411', '0', '0', '1502498554', '1');
INSERT INTO `pk_file` VALUES ('89', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/4703658fcc9d1188f.jpg', '4703658fcc9d1188f', 'efzRilNNFDo0wX9aR4jkLNQGQuCRK8WKfgWdsP1eINw', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aJxYgm68YNRgo6G0DcyibI4g0KfbVicHeHCL7KibQD3D8YCfPbAY1KmfgQ/0?wx_fmt=jpeg', '084A5462.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '14780', '0', '0', '1502498554', '1');
INSERT INTO `pk_file` VALUES ('90', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/e2d0c90000e3668d0.jpg', 'e2d0c90000e3668d0', 'efzRilNNFDo0wX9aR4jkLG0xhrJkYwmdItl75PhNON4', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aAEJHRPkjRHChecCwNPDgzm0kSlk0KvPoNB68POcKxVjvvdxA48oKag/0?wx_fmt=jpeg', '084A5469.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '17058', '0', '0', '1502498554', '1');
INSERT INTO `pk_file` VALUES ('91', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/8776ddc466b01caa2.jpg', '8776ddc466b01caa2', 'efzRilNNFDo0wX9aR4jkLJDKA2VAkbM6ry9cEfIfkT4', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aqf9iaRbl5YCrWcgFTAT9Q47yh9LCHNGeUs67DuicAibBZRKtD9Jo5RMgg/0?wx_fmt=jpeg', '084A5475.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '11374', '0', '0', '1502498554', '1');
INSERT INTO `pk_file` VALUES ('92', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/0a28563c5392c6168.jpg', '0a28563c5392c6168', 'efzRilNNFDo0wX9aR4jkLOwFWSUEo0UDub22OiiCNvs', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1avqG31maZ8elPFoiaTPgmyCetlsuQciaPKTrrZBtIicSIHh4rpEH38IKWg/0?wx_fmt=jpeg', '084A5449.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '27404', '0', '0', '1502498555', '1');
INSERT INTO `pk_file` VALUES ('93', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/1790e37ba7a85b3e6.jpg', '1790e37ba7a85b3e6', 'efzRilNNFDo0wX9aR4jkLIVWj3si567BNK-UHjcaiMo', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1aOm4e6h55UcV9PNIX8z7Wx7m5ReIapODsEgaJ3Gv8icmqrLMyCy3mywA/0?wx_fmt=jpeg', '084A5447.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '10857', '0', '0', '1502498555', '1');
INSERT INTO `pk_file` VALUES ('94', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/dce46673b8a57d207.jpg', 'dce46673b8a57d207', 'efzRilNNFDo0wX9aR4jkLNvTsguuUh4-ShehRvzDhGc', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a25LWHCvXmq3MVT15klibUfkUrzPt2map0DZHIMAXJEwthKpRciabuALQ/0?wx_fmt=jpeg', '084A5436.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '49393', '0', '0', '1502498555', '1');
INSERT INTO `pk_file` VALUES ('95', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/99723ab7d14a67912.jpg', '99723ab7d14a67912', 'efzRilNNFDo0wX9aR4jkLN3AHoUXFS4jpQkjVRNr4Co', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a3pVHByIf2YvUt6sCFbqZ4GbBuHhibC0SdOlERicZwib5PMhftBT1mhjpw/0?wx_fmt=jpeg', '084A5446.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '16740', '0', '0', '1502498556', '1');
INSERT INTO `pk_file` VALUES ('96', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/075a526998afc82a3.jpg', '075a526998afc82a3', 'efzRilNNFDo0wX9aR4jkLJcywswksANlC_hl_z66lD4', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1agibdXlbqpozOdYsl1K5UxIPiajQWXf9FWrXzOQwqpv1ZRymKQyXtQUSA/0?wx_fmt=jpeg', '084A5435.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '39471', '0', '0', '1502498556', '1');
INSERT INTO `pk_file` VALUES ('97', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/fac4880a28824a8e9.jpg', 'fac4880a28824a8e9', 'efzRilNNFDo0wX9aR4jkLKylwHwbuQO4JptwawC8K8I', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a0GXyahngvaicTjoGqibnNU26UiastFlic0bEc0rGGL3Nx2I6Q35icVVnSUg/0?wx_fmt=jpeg', '084A5433.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '18943', '0', '0', '1502498556', '1');
INSERT INTO `pk_file` VALUES ('98', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/c9fc42dea69fa398c.jpg', 'c9fc42dea69fa398c', 'efzRilNNFDo0wX9aR4jkLPIBDFk4SZiDaoSaGAqFTBk', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1asGzOjxSXhcnodx5HdqFTwy2kMvT4GPkT4AzJYjgsic5cRU1degox6ZQ/0?wx_fmt=jpeg', '084A5422.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '50014', '0', '0', '1502498557', '1');
INSERT INTO `pk_file` VALUES ('99', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/ea5661b1f3b8bb2d6.jpg', 'ea5661b1f3b8bb2d6', 'efzRilNNFDo0wX9aR4jkLAOvL5hujEhUHQs3qJeFd90', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzarpHu6AMV40QIwb1xLAI1a2icPoSbzJWRsicFCVRmxRKwZ03IAqdYQdbHrv8sXtw5mUVgocoKrd90Q/0?wx_fmt=jpeg', '084A5414.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '9243', '0', '0', '1502498558', '1');
INSERT INTO `pk_file` VALUES ('100', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/ece3568800d870dc3.jpg', 'ece3568800d870dc3', 'efzRilNNFDo0wX9aR4jkLJudBWCrD58uoPvZ55G1CLk', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzaiaiaBFEQeXLKWxR9DW4yvXsMxVBJm19mo9R8cHUIojpdmbiaDATUxKdmK9ic45FPtc0Ac6gbSFtQ6gA/0?wx_fmt=jpeg', 'IMG_2484.JPG', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '16026', '0', '0', '1502498558', '1');
INSERT INTO `pk_file` VALUES ('101', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/f39095dff1ad8a86f.jpg', 'f39095dff1ad8a86f', 'efzRilNNFDo0wX9aR4jkLMerWjKeXUU_lFd7d1UaOMI', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzaiaiaBFEQeXLKWxR9DW4yvXsrFv4qWsiaicLyFBtricVyF7QJCRaff4aV5Lw03uXhic4Uibb6F6OawvfztA/0?wx_fmt=jpeg', '8367cb59edd766e3a24245ac324eb79e.jpg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '12910', '0', '0', '1502498560', '1');
INSERT INTO `pk_file` VALUES ('102', '0', 'weixin_news_cover', '0', '/data/uploads/201708/weixin_news_cover/477609652765587c8.jpg', '477609652765587c8', 'efzRilNNFDo0wX9aR4jkLDrpDT11OrBFgUZ3UwEy4QQ', 'http://mmbiz.qpic.cn/mmbiz_jpg/LCKF8M32tzaiaiaBFEQeXLKWxR9DW4yvXshjUf9zv3rqfCOyfibEibMmXwo1kOYnVH6zptnlfZ9KbsOKxFL6betibZg/0?wx_fmt=jpeg', '8cbc19e47d6743acf19f9688c6692ec2.jpeg', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '.jpg', '33207', '0', '0', '1502498560', '1');
INSERT INTO `pk_file` VALUES ('103', '0', 'yuji_index_about_banner', '1', '/data/uploads/201708/yuji_index_about_banner/fddb028d5f025fc66.jpg', 'fddb028d5f025fc66', '', '', 'aa3e0b11186d925ed.jpg', '0b5cb47ddc890fead937bb11f661f934f494c89c', 'jpg', '73822', '0', '0', '1502608728', '1');
INSERT INTO `pk_file` VALUES ('104', '0', 'kindeditor', '0', '/data/uploads/201708/kindeditor/a863afc4010e9ce37.jpg', 'a863afc4010e9ce37', '', '', 'aa3e0b11186d925ed.jpg', '0b5cb47ddc890fead937bb11f661f934f494c89c', 'jpg', '73824', '0', '0', '1502609502', '1');
INSERT INTO `pk_file` VALUES ('105', '0', 'yuji_product_cover', '0', '/data/uploads/201708/yuji_product_cover/2b0443546b57a3494.jpg', '2b0443546b57a3494', '', '', 'aa3e0b11186d925ed.jpg', '0b5cb47ddc890fead937bb11f661f934f494c89c', 'jpg', '73822', '0', '0', '1502609535', '1');

-- -----------------------------
-- Table structure for `pk_user`
-- -----------------------------
DROP TABLE IF EXISTS `pk_user`;
CREATE TABLE `pk_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) NOT NULL,
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `avatar` varchar(255) NOT NULL DEFAULT 'ddsss/ddd/aa.jpg' COMMENT '头像地址',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '性别',
  `qq` varchar(12) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_from` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-注册2-微信3-后台导入',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_ipaddress` varchar(40) NOT NULL,
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '会员状态',
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `pk_user`
-- -----------------------------
INSERT INTO `pk_user` VALUES ('1', 'hottredpen2244', 'hottredpen11', 'ddsss/ddd/aa.jpg', '1', '', '', '13625896500', '0000-00-00', '0', '0', '0', '0', '1', '0', '', '0', '1', '1495698090');
INSERT INTO `pk_user` VALUES ('6', '666', '', 'ddsss/ddd/aa.jpg', '1', '', '', '', '0000-00-00', '0', '0', '0', '0', '2', '0', '', '0', '1', '0');
INSERT INTO `pk_user` VALUES ('7', '6662444', '222', 'ddsss/ddd/aa.jpg', '1', '', '', '13625896500', '0000-00-00', '0', '0', '0', '1495684136', '3', '0', '', '0', '1', '1495693126');

-- -----------------------------
-- Table structure for `pk_user_login`
-- -----------------------------
DROP TABLE IF EXISTS `pk_user_login`;
CREATE TABLE `pk_user_login` (
  `id` int(10) unsigned NOT NULL COMMENT '用户ID',
  `user_id` int(10) NOT NULL,
  `identity_type` varchar(50) NOT NULL COMMENT '登录类型（phone,email,username,weixin,weibo,qq)',
  `identifier` varchar(100) DEFAULT NULL COMMENT '标识(第三方应用的唯一标识)',
  `credential` varchar(100) DEFAULT NULL COMMENT '密码凭证（站内的保存密码，站外的不保存或保存token）',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已经验证',
  PRIMARY KEY (`id`),
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户登录凭证';

-- -----------------------------
-- Records of `pk_user_login`
-- -----------------------------
INSERT INTO `pk_user_login` VALUES ('5', '1', 'username', '', '123456', '1');
INSERT INTO `pk_user_login` VALUES ('6', '1', 'phone', '13625896500', '', '1');
INSERT INTO `pk_user_login` VALUES ('7', '1', 'email', 'hottredpen@126.com', '', '1');

-- -----------------------------
-- Table structure for `pk_user_msg_email_log`
-- -----------------------------
DROP TABLE IF EXISTS `pk_user_msg_email_log`;
CREATE TABLE `pk_user_msg_email_log` (
  `id` int(10) unsigned NOT NULL,
  `admin_id` int(10) NOT NULL,
  `fuid` int(10) NOT NULL,
  `tuid` int(10) NOT NULL,
  `msg_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1系统消息2用户级消息',
  `email` varchar(255) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_user_msg_email_log`
-- -----------------------------
INSERT INTO `pk_user_msg_email_log` VALUES ('4', '111', '0', '1', '1', 'hottredpen@126.com', '测试短信', '&lt;p&gt;asdfasdfasd&lt;/p&gt;&lt;p&gt;a&lt;strong&gt;sdfasdf&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;asdfasdf邮件&lt;br/&gt;&lt;/p&gt;', '1495939846');
INSERT INTO `pk_user_msg_email_log` VALUES ('5', '0', '6', '7', '2', 'hottredpen@126.com', 'sdfasdf', 'asdfasdfasdfasdf', '0');
INSERT INTO `pk_user_msg_email_log` VALUES ('0', '1', '0', '1', '1', 'hottredpen@126.com', '', '', '1502521400');

-- -----------------------------
-- Table structure for `pk_user_msg_localmsg_log`
-- -----------------------------
DROP TABLE IF EXISTS `pk_user_msg_localmsg_log`;
CREATE TABLE `pk_user_msg_localmsg_log` (
  `id` int(10) unsigned NOT NULL,
  `admin_id` int(10) NOT NULL,
  `fuid` int(10) NOT NULL,
  `tuid` int(10) NOT NULL,
  `msg_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1系统消息2用户级消息',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_user_msg_localmsg_log`
-- -----------------------------
INSERT INTO `pk_user_msg_localmsg_log` VALUES ('9', '0', '6', '1', '2', 'dafadf22222', '&lt;p&gt;adasdfs&lt;strong&gt;dfaasdf&lt;/strong&gt;asdf&lt;br/&gt;&lt;/p&gt;', '1495868632');
INSERT INTO `pk_user_msg_localmsg_log` VALUES ('10', '0', '6', '1', '2', '测试短信', '&lt;p&gt;asdfasdfasd&lt;/p&gt;&lt;p&gt;a&lt;strong&gt;sdfasdf&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;asdfasdf&lt;br/&gt;&lt;/p&gt;', '1495868828');
INSERT INTO `pk_user_msg_localmsg_log` VALUES ('11', '0', '6', '1', '2', '测试短信', '&lt;p&gt;asdfasdfasd&lt;/p&gt;&lt;p&gt;a&lt;strong&gt;sdfasdf&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;asdfasdf来自站内信&lt;br/&gt;&lt;/p&gt;', '1495938891');
INSERT INTO `pk_user_msg_localmsg_log` VALUES ('12', '0', '6', '1', '2', '测试短信', '&lt;p&gt;asdfasdfasd&lt;/p&gt;&lt;p&gt;a&lt;strong&gt;sdfasdf&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;asdfasdf来自站内信&lt;br/&gt;&lt;/p&gt;', '1495938900');
INSERT INTO `pk_user_msg_localmsg_log` VALUES ('13', '0', '6', '1', '2', '测试短信', '&lt;p&gt;asdfasdfasd&lt;/p&gt;&lt;p&gt;a&lt;strong&gt;sdfasdf&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;asdfasdf来自站内信&lt;br/&gt;&lt;/p&gt;', '1495938980');
INSERT INTO `pk_user_msg_localmsg_log` VALUES ('14', '111', '0', '6', '1', '测试短信', '&lt;p&gt;asdfasdfasd&lt;/p&gt;&lt;p&gt;a&lt;strong&gt;sdfasdf&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;asdfasdf站内信&lt;br/&gt;&lt;/p&gt;', '1495939845');
INSERT INTO `pk_user_msg_localmsg_log` VALUES ('15', '111', '0', '6', '1', '啊大方', '&lt;p&gt;啊撒旦法撒旦法&lt;/p&gt;&lt;p&gt;阿萨德发实打实的发生的f&lt;/p&gt;&lt;p&gt;阿萨德&lt;em&gt;&lt;strong&gt;f阿萨德f&lt;/strong&gt;&lt;/em&gt;&lt;br/&gt;&lt;/p&gt;', '1495940325');

-- -----------------------------
-- Table structure for `pk_user_msg_sms_log`
-- -----------------------------
DROP TABLE IF EXISTS `pk_user_msg_sms_log`;
CREATE TABLE `pk_user_msg_sms_log` (
  `id` int(10) unsigned NOT NULL,
  `admin_id` int(10) NOT NULL,
  `fuid` int(10) NOT NULL,
  `tuid` int(10) NOT NULL,
  `msg_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1系统消息2用户级消息',
  `phone` varchar(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_user_msg_sms_log`
-- -----------------------------
INSERT INTO `pk_user_msg_sms_log` VALUES ('4', '0', '7', '6', '2', '13625896500', 'sss', '啊撒旦法撒旦法撒旦法', '0');
INSERT INTO `pk_user_msg_sms_log` VALUES ('5', '0', '6', '7', '2', '13625896500', 'rrrt', 'asdfasdfadf阿福噶水电费', '0');
INSERT INTO `pk_user_msg_sms_log` VALUES ('6', '111', '0', '6', '1', '13625896577', 'ddss', 'asdfasdf ', '0');
INSERT INTO `pk_user_msg_sms_log` VALUES ('7', '111', '0', '1', '1', '13625896500', '测试短信', '测试发送短信，语记', '1495939846');

-- -----------------------------
-- Table structure for `pk_user_msg_tpl`
-- -----------------------------
DROP TABLE IF EXISTS `pk_user_msg_tpl`;
CREATE TABLE `pk_user_msg_tpl` (
  `id` int(10) unsigned NOT NULL,
  `tpl_module` int(10) NOT NULL DEFAULT '1' COMMENT '所属模块',
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL COMMENT '模板内容',
  `content_sms` text NOT NULL COMMENT '短信模板内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '关闭开启',
  `status_msg` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '站内短信',
  `status_email` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '发送邮件',
  `status_phone` int(1) DEFAULT '0' COMMENT '是否发送手机短信',
  `add_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `pk_user_msg_tpl`
-- -----------------------------
INSERT INTO `pk_user_msg_tpl` VALUES ('3', '1', 'test_send', '测试短信', '&lt;p&gt;asdfasdfasd&lt;/p&gt;&lt;p&gt;a&lt;strong&gt;sdfasdf&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;asdfasdf&lt;br/&gt;&lt;/p&gt;', '测试发送短信，语记', '1', '1', '1', '0', '0', '1495851726');
